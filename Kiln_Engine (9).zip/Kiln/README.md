# Kiln Engine

A browser-based 3D game engine with an editor and play mode. Built on Three.js. No install, no server.

## Start

Double-click `index.html` (Chrome or Edge recommended). The demo project opens automatically.
Press **▶ Play** (or F5) to try it. Press **Esc** to free the mouse, then **■ Stop**.

All libraries are in `lib/`, so it works offline. (Text fonts load from Google Fonts when online and fall back to system fonts offline.)

## Project = a folder (or a .zip of it)

```
MyGame/
  project.json          scene objects, events, triggers, items, settings
  assets/textures/      png, jpg, webp, gif …
  assets/models/        fbx, glb, gltf
  assets/sfx/           wav, mp3, ogg …
  assets/music/
  saves/slot1.json      in-game save files
```

- **Export .zip** downloads the whole project in that layout.
- **Open .zip** or **Open folder** loads one back.
- **Save** (Ctrl+S) keeps the project in this browser (it also autosaves). Export a zip to keep a real copy.

## Editor basics

| Action | How |
|---|---|
| Add object | **+ Add** (boxes, spheres, ramps, floors, decals, 3D text, models, interaction blocks, enemies/NPCs, spawn, lights) |
| Move / rotate / scale | 1 / 2 / 3, drag the gizmo, or type numbers in the Inspector |
| Camera | left-drag orbit, right-drag pan, wheel zoom, F focus |
| Texture an object | drag an image card from **Assets** onto the object in the viewport |
| Import files | drag files from your computer into the viewport or the Assets tab |
| Place a model | drag an FBX/GLB into the viewport |
| Duplicate / delete / undo | Ctrl+D / Del / Ctrl+Z, Ctrl+Y |

## How game logic works

1. **Tags** — give objects tags like `sigma`. Actions target a tag (or a name).
2. **Events** — a named group of actions on a timeline. Each action has a time in seconds *after the event starts*. Drag blocks on the timeline to retime them.
3. **What starts an event**
   - **Interaction block** (orange box, invisible in game): left click, right click, either, interact key, or player touching / stepping in. Can require an item, run once, have a cooldown.
   - **Triggers tab**: game start, at N seconds of game time (optionally repeating), player touches tagged object, key press, enemy killed, player has N items, flag value.
   - Another event (“Run another event”), or an enemy’s death.

Example: interaction block → event `Open the door` → `Rotate object` target `sigma` by Y 90°.

### Action list
Objects: rotate, move, scale (with easing), show/hide, toggle, collision on/off, destroy, change texture, change color, change 3D text, play model animation, enable/disable interaction.
Player: give/take item, teleport (XYZ or to an object), lock/unlock, damage, heal, change speed, change gravity/jump.
Screen & camera: lock camera at XYZ looking at an object, release camera, shake, fade out/in (any color), complete blackout, title text, dialogue/subtitle, clear text.
Sound: play a sound file (volume, loop, channel, follow an object), stop sound.
Enemies & NPCs: spawn from a template, kill, damage, walk NPC to XYZ, face player, hostile on/off.
Flow: run event, stop event, set flag, save game (checkpoint), debug log.

### Text styling
Presets (Cinematic, Horror, Retro, SciFi, Typewriter, Impact, Korean, Boxed) plus font, size, color, weight, italic, uppercase, letter spacing, alignment, position (center/top/bottom/lower third/custom %), outline, drop shadow / glow / hard shadow, background box or bar, subtitle line, and animations: fade, typewriter, slide up/down, zoom, shake, glitch, wave.

## Enemies & NPCs
Health, speed, damage, attack range and rate, notice range, hostile or friendly, health bar, sounds (hurt/attack/death), death event.
- **No model**: a built-in jointed rig (hips, spine, head, arms, forearms, legs, shins). Pose each joint in degrees; walk/zombie/idle motions play on top.
- **FBX/GLB model**: auto-sized; pick idle / walk / attack / death clips from the model or from other FBX files (Mixamo “without skin” animations work). Bone offsets can be posed per bone.
- Uncheck **Spawn at start** to make a template, then spawn copies with the “Spawn enemy” action.

## Play controls (defaults — change in Settings → Controls)
WASD move · Shift run · Space jump · mouse look (arrow keys too) · left click: interact / attack · right click: interact · E: interact key · P pause menu (save/load 3 slots) · F5 quick save · F9 quick load.

## Demo project
Lever opens the vault door (`sigma`), right-click chest gives a key, hot plate hurts on touch, glowing pad teleports to section B with a fade, title and `assets/sfx/tts_3.wav`, the Guide cutscene locks player + camera for 10 seconds while `speech.wav` plays, the red stone spawns grunts, and the key opens a gate.

The demo’s `tts_3.wav` and `speech.wav` are placeholder voice-like sounds. Replace them with your own recordings (same file names) and every event that uses them plays your audio.

## Update: groups, basic assets, gameplay
- **Editor camera**: hold left mouse to look around, WASD moves where you look (Q/E down/up, Shift faster), right-drag pans, wheel zooms fast. **T** jumps the camera to the selected object (browsers keep Ctrl+T for new tabs).
- **Groups**: select objects, press **G** to group them (G again on a group ungroups). A group has one position/rotation/scale; everything inside follows. Click selects the whole group, Alt+click picks one object inside.
- **Copy / paste**: Ctrl+C / Ctrl+V copies objects in the scene, or the selected action on the timeline (paste into any event).
- **Drag select (R)** now selects anything the box touches.
- **+ Add → Basic assets**: Pistol, Rifle (automatic), Ammo box, Damage block, Checkpoint, Password keypad, House, Car.
- **Guns**: walk into a gun to pick it up. LMB fires, R reloads, 1-9 switches. Ammo boxes add ammo of the same type.
- **Password lock** (any object's Inspector): left click or E opens a keypad with button beeps; right code runs an event, wrong code runs another.
- **Damage on touch** (any solid / interaction block): once per touch, per second, or instant kill. You respawn at the last **checkpoint** you touched.
- **Car**: E to get in/out. W/S throttle/brake, A/D steer, Space gear up, Shift gear down (R, N, 1-5). Engine sound follows RPM; shift sound on every change.
- **Bunny hop**: hold jump while moving to chain hops without losing speed (Settings → bunny hop, gain, max speed).
- **New trigger**: "When object touches another object" (tag A touches tag B).

## Update: held items
- **Items tab**: each item has a type (held item / sword / gun), damage, and a **model**: any group or object in your scene ("Use selected in scene"), or a built-in sword/gun. While an item is selected, the viewport shows it in hand exactly as in game; set hand position / rotation / scale / size and idle motion (bob + sway, bob, float, spin, still).
- **Getting items**: the item's model in the world is a pickup (look + E / left click, or walk into it), or turn that off to use it only as the look. The "Give player item" action flies the item into your hand from any object you pick (or from the interaction block / the ground), with a pick-up dip and a changeable pickup sound.
- **Hotbar**: 1-9 or the mouse wheel. Pressing the same number again puts the item away.
- **Sword**: reach, hit arc, pause after swing, swing / hit sounds, and a combo list of swing motions: slash, backhand, overhead, stab, uppercut, spin, bash, or **custom keyframes** (time, move xyz, turn xyz). Test them in the preview.
- **Gun**: magazine, spare ammo, ammo type, infinite ammo, fire rate, automatic, reload time, recoil, real bullets (size, speed, color, drop, spread, range), shot / reload / empty sounds.

## Update: groups, display settings, Kiln Launcher
- **Scene list**: click ▸ / ▾ next to a group to close or open it. The number shows how many objects are inside; ⚔ marks a group used as an item model.
- **Item models are groups only.** Pick one in Items → Model group, or select a group and use "Use selected group", or in a group's Inspector choose "Model of item" / "+ New item from this group". One object? Select it and press G first.
- **Settings → Game display**: resolution (native, 360p … 4K), FPS limit (30–240 or unlimited), pixelated upscaling, start fullscreen. Applied in Play mode and the launcher.
- **Export .zip** now includes `config.json` (resolution, FPS, fullscreen, pixelated, FOV, mouse speed). Opening the zip in the editor or launcher reads it.
- **Kiln Launcher** (`launcher.html`): a game library. Add exported zips (or a project folder), see each game's resolution / FPS, change them per game (⚙), press Play. Games run full-window with no editor; saves are kept per game; Pause → "Quit to launcher". The editor's **▶ Launcher** button sends the current game straight to the library.
