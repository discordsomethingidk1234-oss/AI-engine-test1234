/* ---------- Kiln Launcher: a library of exported games (.zip) that plays them without the editor ---------- */
const LibDB = {
  db: null,
  open(){ if (this.db) return Promise.resolve(this.db);
    return new Promise((res, rej) => { const r = indexedDB.open('kiln-launcher', 1);
      r.onupgradeneeded = () => r.result.createObjectStore('games', {keyPath: 'id'});
      r.onsuccess = () => { this.db = r.result; res(this.db); }; r.onerror = () => rej(r.error); }); },
  async all(){ const db = await this.open(); return new Promise((res, rej) => { const q = db.transaction('games').objectStore('games').getAll(); q.onsuccess = () => res(q.result || []); q.onerror = () => rej(q.error); }); },
  async put(g){ const db = await this.open(); return new Promise((res, rej) => { const t = db.transaction('games', 'readwrite'); t.objectStore('games').put(g); t.oncomplete = res; t.onerror = () => rej(t.error); }); },
  async del(id){ const db = await this.open(); return new Promise((res, rej) => { const t = db.transaction('games', 'readwrite'); t.objectStore('games').delete(id); t.oncomplete = res; t.onerror = () => rej(t.error); }); },
};

/* add a game zip to the library (used by the launcher and by the editor's "Send to launcher") */
async function addGameToLibrary(zipBlob, fileName){
  const zip = await JSZip.loadAsync(zipBlob);
  const names = Object.keys(zip.files);
  const pj = names.filter(n => /(^|\/)project\.json$/i.test(n)).sort((a, b) => a.length - b.length)[0];
  if (!pj) throw new Error('No project.json inside ' + (fileName || 'this zip') + ' — export it from the Kiln editor.');
  const prefix = pj.slice(0, pj.length - 'project.json'.length);
  const project = JSON.parse(await zip.file(pj).async('string'));
  let cfg = null; const cf = zip.file(prefix + 'config.json'); if (cf) try { cfg = JSON.parse(await cf.async('string')); } catch(_){}
  if (!cfg) cfg = gameConfig(project);
  const name = cfg.name || project.name || (fileName || 'Game').replace(/\.zip$/i, '');
  const games = await LibDB.all(); const same = games.find(g => g.name === name);
  const g = Object.assign(same || {id: 'g_' + Date.now().toString(36), added: Date.now(), saves: {}, thumb: ''}, {name, zip: zipBlob, config: cfg, updated: Date.now()});
  await LibDB.put(g); return g;
}

const Launcher = {
  games: [], cur: null,
  async init(){
    // the launcher keeps game saves in its own library, not in the editor's project
    Editor.persist = async () => { if (this.cur){ this.cur.saves = clone(P.saves || {}); await LibDB.put(this.cur); } Editor.setUnsaved(false); };
    const cmd = Editor.cmd.bind(Editor);
    Editor.cmd = c => { if (c === 'play' && Runtime.active) return this.quit(); if (c === 'play') return; return cmd(c); };
    document.querySelector('[data-pm="stop"]').textContent = 'Quit to launcher';
    P = newProject(); W.applyEnvironment();
    this.build(); await this.refresh();
    const auto = new URLSearchParams(location.search).get('play');
    if (auto){ const g = this.games.find(x => x.id === auto); if (g) this.play(g); }
  },
  build(){
    const el = h('div', {id: 'launcher'},
      h('header', {class: 'ln-top'},
        h('div', {class: 'ln-brand'}, h('span', {class: 'brand-mark'}), 'Kiln', h('span', null, 'Launcher')),
        h('div', {class: 'ln-actions'},
          h('button', {class: 'ln-primary', onclick: () => $('#lnZip').click()}, '+ Add game (.zip)'),
          h('button', {onclick: () => $('#lnFolder').click()}, 'Add folder'),
          h('a', {class: 'ln-link', href: 'index.html'}, 'Open editor →'))),
      h('main', {class: 'ln-main'}, h('div', {class: 'ln-grid', id: 'lnGrid'})),
      h('div', {id: 'lnLoading', hidden: true}, h('div', {class: 'ln-spin'}), h('div', {id: 'lnLoadText'}, 'Loading…')),
      h('input', {type: 'file', id: 'lnZip', accept: '.zip', multiple: true, hidden: true, onchange: e => this.addFiles(e.target.files)}),
      h('input', {type: 'file', id: 'lnFolder', webkitdirectory: true, multiple: true, hidden: true, onchange: e => this.addFolder(e.target.files)}));
    document.body.append(el);
    el.addEventListener('dragover', e => { e.preventDefault(); el.classList.add('drop'); });
    el.addEventListener('dragleave', e => { if (!el.contains(e.relatedTarget)) el.classList.remove('drop'); });
    el.addEventListener('drop', e => { e.preventDefault(); el.classList.remove('drop'); this.addFiles(e.dataTransfer.files); });
  },
  async refresh(){
    this.games = (await LibDB.all()).sort((a, b) => (b.played || b.added) - (a.played || a.added));
    const grid = $('#lnGrid'); grid.innerHTML = '';
    if (!this.games.length) grid.append(h('div', {class: 'ln-empty'},
      h('h2', null, 'No games yet'),
      h('p', null, 'In the Kiln editor press ', h('b', null, 'Export .zip'), ' (or ', h('b', null, '▶ Launcher'), '), then drop the zip here. The game starts with the resolution and FPS saved in its config.json.')));
    for (const g of this.games) grid.append(this.card(g));
  },
  label(c){ const r = (RESOLUTIONS.find(x => x[0] === (+c.resolution || 0)) || [0, 'Native'])[1].split(' ')[0]; return [r === 'Native' ? 'Native res' : r, c.fps ? c.fps + ' FPS' : 'Unlimited FPS', c.fullscreen ? 'Fullscreen' : 'Window', c.pixelated ? 'Pixelated' : null].filter(Boolean); },
  card(g){
    const c = g.config || {};
    const art = h('div', {class: 'ln-art'}, g.thumb ? h('img', {src: g.thumb, alt: ''}) : h('div', {class: 'ln-ph'}, g.name.slice(0, 1)));
    const opts = h('div', {class: 'ln-opts', hidden: true},
      UI.row('Resolution', UI.sel(RESOLUTIONS, +c.resolution || 0, v => { c.resolution = +v; this.save(g); })),
      UI.row('FPS limit', UI.sel(FPS_CAPS, +c.fps || 0, v => { c.fps = +v; this.save(g); })),
      UI.row('Fullscreen', UI.chk(c.fullscreen, v => { c.fullscreen = v; this.save(g); })),
      UI.row('Pixelated', UI.chk(c.pixelated, v => { c.pixelated = v; this.save(g); })),
      UI.row('Mouse speed', UI.num(c.mouseSensitivity || 1, null, v => { c.mouseSensitivity = v; this.save(g); }, .1)),
      h('div', {class: 'ln-opt-actions'},
        Object.keys(g.saves || {}).length ? Editor.armedButton('Delete saves', async () => { g.saves = {}; await LibDB.put(g); this.refresh(); }) : null,
        Editor.armedButton('Remove game', async () => { await LibDB.del(g.id); this.refresh(); })));
    const nSaves = Object.keys(g.saves || {}).length;
    return h('article', {class: 'ln-card'}, art,
      h('div', {class: 'ln-body'},
        h('h3', null, g.name),
        h('div', {class: 'ln-chips'}, ...this.label(c).map(x => h('span', null, x))),
        h('div', {class: 'ln-meta'}, (g.played ? 'Last played ' + new Date(g.played).toLocaleDateString() : 'Never played') + (nSaves ? ` · ${nSaves} save${nSaves > 1 ? 's' : ''}` : '')),
        h('div', {class: 'ln-btns'}, h('button', {class: 'ln-play', onclick: () => this.play(g)}, '▶ Play'),
          h('button', {title: 'Settings', onclick: () => { opts.hidden = !opts.hidden; }}, '⚙'))),
      opts);
  },
  async save(g){ await LibDB.put(g); const cards = [...document.querySelectorAll('.ln-card')]; const i = this.games.indexOf(g);
    if (cards[i]){ const chips = cards[i].querySelector('.ln-chips'); chips.innerHTML = ''; this.label(g.config).forEach(x => chips.append(h('span', null, x))); } },
  loading(msg){ $('#lnLoading').hidden = !msg; if (msg) $('#lnLoadText').textContent = msg; },
  async addFiles(files){
    for (const f of files){ if (!/\.zip$/i.test(f.name)) continue;
      try { this.loading('Adding ' + f.name + '…'); await addGameToLibrary(f, f.name); } catch(e){ this.loading(''); this.note(e.message); } }
    this.loading(''); $('#lnZip').value = ''; this.refresh();
  },
  async addFolder(files){
    try { this.loading('Packing folder…'); const zip = new JSZip();
      for (const f of files) zip.file(f.webkitRelativePath || f.name, f);
      const blob = await zip.generateAsync({type: 'blob'}); await addGameToLibrary(blob, (files[0].webkitRelativePath || 'Game').split('/')[0]);
    } catch(e){ this.note(e.message); }
    this.loading(''); $('#lnFolder').value = ''; this.refresh();
  },
  note(msg){ const n = h('div', {class: 'ln-note'}, msg); $('#launcher').append(n); setTimeout(() => n.remove(), 4000); },

  async play(g){
    this.cur = g; const c = g.config || {};
    if (c.fullscreen && !document.fullscreenElement) try { await document.documentElement.requestFullscreen(); } catch(_){}
    this.loading('Loading ' + g.name + '…');
    try {
      const project = await ProjectIO.importZip(g.zip);
      applyConfig(project, c);
      project.saves = Object.assign(project.saves || {}, g.saves || {});
      Editor.load(project);
      $('#launcher').hidden = true; this.loading('');
      $('#app').classList.add('playing'); $('#stopFloat').hidden = true;
      setTimeout(() => { W.resize(); Runtime.start(); this.thumbAt = performance.now() + 2500; }, 30);
      g.played = Date.now(); LibDB.put(g);
      history.replaceState(null, '', '?play=' + g.id);
    } catch(e){ this.loading(''); this.note('Could not start: ' + e.message); console.error(e); }
  },
  /* grab a screenshot for the library card (called right after a frame is drawn) */
  afterRender(){
    if (!this.thumbAt || performance.now() < this.thumbAt || !this.cur) return; this.thumbAt = 0;
    try { const src = W.renderer.domElement, c = document.createElement('canvas'); c.width = 480; c.height = 270;
      const k = Math.max(480 / src.width, 270 / src.height), w = src.width * k, hh = src.height * k;
      c.getContext('2d').drawImage(src, (480 - w) / 2, (270 - hh) / 2, w, hh); this.cur.thumb = c.toDataURL('image/jpeg', .8); LibDB.put(this.cur); } catch(_){}
  },
  quit(){
    Runtime.stop(); $('#app').classList.remove('playing'); $('#launcher').hidden = false; this.cur = null;
    if (document.fullscreenElement) document.exitFullscreen().catch(() => {});
    history.replaceState(null, '', location.pathname); this.refresh();
  },
};
