/* ---------- Boot + main loop ---------- */
(async function boot(){
  W.init(document.getElementById('viewport'));
  Editor.init(); Gameplay.init();
  let restored = false;
  if (window.KILN_LAUNCHER){ Launcher.init(); restored = true; }
  else try {
    const st = await Store.loadProject();
    if (st && st.json){ for (const [p, b] of st.files) VFS.add(p, b, true); VFS.dirty.clear(); VFS.removed.clear(); VFS.emit(); Editor.load(st.json); restored = true; log('Restored "' + (P.name || 'project') + '" from this browser', 'ok'); }
  } catch(e){ console.warn(e); }
  if (!restored){ loadDemoAssets(); Editor.load(makeDemo()); Editor.persist('full'); log('Loaded the demo project. Press ▶ Play to try it.', 'ok'); }
  Editor.orbit.target.set(0, 1, -2); W.camera.position.set(14, 11, 16);

  let last = performance.now(), frames = 0, acc = 0;
  const fpsEl = document.getElementById('fps'), gfps = document.getElementById('gfps');
  function frame(now){
    requestAnimationFrame(frame);
    const cap = Runtime.active ? +Runtime.S.fpsCap || 0 : 0;
    if (cap > 0 && now - last < 1000 / cap - 2) return;     // FPS limit: skip this screen refresh
    const dt = Math.min(0.05, (now - last) / 1000); last = now;
    try {
      if (Runtime.active){ Runtime.update(dt); W.renderer.render(W.scene, Runtime.camera); Items.renderVM(Runtime.camera); if (window.KILN_LAUNCHER) Launcher.afterRender(); }
      else { Editor.update(dt); Items.editorUpdate(dt); W.renderer.render(W.scene, W.camera); if (Items.previewDef) Items.renderVM(W.camera); }
    } catch(e){ console.error(e); if (!frame._err){ frame._err = true; log('Error: ' + e.message, 'err'); setTimeout(() => frame._err = false, 3000); } }
    frames++; acc += now - (frame._t || now); frame._t = now;
    if (acc >= 500){ const f = Math.round(frames * 1000 / acc); fpsEl.textContent = f + ' fps'; gfps.textContent = f + ' FPS'; frames = 0; acc = 0; }
  }
  requestAnimationFrame(frame);
  window.addEventListener('beforeunload', () => { if (Editor.unsaved) Editor.persist(); });
})();
