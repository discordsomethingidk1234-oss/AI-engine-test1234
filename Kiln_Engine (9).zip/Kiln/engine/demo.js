/* ---------- Demo project: shows interaction blocks, timelines, teleport, cutscene, enemies ---------- */
function loadDemoAssets(){
  for (const p in window.DEMO_ASSETS || {}){
    const bin = atob(window.DEMO_ASSETS[p]); const u = new Uint8Array(bin.length); for (let i = 0; i < bin.length; i++) u[i] = bin.charCodeAt(i);
    VFS.add(p, new Blob([u]), true);
  }
  VFS.emit();
}
function makeDemo(){
  const T = 'assets/textures/', S = 'assets/sfx/';
  const O = (type, over) => newObject(type, over);
  const act = (type, t, p) => Object.assign({id: uid('a'), type, t}, actionDefaults(type), p || {});
  const title = (t, text, preset, dur, extra) => act('showTitle', t, Object.assign({text, preset, duration: dur, style: clone(TEXT_PRESETS[preset])}, extra || {}));
  const E = {}; const ev = (key, name, actions) => (E[key] = {id: uid('ev'), name, actions});

  ev('intro', 'Intro', [act('fadeOut', 0, {duration: .01}), act('fadeIn', .3, {duration: 1.6}),
    title(.5, 'Kiln Demo', 'Cinematic', 5, {subtitle: 'WASD move · mouse look · click the lever and chest · walk onto the glowing pad'})]);
  ev('door', 'Open the door', [act('playSound', 0, {sound: S + 'door.wav'}), act('rotate', 0, {target: 'sigma', mode: 'by', x: 0, y: 90, z: 0, duration: 1.2}),
    act('showDialogue', .2, {text: 'The vault door grinds open.', duration: 2.5, typeSpeed: 40}), act('setCollision', 1.2, {target: 'sigma', on: false})]);
  ev('chest', 'Loot chest', [act('giveItem', 0, {item: 'Blaster', from: 'loot', equip: true}), act('giveItem', .7, {item: 'Rusty Key', animate: false}),
    act('setVisible', .1, {target: 'loot', visible: false, alsoCollision: true}),
    act('showDialogue', .2, {text: 'A rusty key. Maybe it opens something in section B.', duration: 3.5, typeSpeed: 45})]);
  ev('tpB', 'Teleport to section B', [act('lockPlayer', 0, {on: true}), act('playSound', 0, {sound: S + 'teleport.wav'}), act('fadeOut', 0, {duration: .5, color: '#000000'}),
    act('teleport', .6, {x: 40, y: .1, z: 6, setYaw: true, yaw: 0}), act('playSound', .7, {sound: S + 'tts_3.wav', channel: 'voice'}),
    act('fadeIn', .8, {duration: 1.2}), title(1, 'You are teleported to section B', 'Cinematic', 3.5), act('lockPlayer', 1, {on: false})]);
  ev('tpA', 'Return to section A', [act('playSound', 0, {sound: S + 'teleport.wav'}), act('fadeOut', 0, {duration: .4}),
    act('teleport', .5, {x: 0, y: .1, z: -6.5, setYaw: true, yaw: 180}), act('fadeIn', .6, {duration: .8}), title(.7, 'Back in section A', 'Typewriter', 2.5)]);
  ev('guide', 'Guide cutscene', [act('lockPlayer', 0, {on: true}), act('npcFacePlayer', 0, {target: 'guide'}),
    act('cameraLock', 0, {x: 42.2, y: 2.1, z: -2.6, lookAt: 'guide', follow: true, blend: .8}),
    act('playSound', .4, {sound: S + 'speech.wav', channel: 'voice'}),
    act('showDialogue', .5, {speaker: 'Guide', text: 'Welcome to section B. Grunts gather near the red stone.', duration: 4, typeSpeed: 40}),
    act('showDialogue', 4.7, {speaker: 'Guide', text: 'Click the stone if you want a fight. I will keep my distance.', duration: 4, typeSpeed: 40}),
    act('npcMoveTo', 6, {target: 'guide', x: 43.5, y: 0, z: -9, speed: 1.6}),
    act('showDialogue', 8.8, {speaker: 'Guide', text: 'Here, take my map.', duration: 2, typeSpeed: 40}),
    act('cameraRelease', 10, {blend: .8}), act('lockPlayer', 10, {on: false}), act('giveItem', 10, {item: "Guide's Map"})]);
  ev('wave', 'Spawn wave', [title(0, 'HERE THEY COME', 'GeometryDash', 2), act('cameraShake', 0, {intensity: .25, duration: .6}),
    act('playSound', .2, {sound: S + 'teleport.wav', volume: .7}), act('spawnEnemy', .3, {template: 'grunt', count: 3, atTemplate: true, spread: 3})]);
  ev('kill', 'First kill', [act('giveItem', 0, {item: 'Grunt Tooth'}), act('showDialogue', 0, {text: 'First grunt down.', duration: 2})]);
  ev('burn', 'Burn', [act('damagePlayer', 0, {amount: 10}), act('cameraShake', 0, {intensity: .15, duration: .3}), act('showDialogue', 0, {text: 'Ouch. That plate is hot.', duration: 1.5, typeSpeed: 0})]);
  ev('gate', 'Open gate', [act('playSound', 0, {sound: S + 'door.wav'}), act('move', 0, {target: 'gate', mode: 'by', x: 0, y: -3.2, z: 0, duration: 1.6}),
    title(.2, 'Gate unlocked', 'Retro', 2)]);
  ev('tip', 'Save tip', [act('showDialogue', 0, {speaker: 'Tip', text: 'Press F5 to quick save, F9 to load, P for the pause menu.', duration: 4, typeSpeed: 50})]);

  const brick = {texture: T + 'brick.png', color: '#ffffff', texRepeat: [3, 1]}, metal = {texture: T + 'metal.png', color: '#ffffff'};
  const objects = [
    O('plane', {name: 'Ground A', texture: T + 'grass.png', color: '#ffffff', scale: [40, 1, 40], texRepeat: [12, 12]}),
    O('spawn', {name: 'Player spawn', pos: [0, 0, 10]}),
    O('box', Object.assign({name: 'Wall left', pos: [-4.5, 1.5, -4], scale: [7, 3, .5]}, brick)),
    O('box', Object.assign({name: 'Wall right', pos: [4.5, 1.5, -4], scale: [7, 3, .5]}, brick)),
    O('box', Object.assign({name: 'Lintel', pos: [0, 2.75, -4], scale: [2, .5, .5]}, brick, {texRepeat: [1, .3]})),
    O('box', {name: 'Door', tags: ['sigma'], pos: [0, 1.25, -4], scale: [2, 2.5, .3], texture: T + 'wood.jpg', color: '#ffffff'}),
    O('text3d', {name: 'Vault sign', text: 'THE VAULT', pos: [0, 3.5, -3.7], scale: [3.4, 1, 1], textColor: '#ffd58a'}),
    O('box', Object.assign({name: 'Lever panel', pos: [1.8, 1.3, -3.66], scale: [.4, .6, .15], collide: false}, metal)),
    O('interaction', {name: 'Door switch', pos: [1.8, 1.3, -3.4], scale: [.9, 1.1, .8],
      interact: {mode: 'left', event: E.door.id, once: true, cooldown: .5, requireItem: '', consumeItem: false, prompt: 'Pull lever', enabled: true, sound: S + 'click.wav'}}),
    O('box', Object.assign({name: 'Room left', pos: [-6, 1.5, -9], scale: [.5, 3, 10]}, brick, {texRepeat: [4, 1]})),
    O('box', Object.assign({name: 'Room right', pos: [6, 1.5, -9], scale: [.5, 3, 10]}, brick, {texRepeat: [4, 1]})),
    O('box', Object.assign({name: 'Room back', pos: [0, 1.5, -14], scale: [12.5, 3, .5]}, brick, {texRepeat: [5, 1]})),
    O('light', {name: 'Room light', pos: [0, 2.6, -9], intensity: 2, distance: 12, color: '#ffcf8a'}),
    O('cylinder', Object.assign({name: 'Teleport pad', pos: [0, .05, -10], scale: [2.4, .1, 2.4], emissive: '#0d2a38'}, metal)),
    O('decal', {name: 'Pad rune', pos: [0, .12, -10], rot: [-90, 0, 0], scale: [2.2, 2.2, 1], texture: T + 'teleport_rune.png', emissive: '#1b6d8a'}),
    O('interaction', {name: 'Teleporter', pos: [0, 1, -10], scale: [2, 2, 2],
      interact: {mode: 'touch', event: E.tpB.id, once: false, cooldown: 2, requireItem: '', consumeItem: false, prompt: '', enabled: true, sound: ''}}),
    O('text3d', {name: 'Pad sign', text: 'TELEPORTER\nsection B', pos: [0, 2.3, -13.7], scale: [2.6, 1, 1], font: 'Orbitron', textColor: '#7ff6ff', fontSize: 80}),
    O('box', {name: 'Chest', tags: ['loot'], pos: [-4, .4, 3], scale: [1.2, .8, .8], texture: T + 'wood.jpg', color: '#d8b38a'}),
    O('interaction', {name: 'Chest lid', pos: [-4, .5, 3], scale: [1.6, 1.2, 1.2],
      interact: {mode: 'right', event: E.chest.id, once: true, cooldown: .5, requireItem: '', consumeItem: false, prompt: 'Open chest (right click)', enabled: true, sound: ''}}),
    O('box', {name: 'Hot plate', tags: ['hazard'], pos: [5, .15, 4], scale: [2, .3, 2], color: '#ff5a33', emissive: '#a32000'}),
    O('ramp', Object.assign({name: 'Ramp', pos: [-7, .75, 8], scale: [2, 1.5, 4]}, metal)),
    O('box', Object.assign({name: 'Platform', pos: [-7, .75, 4.5], scale: [3, 1.5, 3]}, metal)),
    O('box', {name: 'Crate', pos: [-7, 1.9, 4.2], scale: [.8, .8, .8], texture: T + 'checker.png', color: '#ffffff', pickable: true}),
    O('box', {name: 'Ice block', pos: [3, .5, 7], scale: [1, 1, 1], color: '#bfe8ff', roughness: .1, metalness: .2, slippery: true}),
    O('box', {name: 'Pickup crate', pos: [-2, .4, 7], scale: [.6, .6, .6], texture: T + 'wood.jpg', color: '#ffffff', pickable: true}),

    O('plane', {name: 'Ground B', pos: [40, 0, 0], scale: [26, 1, 26], texture: T + 'checker.png', color: '#ffffff', texRepeat: [10, 10]}),
    O('text3d', {name: 'Section B sign', text: 'SECTION B', pos: [40, 3.5, -12], scale: [5, 1, 1], font: 'Geometry Dash', textColor: '#ffffff'}),
    O('enemy', {name: 'Guide', tags: ['guide'], pos: [40, 0, -6], rot: [0, 180, 0], color: '#4c8fd6',
      enemy: Object.assign(newObject('enemy').enemy, {hostile: false, showHealthBar: false, aggroRange: 0, motion: 'walk-cycle'})}),
    O('interaction', {name: 'Talk to guide', pos: [40, 1.1, -6], scale: [1.4, 2.2, 1.4],
      interact: {mode: 'key', event: E.guide.id, once: true, cooldown: 1, requireItem: '', consumeItem: false, prompt: 'Talk', enabled: true, sound: ''}}),
    O('enemy', {name: 'Grunt', tags: ['grunt'], pos: [46, 0, 4], color: '#7a9a52',
      enemy: Object.assign(newObject('enemy').enemy, {hostile: true, health: 60, speed: 2.6, damage: 8, spawnOnStart: false, motion: 'zombie',
        hurtSound: S + 'hurt.wav', deathSound: S + 'enemy_die.wav', joints: {head: [10, 0, 8]}})}),
    O('cylinder', {name: 'Summon stone', pos: [46, 1, -2], scale: [.8, 2, .8], color: '#8a2a2a', emissive: '#401010'}),
    O('interaction', {name: 'Summon', pos: [46, 1.1, -2], scale: [1.4, 2.4, 1.4],
      interact: {mode: 'left', event: E.wave.id, once: false, cooldown: 6, requireItem: '', consumeItem: false, prompt: 'Summon grunts', enabled: true, sound: S + 'click.wav'}}),
    O('box', Object.assign({name: 'Gate', tags: ['gate'], pos: [33, 1.5, 0], scale: [.4, 3, 4]}, metal)),
    O('interaction', {name: 'Gate lock', pos: [33.6, 1.2, 0], scale: [.9, 1.8, 4.2],
      interact: {mode: 'left', event: E.gate.id, once: true, cooldown: .5, requireItem: 'Rusty Key', consumeItem: true, prompt: 'Unlock gate', enabled: true, sound: ''}}),
    O('text3d', {name: 'Secret sign', text: 'You found\nthe secret', pos: [30.5, 2, 0], rot: [0, 90, 0], scale: [2.4, 1, 1], font: 'Special Elite', textColor: '#ffe9b8'}),
    O('cylinder', Object.assign({name: 'Return pad', pos: [40, .05, 10], scale: [2.4, .1, 2.4], emissive: '#0d2a38'}, metal)),
    O('decal', {name: 'Return rune', pos: [40, .12, 10], rot: [-90, 0, 0], scale: [2.2, 2.2, 1], texture: T + 'teleport_rune.png', emissive: '#1b6d8a'}),
    O('interaction', {name: 'Return teleporter', pos: [40, 1, 10], scale: [2, 2, 2],
      interact: {mode: 'touch', event: E.tpA.id, once: false, cooldown: 2, requireItem: '', consumeItem: false, prompt: '', enabled: true, sound: ''}}),
  ];
  // a sword built from boxes, standing on a stone; its group is the item's model
  const swordG = O('group', {name: 'Sword (item model)', pos: [3.5, 1.05, 1.5]});
  const steel = {color: '#d9dee6', metalness: .9, roughness: .25, collide: false};
  objects.push(O('cylinder', {name: 'Sword stone', pos: [3.5, .5, 1.5], scale: [.9, 1, .9], color: '#7d7f86', roughness: 1}), swordG,
    O('box', {name: 'Grip', parent: swordG.id, pos: [0, .1, 0], scale: [.05, .2, .05], color: '#3a2a1e', collide: false}),
    O('box', {name: 'Guard', parent: swordG.id, pos: [0, .22, 0], scale: [.3, .05, .07], color: '#c9a23a', metalness: .8, collide: false}),
    O('box', Object.assign({name: 'Blade', parent: swordG.id, pos: [0, .75, 0], scale: [.07, 1, .02]}, steel)));
  const sword = Object.assign(newItemDef('Iron Sword'), {kind: 'sword', damage: 35, model: swordG.id, size: .75, desc: 'Pull it from the stone',
    hold: {pos: [.36, -.36, -.8], rot: [-25, 0, -10], scale: 1}});
  const blaster = Object.assign(newItemDef('Blaster'), {kind: 'gun', damage: 15, size: .7, desc: 'Found in the chest', hold: {pos: [.28, -.28, -.62], rot: [0, 0, 0], scale: 1}});
  Object.assign(blaster.gun, {builtin: 'rifle', magSize: 24, startAmmo: 72, auto: true, fireRate: 9, bulletSpeed: 90, bulletSize: .08, bulletColor: '#5ff0ff', reloadTime: 1.8});
  return {format: 'kiln-project-1', name: 'Kiln Demo',
    settings: Object.assign(DEFAULT_SETTINGS(), {footstepSound: S + 'footstep.wav', hurtSound: S + 'hurt.wav', sky: '#9cc0e0', fogColor: '#9cc0e0'}),
    objects, events: Object.values(E),
    triggers: [
      {id: uid('tr'), type: 'start', event: E.intro.id},
      {id: uid('tr'), type: 'touch', tag: 'hazard', event: E.burn.id, once: false},
      {id: uid('tr'), type: 'enemyKilled', tag: 'grunt', event: E.kill.id, once: true},
      {id: uid('tr'), type: 'time', time: 40, repeat: 0, event: E.tip.id, once: true},
    ],
    items: [sword, blaster, {name: 'Rusty Key', icon: '', desc: 'Opens the gate in section B'}, {name: "Guide's Map", icon: T + 'teleport_rune.png', desc: 'A gift'}, {name: 'Grunt Tooth', icon: '', desc: 'Trophy'}],
    saves: {}};
}
