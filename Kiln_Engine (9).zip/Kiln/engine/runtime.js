/* ---------- Runtime: play mode ---------- */
const V3 = THREE.Vector3;
const Runtime = {
  active:false, paused:false, camera:null, S:null, time:0,
  entries: new Map(), colliders: [], ramps: [], collidersDirty: true,
  running: [], tweens: [], enemies: [], sounds: [], channels: {}, keys: new Set(), pressed: new Set(),
  flags: {}, firedTriggers: new Set(), touching: new Set(), titleEls: [],
  camLock: null, camBlend: 0, shake: null, fade: null, ray: new THREE.Raycaster(), mouse: new THREE.Vector2(), mouseInside:false,

  /* ===== lifecycle ===== */
  start(fromSave){
    this.active = true; this.paused = false;
    this.S = clone(P.settings);
    if (!this.camera){ this.camera = new THREE.PerspectiveCamera(75, 1, 0.05, 2000); this.camera.rotation.order = 'YXZ'; }
    this.camera.fov = +this.S.fov || 75; W.resize();
    W.setEditorMode(false); W.applyEnvironment(); W.setRenderHeight(this.S.renderHeight, this.S.pixelated);
    W.buildAll();
    this.reset();
    document.getElementById('hud').hidden = false; $('#pauseMenu').hidden = true;
    $('#gfps').hidden = !this.S.showFps;
    this.bindInput(true);
    if (!fromSave) this.fireTriggers('start');
    if (this.S.music){ this.playSound({sound: this.S.music, volume: this.S.musicVolume, loop: true, channel: 'music'}); }
    log('▶ Play started', 'ok');
    this.requestLock();
  },
  reset(){
    this.time = 0; this.running = []; this.tweens = []; this.flags = {}; this.firedTriggers = new Set(); this.touching = new Set();
    this.stopAllSounds(); this.clearText(); this.camLock = null; this.camBlend = 0; this.shake = null;
    this.setFade(0, '#000'); $('#fade').classList.remove('full');
    this.entries.clear(); this.enemies = []; this.checkpoint = null; this.activeCp = null;
    for (const o of P.objects){ const root = W.roots.get(o.id); if (!root) continue;
      // things that move on their own leave their group so they live in world space
      if (o.parent && (o.type === 'enemy' || o.type === 'vehicle' || o.pickable || o.slippery)) W.scene.attach(root);
      const e = {o: clone(o), root, used:false, cool:0, hidden: o.visible === false, collide: o.collide !== false};
      this.entries.set(o.id, e);
      if (o.type === 'enemy'){ if (o.enemy.spawnOnStart) this.makeEnemy(e); else { root.visible = false; e.template = true; } }
      if (o.anim && o.type === 'model') this.playClip(e, o.anim, true);
    }
    const sp = P.objects.find(o => o.type === 'spawn');
    const pl = this.player = {pos: new V3(0, 1, 6), vel: new V3(), yaw: 0, pitch: 0, onGround: false, hp: +this.S.maxHealth, inv: {}, locked: false,
      stepT: 0, atkT: 0, dead: false, r: +this.S.playerRadius, h: +this.S.playerHeight, hurtT: 0};
    if (sp){ pl.pos.fromArray(sp.pos); pl.yaw = sp.rot[1] * D2R; }
    this.spawnPoint = {pos: pl.pos.clone(), yaw: pl.yaw};
    this.makePlayerBody();
    this.held = null; this.aimedId = null;
    for (const e of this.entries.values()) if ((e.o.pickable || e.o.slippery) && this.solidType(e.o.type) && e.o.type !== 'plane' && e.o.type !== 'ramp')
      e.dyn = {vel: new V3(), onGround: false, home: e.root.position.clone()};
    this.collidersDirty = true; this.updateHud(true);
    Gameplay.reset();
  },
  stop(){
    if (!this.active) return;
    this.active = false; Gameplay.stop(); this.bindInput(false); this.stopAllSounds(); this.clearText();
    if (document.pointerLockElement) document.exitPointerLock();
    document.getElementById('hud').hidden = true;
    if (this.playerBody){ W.scene.remove(this.playerBody); this.playerBody = null; }
    W.setEditorMode(true); W.setRenderHeight(0, false); W.buildAll();
    log('■ Play stopped');
  },

  /* ===== input ===== */
  bindInput(on){
    const f = on ? 'addEventListener' : 'removeEventListener', c = W.renderer.domElement;
    if (!this._h) this._h = {
      kd: e => this.onKey(e, true), ku: e => this.onKey(e, false),
      mm: e => this.onMouseMove(e), md: e => this.onMouseDown(e), cm: e => { if (this.active) e.preventDefault(); },
      pl: () => { $('#clickToPlay').hidden = !!document.pointerLockElement || this.paused; },
      ml: () => { this.mouseInside = false; }, me: () => { this.mouseInside = true; },
    };
    const h = this._h;
    if (!h.wh) h.wh = e => { if (!this.active || this.paused || (this.player && this.player.inCar)) return; e.preventDefault(); Items.wheel(e.deltaY); };
    c[f]('wheel', h.wh, {passive: false});
    window[f]('keydown', h.kd); window[f]('keyup', h.ku); window[f]('mousemove', h.mm);
    c[f]('mousedown', h.md); c[f]('contextmenu', h.cm); c[f]('mouseleave', h.ml); c[f]('mouseenter', h.me);
    document[f]('pointerlockchange', h.pl);
    this.keys.clear();
  },
  requestLock(){
    const c = W.renderer.domElement;
    try { const p = c.requestPointerLock(); if (p && p.catch) p.catch(() => {}); } catch(e){}
    $('#clickToPlay').hidden = !!document.pointerLockElement;
  },
  onKey(e, down){
    if (!this.active) return;
    if (/^(INPUT|TEXTAREA|SELECT)$/.test(e.target.tagName)) return;
    const K = this.S.keys;
    if (down){
      if (e.code === 'Escape' && !document.pointerLockElement && !this.paused){ this.togglePause(true); return; }
      if (e.repeat) return;
      if (e.code === K.pause){ this.togglePause(); e.preventDefault(); return; }
      if (e.code === K.quickSave){ e.preventDefault(); this.saveGame('quick'); return; }
      if (e.code === K.quickLoad){ e.preventDefault(); this.loadGame('quick'); return; }
      this.keys.add(e.code); this.pressed.add(e.code);
      Gameplay.keyDown(e.code);
      if (e.code === K.interact && !Gameplay.onInteract() && !Items.tryPickup()) this.tryInteract('key');
      for (const t of P.triggers) if (t.type === 'key' && t.key === e.code) this.fireTrigger(t);
      if (['Space','ArrowUp','ArrowDown','ArrowLeft','ArrowRight','Tab'].includes(e.code)) e.preventDefault();
    } else this.keys.delete(e.code);
  },
  onMouseMove(e){
    if (!this.active || this.paused) return;
    const c = W.renderer.domElement.getBoundingClientRect();
    this.mouse.set(((e.clientX - c.left) / c.width) * 2 - 1, -((e.clientY - c.top) / c.height) * 2 + 1);
    if (document.pointerLockElement && !this.player.locked){
      const s = 0.0022 * (+this.S.mouseSensitivity || 1);
      this.player.yaw -= e.movementX * s; this.player.pitch -= e.movementY * s * (this.S.invertY ? -1 : 1);
      this.player.pitch = Math.max(-1.5, Math.min(1.5, this.player.pitch));
    }
  },
  onMouseDown(e){
    if (!this.active || this.paused) return;
    if (!document.pointerLockElement){ this.requestLock(); if (e.button === 0 && !this.lockFailedOnce){ this.lockFailedOnce = true; } }
    const btn = e.button === 2 ? 'right' : e.button === 0 ? 'left' : null; if (!btn) return;
    const r = this.pick(); this.lastPick = r;
    if (r.aim && r.aim.e) for (const t of P.triggers) if (t.type === (btn === 'left' ? 'clickLeft' : 'clickRight') && this.trigMatch(t, r.aim.e, r.aim.d)) this.fireTrigger(t, r.aim.e);
    if (Gameplay.mouseDown(btn)) return;
    if (btn === 'left' && Items.tryPickup()) return;
    if (this.tryInteract(btn)) return;
    if (Items.use(btn)) return;
    if (btn === 'left') this.attack();
  },
  togglePause(force){
    this.paused = force != null ? force : !this.paused; $('#pauseMenu').hidden = !this.paused;
    if (this.paused && document.pointerLockElement) document.exitPointerLock();
    if (!this.paused) this.requestLock();
    for (const s of this.sounds) try { this.paused ? s.a.pause() : s.a.play(); } catch(e){}
  },

  /* ===== main update ===== */
  update(dt){
    if (this.paused) return;
    this.time += dt;
    if (this.collidersDirty) this.buildColliders();
    this.updateDynamics(dt);
    this.updatePlayer(dt);
    Gameplay.update(dt); Items.update(dt);
    this.updateTriggers();
    this.updateEvents(dt);
    this.updateTweens(dt);
    this.updateEnemies(dt);
    this.updateEntries(dt);
    this.updateCamera(dt);
    Gameplay.camera(dt); Items.camera();
    this.updateHold(dt);
    this.updateLook();
    this.updateSounds(dt);
    this.updateFade(dt);
    this.pressed.clear();
  },

  /* ===== colliders ===== */
  solidType(t){ return !['interaction','spawn','light','enemy','decal','text3d','weapon','ammo','checkpoint','group'].includes(t); },
  buildColliders(){
    this.colliders = []; this.ramps = [];
    for (const e of this.entries.values()){
      if (e.dead || e.hidden || !e.collide || !this.solidType(e.o.type) || !visibleChain(e.root) || !inScene(e.root)) continue;
      e.root.updateMatrixWorld(true);
      if (e.o.type === 'ramp'){ this.ramps.push(e); continue; }
      const b = boxOf(e.root); if (b.isEmpty()) continue;
      if (b.max.y - b.min.y < 0.2) b.min.y = b.max.y - 0.2;
      e.box = b; this.colliders.push(e);
      if (e.dyn){ e.dynOff = b.min.clone().sub(e.root.position); e.dynSize = b.getSize(new V3()); }
    }
    this.collidersDirty = false;
  },
  refreshMoving(){ for (const e of this.colliders) if (e.moving){ e.root.updateMatrixWorld(true); e.box = boxOf(e.root); if (e.box.max.y - e.box.min.y < .2) e.box.min.y = e.box.max.y - .2; } },

  /* Generic AABB body mover used by player and enemies */
  moveBody(b, dt){
    const steps = Math.max(1, Math.ceil(Math.max(Math.abs(b.vel.x), Math.abs(b.vel.y), Math.abs(b.vel.z)) * dt / 0.2));
    const h = dt / steps; const wasGround = b.onGround; b.onGround = false;
    for (let i = 0; i < steps; i++){
      this.moveAxis(b, 'x', b.vel.x * h, wasGround); this.moveAxis(b, 'z', b.vel.z * h, wasGround); this.moveAxis(b, 'y', b.vel.y * h);
    }
    this.rampGround(b);
  },
  moveAxis(b, ax, d, grounded){
    if (!d) return;
    b.pos[ax] += d;
    const r = b.r, hgt = b.h, step = +this.S.stepHeight || .4;
    for (const e of this.colliders){ if (e.held) continue; const B = e.box;
      if (b.pos.x + r <= B.min.x || b.pos.x - r >= B.max.x || b.pos.z + r <= B.min.z || b.pos.z - r >= B.max.z || b.pos.y + hgt <= B.min.y || b.pos.y >= B.max.y) continue;
      if (ax === 'y'){ if (d < 0){ b.pos.y = B.max.y; b.onGround = true; } else b.pos.y = B.min.y - hgt; b.vel.y = 0; }
      else {
        const rise = B.max.y - b.pos.y;
        if (rise <= (grounded ? step : 0.08) && !this.blockedAbove(b, B.max.y)){ b.pos.y = B.max.y + 0.001; b.onGround = true; continue; }
        if (e.dyn && e.o.slippery){ const sp = Math.max(Math.abs(b.vel[ax]), 1.5) * Math.sign(d); e.dyn.vel[ax] = sp * 1.05; }
        b.pos[ax] = d > 0 ? B.min[ax] - r - 1e-4 : B.max[ax] + r + 1e-4;
        b.hitWall = true;
      }
    }
  },
  blockedAbove(b, y){ for (const e of this.colliders){ if (e.held) continue; const B = e.box; if (b.pos.x + b.r > B.min.x && b.pos.x - b.r < B.max.x && b.pos.z + b.r > B.min.z && b.pos.z - b.r < B.max.z && y + b.h > B.min.y && y < B.min.y) return true; } return false; },
  rampGround(b){
    for (const e of this.ramps){
      const inv = e.invM || (e.invM = new THREE.Matrix4()); inv.copy(e.root.matrixWorld).invert();
      const lp = b.pos.clone().applyMatrix4(inv);
      if (lp.x < -.5 || lp.x > .5 || lp.z < -.5 || lp.z > .5) continue;
      const surf = new V3(lp.x, -lp.z, lp.z).applyMatrix4(e.root.matrixWorld).y;
      if (b.pos.y <= surf + .35 && b.pos.y >= surf - .9 && b.vel.y <= 0.01){ b.pos.y = surf; b.vel.y = 0; b.onGround = true; }
    }
  },

  /* ===== player ===== */
  makePlayerBody(){
    if (this.playerBody) W.scene.remove(this.playerBody);
    const g = new THREE.Group(); const m = new THREE.MeshStandardMaterial({color: 0x4cc3e0, roughness: .6});
    const body = new THREE.Mesh(new THREE.CylinderGeometry(this.player.r, this.player.r, this.player.h - this.player.r * 2, 16), m); body.position.y = this.player.h / 2;
    const top = new THREE.Mesh(new THREE.SphereGeometry(this.player.r, 16, 10), m); top.position.y = this.player.h - this.player.r;
    const bot = top.clone(); bot.position.y = this.player.r;
    const visor = new THREE.Mesh(new THREE.BoxGeometry(.3, .1, .1), new THREE.MeshBasicMaterial({color: 0x10202a})); visor.position.set(0, this.player.h - .3, -this.player.r);
    g.add(body, top, bot, visor); g.traverse(x => x.castShadow = true);
    this.playerBody = g; W.scene.add(g); g.visible = this.S.camera === 'third';
  },
  updatePlayer(dt){
    const pl = this.player, S = this.S, K = S.keys;
    this.refreshMoving();
    if (pl.dead){ pl.vel.x = pl.vel.z = 0; }
    const free = !pl.locked && !pl.dead;
    // keyboard look
    const lk = 1.8 * dt * (+S.mouseSensitivity || 1);
    if (free){ if (this.keys.has(K.lookLeft)) pl.yaw += lk; if (this.keys.has(K.lookRight)) pl.yaw -= lk;
      if (this.keys.has(K.lookUp)) pl.pitch = Math.min(1.5, pl.pitch + lk); if (this.keys.has(K.lookDown)) pl.pitch = Math.max(-1.5, pl.pitch - lk); }
    const run = this.keys.has(K.run) || (K.run === 'ShiftLeft' && this.keys.has('ShiftRight'));
    if (!pl.inCar){
    let f = 0, s = 0;
    if (free){ if (this.keys.has(K.forward)) f++; if (this.keys.has(K.back)) f--; if (this.keys.has(K.right)) s++; if (this.keys.has(K.left)) s--; }
    const spd = run ? +S.runSpeed : +S.walkSpeed;
    const len = Math.hypot(f, s);
    const fx = -Math.sin(pl.yaw), fz = -Math.cos(pl.yaw), rx = Math.cos(pl.yaw), rz = -Math.sin(pl.yaw);
    const wx = len ? (fx * f + rx * s) / len : 0, wz = len ? (fz * f + rz * s) / len : 0;
    const hs = Math.hypot(pl.vel.x, pl.vel.z), bhop = S.bhop !== false, mx = +S.bhopMax || 22;
    const jumpNow = free && (this.pressed.has(K.jump) || (bhop && this.keys.has(K.jump)));
    if (pl.onGround && jumpNow){
      // bunny hop: jumping again on the landing frame keeps (and slightly grows) your speed — no ground friction
      if (bhop && hs > spd * .9){ const k2 = Math.min(mx, hs * (+S.bhopGain || 1.06)) / hs; pl.vel.x *= k2; pl.vel.z *= k2; }
      else { pl.vel.x = wx * spd; pl.vel.z = wz * spd; }
      pl.vel.y = +S.jumpForce; pl.onGround = false;
    } else if (pl.onGround){ const a = Math.min(1, dt * 14); pl.vel.x += (wx * spd - pl.vel.x) * a; pl.vel.z += (wz * spd - pl.vel.z) * a; }
    else if (len){   // air strafing (strafe + turn the mouse to gain speed)
      const ac = +S.airControl || .6, cur = pl.vel.x * wx + pl.vel.z * wz, cap = Math.max(1.2, spd * .5 * ac);
      const add = cap - cur; if (add > 0){ const g = Math.min(add, 40 * ac * dt * spd / 4); pl.vel.x += wx * g; pl.vel.z += wz * g; }
      const h2 = Math.hypot(pl.vel.x, pl.vel.z); if (h2 > mx){ pl.vel.x *= mx / h2; pl.vel.z *= mx / h2; }
    }
    pl.vel.y -= (+S.gravity) * dt; if (pl.vel.y < -60) pl.vel.y = -60;
    this.moveBody(pl, dt);
    }
    // footsteps
    if (S.footstepSound && pl.onGround && !pl.inCar && Math.hypot(pl.vel.x, pl.vel.z) > 1){
      pl.stepT += dt * (run ? 1.45 : 1); if (pl.stepT > (+S.footstepInterval || .42)){ pl.stepT = 0; this.playSound({sound: S.footstepSound, volume: .35}); } }
    if (pl.pos.y < +S.killY) this.respawn('fell');
    if (this.playerBody){ this.playerBody.position.copy(pl.pos); this.playerBody.rotation.y = pl.yaw; }
    pl.atkT -= dt; pl.hurtT -= dt;
    // touch detection (interaction blocks + touch triggers)
    const pb = new THREE.Box3(new V3(pl.pos.x - pl.r, pl.pos.y, pl.pos.z - pl.r), new V3(pl.pos.x + pl.r, pl.pos.y + pl.h, pl.pos.z + pl.r));
    const now = new Set();
    const touchTags = P.triggers.filter(t => t.type === 'touch' && t.tag);
    for (const e of this.entries.values()){
      if (e.dead) continue;
      const isTouchBlock = e.o.type === 'interaction' && e.o.interact.mode === 'touch';
      const tagHit = touchTags.some(t => e.o.tags.includes(t.tag) || e.o.name === t.tag);
      if (!isTouchBlock && !tagHit) continue;
      if (e.hidden && e.o.type !== 'interaction') continue;
      const b = boxOf(e.root, true).expandByScalar(0.08);
      if (!b.intersectsBox(pb)) continue;
      now.add(e.o.id);
      if (!this.touching.has(e.o.id)){
        if (isTouchBlock) this.activate(e);
        for (const t of touchTags) if (e.o.tags.includes(t.tag) || e.o.name === t.tag) this.fireTrigger(t, e);
      }
    }
    this.touching = now;
  },
  respawn(why){
    if (Gameplay.car) Gameplay.exitCar();
    const pl = this.player; const cp = this.checkpoint || this.spawnPoint;
    pl.pos.copy(cp.pos); pl.yaw = cp.yaw; pl.vel.set(0,0,0); pl.hp = +this.S.maxHealth; pl.dead = false;
    this.updateHud(); if (why === 'fell') this.toast('You fell — respawned');
  },
  damagePlayer(n){
    const pl = this.player; if (pl.dead || n <= 0) return;
    pl.hp = Math.max(0, pl.hp - n); pl.hurtT = .25; this.updateHud();
    if (this.S.hurtSound) this.playSound({sound: this.S.hurtSound, volume: .8});
    this.doShake(.15, .2);
    if (pl.hp <= 0){ pl.dead = true;
      this.showTitle({text: 'YOU DIED', duration: 2.6, preset: 'Horror', style: Object.assign(clone(TEXT_PRESETS.Horror), {size: 80})});
      this.fadeTo(.85, .8, '#300000'); setTimeout(() => { if (this.active){ this.respawn(); this.fadeTo(0, .8); } }, 2600); }
  },

  /* ===== looking & interacting ===== */
  lookRay(){
    if (document.pointerLockElement || !this.mouseInside) this.ray.setFromCamera({x: 0, y: 0}, this.camera);
    else this.ray.setFromCamera(this.mouse, this.camera);
    this.ray.far = 200; return this.ray;
  },
  pick(){
    const ray = this.lookRay(); const inter = [], solids = [], enemies = [];
    for (const e of this.entries.values()){ if (e.dead) continue;
      if (e.o.type === 'interaction'){ if (e.o.interact.enabled !== false) inter.push(e.root); }
      else if (e.o.type === 'enemy'){ if (e.enemy && !e.enemy.dead && e.root.visible) enemies.push(e.root); }
      else if (!e.hidden && e.root.visible && !e.held && !['spawn','light'].includes(e.o.type)) solids.push(e.root); }
    const hitI = ray.intersectObjects(inter, true).filter(h => !h.object.isLineSegments)[0];
    const hitS = ray.intersectObjects(solids, true).filter(h => visibleChain(h.object))[0];
    const hitE = ray.intersectObjects(enemies, true)[0];
    const res = {};
    if (hitI && hitI.distance <= +this.S.interactRange + 1 && (!hitS || hitI.distance <= hitS.distance + 1.0)) res.inter = {e: this.entryOf(hitI.object), d: hitI.distance};
    if (hitE && (!hitS || hitE.distance < hitS.distance)) res.enemy = {e: this.entryOf(hitE.object), d: hitE.distance};
    if (hitS) res.solid = {e: this.entryOf(hitS.object), d: hitS.distance};
    const aim = res.enemy || res.solid; if (aim && aim.e) res.aim = aim;
    if (res.solid && res.solid.e && res.solid.e.o.pickable && res.solid.e.dyn && res.solid.d <= +this.S.interactRange && !res.enemy) res.pickable = res.solid;
    return res;
  },
  entryOf(obj){ while (obj && !obj.userData.objId) obj = obj.parent; return obj ? this.entries.get(obj.userData.objId) : null; },
  updateLook(){
    if (!this.S.showHud){ $('#prompt').textContent = ''; return; }
    const r = this.pick(); this.lastPick = r;
    const ch = $('#crosshair'), pr = $('#prompt');
    const it = r.inter && r.inter.e && r.inter.d <= +this.S.interactRange ? r.inter.e : null;
    if (it && it.o.interact.mode !== 'touch'){
      const m = it.o.interact.mode, keyName = keyLabel(this.S.keys.interact);
      const how = m === 'left' ? 'LMB' : m === 'right' ? 'RMB' : m === 'key' ? keyName : 'Click';
      ch.classList.add('hot'); pr.textContent = `[${how}] ${it.o.interact.prompt || 'Interact'}`;
    } else if (this.held){ ch.classList.remove('hot'); pr.textContent = `[LMB] Throw · [${keyLabel(this.S.keys.interact)}] Drop`; }
    else if (r.pickable){ ch.classList.add('hot'); pr.textContent = `[${keyLabel(this.S.keys.interact)} / LMB] Pick up ${r.pickable.e.o.name}`; }
    else { ch.classList.remove('hot'); pr.textContent = ''; }
    Gameplay.lookPrompt();
    { const ip = Items.aimPickup(); if (ip && !this.held){ ch.classList.add('hot'); pr.textContent = `[${keyLabel(this.S.keys.interact)} / LMB] Pick up ${ip.itemPickup}`; } }
    // "when object is aimed at" triggers
    const aimedE = r.aim ? r.aim.e : null, id = aimedE ? aimedE.o.id : null;
    if (id !== this.aimedId){ this.aimedId = id;
      if (aimedE) for (const t of P.triggers) if (t.type === 'aim' && this.trigMatch(t, aimedE, r.aim.d)) this.fireTrigger(t, aimedE); }
  },
  trigMatch(t, e, d){ return (!t.tag || e.o.tags.includes(t.tag) || e.o.name === t.tag) && (!(+t.range > 0) || d <= +t.range); },
  tryInteract(kind){
    if (this.held && (kind === 'key' || kind === 'left')){ this.drop(kind === 'left'); return true; }
    const r = this.lastPick || this.pick(); const hit = r.inter;
    if (hit && hit.e && hit.d <= +this.S.interactRange){
      const m = hit.e.o.interact.mode; const ok = m === 'any' ? kind !== 'touch' : m === kind;
      if (ok){ this.activate(hit.e); return true; } }
    if ((kind === 'key' || kind === 'left') && r.pickable){ this.pickUp(r.pickable.e); return true; }
    return false;
  },
  /* ----- pickable objects ----- */
  pickUp(e){
    if (e.o.pickSound) this.playSound({sound: e.o.pickSound});
    if (e.o.pickItem){ Items.give(e.o.pickItem, 1, {fromEntry: e, take: true}); return; }
    this.held = e; e.held = true; e.dyn.vel.set(0,0,0);
  },
  drop(thr){
    const e = this.held; if (!e) return; this.held = null; e.held = false;
    const f = new V3(); this.camera.getWorldDirection(f);
    if (thr) e.dyn.vel.copy(f.multiplyScalar(+this.S.throwForce || 12)).add(new V3(0, 2, 0));
    else e.dyn.vel.clampLength(0, 6);
  },
  updateHold(dt){
    const e = this.held; if (!e) return;
    if (e.dead || e.hidden){ this.held = null; e.held = false; return; }
    const f = new V3(); this.camera.getWorldDirection(f);
    const dist = 1.2 + (e.dynSize ? Math.max(e.dynSize.x, e.dynSize.z) * .6 : .5);
    const center = this.camera.position.clone().addScaledVector(f, dist);
    const half = e.dynSize ? e.dynSize.clone().multiplyScalar(.5) : new V3();
    const want = center.sub(half).sub(e.dynOff || new V3());
    const prev = e.root.position.clone(); e.root.position.lerp(want, Math.min(1, dt * 18));
    if (dt > 0) e.dyn.vel.copy(e.root.position).sub(prev).divideScalar(dt);
    this.syncDynBox(e);
  },
  syncDynBox(e){ if (!e.box || !e.dynOff) return; e.box.min.copy(e.root.position).add(e.dynOff); e.box.max.copy(e.box.min).add(e.dynSize); },
  updateDynamics(dt){
    const pl = this.player; if (!pl) return;
    const pb = new THREE.Box3(new V3(pl.pos.x - pl.r, pl.pos.y, pl.pos.z - pl.r), new V3(pl.pos.x + pl.r, pl.pos.y + pl.h, pl.pos.z + pl.r));
    for (const e of this.colliders){
      if (!e.dyn || e.held || e.dead || !e.dynOff) continue;
      const v = e.dyn.vel, g = +this.S.gravity;
      v.y -= g * dt; if (v.y < -50) v.y = -50;
      if (e.dyn.onGround){ const k = Math.exp(-(e.o.slippery ? .7 : 10) * dt); v.x *= k; v.z *= k; }
      if (Math.abs(v.x) < .01) v.x = 0; if (Math.abs(v.z) < .01) v.z = 0;
      e.dyn.onGround = false;
      const steps = Math.max(1, Math.ceil(Math.max(Math.abs(v.x), Math.abs(v.y), Math.abs(v.z)) * dt / .2));
      for (let i = 0; i < steps; i++) for (const ax of ['x','z','y']){
        const d = v[ax] * dt / steps; if (!d) continue;
        e.root.position[ax] += d; this.syncDynBox(e); const A = e.box;
        const others = this.colliders.filter(c => c !== e && !c.held);
        for (const c of others){ const B = c.box;
          if (A.max.x <= B.min.x || A.min.x >= B.max.x || A.max.y <= B.min.y || A.min.y >= B.max.y || A.max.z <= B.min.z || A.min.z >= B.max.z) continue;
          if (ax !== 'y' && c.dyn && c.o.slippery){ c.dyn.vel[ax] = v[ax] * .9; v[ax] *= .3; }
          const push = d > 0 ? B.min[ax] - A.max[ax] - 1e-4 : B.max[ax] - A.min[ax] + 1e-4;
          e.root.position[ax] += push; this.syncDynBox(e);
          if (ax === 'y'){ if (d < 0) e.dyn.onGround = true; v.y = 0; } else if (!c.dyn || !c.o.slippery) v[ax] *= -.2;
        }
        // don't slide into the player
        if (ax !== 'y' && e.box.intersectsBox(pb)){ const push = d > 0 ? pb.min[ax] - A.max[ax] - 1e-4 : pb.max[ax] - A.min[ax] + 1e-4; e.root.position[ax] += push; this.syncDynBox(e); v[ax] = 0; }
      }
      if (e.root.position.y < +this.S.killY){ e.root.position.copy(e.dyn.home); v.set(0,0,0); this.syncDynBox(e); }
    }
  },
  activate(e){
    const I = e.o.interact; if (!I || I.enabled === false) return;
    if (e.o.password && e.o.password.enabled && !e._pwOk){ if (!Gameplay.pwOpen) Gameplay.openPw(e); return; }
    if (I.once && e.used) return;
    if (e.cool > this.time) return;
    if (I.requireItem && !(this.player.inv[I.requireItem] > 0)){ this.toast(`Requires ${I.requireItem}`); return; }
    if (I.requireItem && I.consumeItem) this.changeItem(I.requireItem, -1, false);
    e.used = true; e.cool = this.time + (+I.cooldown || 0);
    if (I.sound) this.playSound({sound: I.sound, volume: 1});
    if (I.event) this.fireEvent(I.event, e); else log(`Interaction "${e.o.name}" has no event set`, 'warn');
  },
  attack(){
    const pl = this.player; if (pl.atkT > 0 || pl.locked || pl.dead) return;
    pl.atkT = +this.S.attackCooldown || .4;
    const r = this.lastPick || this.pick();
    if (r.enemy && r.enemy.e && r.enemy.d <= +this.S.attackRange) this.hurtEnemy(r.enemy.e.enemy, +this.S.playerDamage);
  },

  /* ===== triggers ===== */
  fireTriggers(type){ for (const t of P.triggers) if (t.type === type) this.fireTrigger(t); },
  fireTrigger(t, src){
    if (t.once !== false && this.firedTriggers.has(t.id) && t.type !== 'key') return;
    this.firedTriggers.add(t.id);
    if (t.event) this.fireEvent(t.event, src);
  },
  updateTriggers(){
    for (const t of P.triggers){
      if (t.type === 'time'){ const at = +t.time || 0, rep = +t.repeat || 0;
        if (!rep){ if (this.time >= at && !this.firedTriggers.has(t.id)){ this.firedTriggers.add(t.id); this.fireEvent(t.event); } }
        else { t._n = t._n || 0; const n = this.time >= at ? Math.floor((this.time - at) / rep) + 1 : 0;
          const key = t.id + ':' + n; if (n > 0 && !this.firedTriggers.has(key)){ this.firedTriggers.add(key); this.fireEvent(t.event); } } }
      else if (t.type === 'itemCount'){ if ((this.player.inv[t.item] || 0) >= (+t.count || 1)) this.fireTrigger(t); }
      else if (t.type === 'flag'){ if (t.flag && String(this.flags[t.flag]) === String(t.value)) this.fireTrigger(t); }
    }
  },

  /* ===== events (timeline execution) ===== */
  fireEvent(id, src){
    const ev = P.events.find(x => x.id === id || x.name === id); if (!ev){ log('Missing event ' + id, 'warn'); return; }
    const acts = ev.actions.slice().sort((a, b) => (+a.t || 0) - (+b.t || 0));
    this.running.push({ev, acts, t: 0, i: 0, src}); log(`⚡ event "${ev.name}"`);
    this.updateEvents(0);
  },
  updateEvents(dt){
    for (let k = 0; k < this.running.length; k++){ const r = this.running[k];
      r.t += dt;
      while (r.i < r.acts.length && (+r.acts[r.i].t || 0) <= r.t + 1e-6){ try { this.exec(r.acts[r.i], r); } catch(e){ log('Action error: ' + e.message, 'err'); console.error(e); } r.i++; }
    }
    this.running = this.running.filter(r => r.i < r.acts.length);
  },
  find(target){
    if (!target) return [];
    const out = []; for (const e of this.entries.values()) if (!e.dead && (e.o.tags.includes(target) || e.o.name === target || e.o.id === target)) out.push(e);
    return out;
  },
  exec(a, run){
    const T = () => { const r = this.find(a.target); if (!r.length) log(`No object with tag/name "${a.target}"`, 'warn'); return r; };
    switch (a.type){
      case 'rotate': case 'move': case 'scale': for (const e of T()) this.tweenTransform(e, a); break;
      case 'setVisible': for (const e of T()){ this.setHidden(e, !a.visible); if (a.alsoCollision) e.collide = !!a.visible; } this.collidersDirty = true; break;
      case 'toggleVisible': for (const e of T()) this.setHidden(e, !e.hidden); this.collidersDirty = true; break;
      case 'setCollision': for (const e of T()) e.collide = !!a.on; this.collidersDirty = true; break;
      case 'destroy': for (const e of T()) this.destroy(e); break;
      case 'setTexture': for (const e of T()){ e.o.texture = a.texture; forMats(e.root, m => { m.map = a.texture ? W.texture(a.texture, e.o.texRepeat) : null; m.needsUpdate = true; }); } break;
      case 'setColor': for (const e of T()) forMats(e.root, m => { if (m.color) this.tweens.push({kind: 'color', m, from: m.color.clone(), to: new THREE.Color(a.color), t: 0, d: +a.duration || 0}); }); break;
      case 'setText3D': for (const e of T()){ e.o.text = a.text; e.root.traverse(m => { if (m.userData.textSign){ const c = drawTextCanvas(e.o); m.material.map.image = c; m.material.map.needsUpdate = true; m.scale.y = c.height / c.width; } }); } break;
      case 'playAnimation': for (const e of T()) this.playClip(e, a.clip, a.loop); break;
      case 'enableInteraction': for (const e of T()) if (e.o.interact) e.o.interact.enabled = !!a.on; break;

      case 'giveItem': Items.give(a.item, +a.count || 1, {notify: a.notify !== false, animate: a.animate !== false, from: a.from, take: !!a.takeObject, src: run && run.src, equip: !!a.equip}); break;
      case 'takeItem': this.changeItem(a.item, -(+a.count || 1), true); break;
      case 'teleport': { const pl = this.player; let p = new V3(+a.x, +a.y, +a.z);
        if (a.toTarget){ const t = this.find(a.toTarget)[0]; if (t) p = t.root.getWorldPosition(new V3()); }
        pl.pos.copy(p); pl.vel.set(0,0,0); if (a.setYaw) pl.yaw = (+a.yaw || 0) * D2R; this.touching = new Set([...this.touching]); break; }
      case 'lockPlayer': this.player.locked = !!a.on; if (a.on){ this.player.vel.x = this.player.vel.z = 0; } break;
      case 'damagePlayer': this.damagePlayer(+a.amount); break;
      case 'healPlayer': this.player.hp = Math.min(+this.S.maxHealth, this.player.hp + (+a.amount || 0)); this.updateHud(); break;
      case 'setSpeed': this.S.walkSpeed = +a.walk; this.S.runSpeed = +a.run; break;
      case 'setGravity': this.S.gravity = +a.gravity; this.S.jumpForce = +a.jump; break;

      case 'cameraLock': this.camLock = {pos: new V3(+a.x, +a.y, +a.z), look: a.lookAt, lp: new V3(+a.lx, +a.ly, +a.lz), follow: a.follow !== false,
        blend: +a.blend || 0.001, until: (+a.duration > 0) ? this.time + (+a.duration) : Infinity, cur: null}; break;
      case 'cameraRelease': if (this.camLock){ this.camLock.until = this.time; this.camLock.blend = +a.blend || .001; } break;
      case 'cameraShake': this.doShake(+a.intensity, +a.duration); break;
      case 'fadeOut': $('#fade').classList.remove('full'); this.fadeTo(1, +a.duration, a.color); break;
      case 'fadeIn': $('#fade').classList.remove('full'); this.fadeTo(0, +a.duration); break;
      case 'blackout': { const f = $('#fade'); if (a.on){ f.classList.add('full'); this.setFade(1, a.color || '#000'); } else { f.classList.remove('full'); this.setFade(0); } break; }
      case 'showTitle': this.showTitle(a); break;
      case 'showDialogue': this.showDialogue(a); break;
      case 'hideText': this.clearText(); break;

      case 'playSound': this.playSound(a); break;
      case 'stopSound': this.stopSound(a.channel, +a.fade); break;

      case 'spawnEnemy': this.spawnEnemies(a); break;
      case 'killEnemy': for (const e of T()) if (e.enemy) this.killEnemy(e.enemy); break;
      case 'damageEnemy': for (const e of T()) if (e.enemy) this.hurtEnemy(e.enemy, +a.amount); break;
      case 'npcMoveTo': for (const e of T()) if (e.enemy) { e.enemy.moveTo = new V3(+a.x, +a.y, +a.z); e.enemy.moveSpeed = +a.speed || e.enemy.speed; } break;
      case 'npcFacePlayer': for (const e of T()) if (e.enemy) e.enemy.facePlayer = true; break;
      case 'setHostile': for (const e of T()) if (e.enemy) e.enemy.hostile = !!a.on; break;

      case 'triggerEvent': this.fireEvent(a.event, run && run.src); break;
      case 'stopEvent': this.running = this.running.filter(r => r.ev.id !== a.event || r === run); break;
      case 'setFlag': this.flags[a.flag] = a.value; break;
      case 'saveGame': this.saveGame(a.slot || 'checkpoint', true); break;
      case 'log': log('[game] ' + a.message); break;
    }
  },
  setHidden(e, h){ e.hidden = h; e.root.visible = !h; if (e.enemy && h) e.enemy.inactive = true; if (e.enemy && !h) e.enemy.inactive = false; },
  destroy(e){ e.dead = true; e.root.visible = false; if (e.root.parent) e.root.parent.remove(e.root);
    for (const c of this.entries.values()) if (c !== e && !c.dead && !inScene(c.root) && c.root !== e.root){ let r = c.root; while (r && r !== e.root) r = r.parent; if (r === e.root) c.dead = true; } if (e.enemy) e.enemy.dead = true; this.collidersDirty = true; },
  tweenTransform(e, a){
    const prop = a.type === 'rotate' ? 'rotation' : a.type === 'move' ? 'position' : 'scale';
    const cur = e.root[prop]; const from = new V3(cur.x, cur.y, cur.z);
    const k = prop === 'rotation' ? D2R : 1; const v = new V3((+a.x || 0) * k, (+a.y || 0) * k, (+a.z || 0) * k);
    const to = a.mode === 'to' ? v : (prop === 'scale' ? from.clone().multiply(v) : from.clone().add(v));
    const d = +a.duration || 0;
    this.tweens = this.tweens.filter(t => !(t.e === e && t.prop === prop));
    if (d <= 0){ cur.set(to.x, to.y, to.z); this.markMoved(e); return; }
    e.moving = (e.moving || 0) + 1;
    this.tweens.push({kind: 'tf', e, prop, from, to, t: 0, d, ease: EASE[a.ease] || EASE.smooth});
  },
  markMoved(e){ e.root.updateMatrixWorld(true); if (e.enemy) return; if (e.box){ e.box = boxOf(e.root); } this.collidersDirty = true; },
  updateTweens(dt){
    for (const t of this.tweens){
      t.t += dt; const p = Math.min(1, t.t / t.d);
      if (t.kind === 'tf' && t.e.o.type === 'group') this.collidersDirty = true;
      if (t.kind === 'tf'){ const s = t.ease(p); const v = t.from.clone().lerp(t.to, s); t.e.root[t.prop].set(v.x, v.y, v.z);
        if (p >= 1){ t.e.moving = Math.max(0, t.e.moving - 1); this.markMoved(t.e); } }
      else if (t.kind === 'color'){ t.m.color.copy(t.from).lerp(t.to, t.d ? p : 1); if (!t.d) t.t = 1; }
    }
    this.tweens = this.tweens.filter(t => t.t < t.d);
  },
  updateEntries(dt){
    for (const e of this.entries.values()){
      if (e.mixer) e.mixer.update(dt);
      if (e.o.type === 'text3d' && e.o.billboard){ e.root.quaternion.copy(this.camera.quaternion); }
    }
  },

  /* ===== items / HUD ===== */
  changeItem(item, n, notify){
    if (!item) return; const inv = this.player.inv;
    inv[item] = Math.max(0, (inv[item] || 0) + n); if (!inv[item]) delete inv[item];
    if (notify) this.toast(n > 0 ? `+${n} ${item}` : `−${-n} ${item}`);
    this.updateHud();
  },
  updateHud(){
    const pl = this.player; if (!pl) return;
    const S = this.S; $('#hpWrap').hidden = $('#inventory').hidden = $('#crosshair').hidden = !S.showHud;
    $('#hpBar').style.width = (100 * pl.hp / (+S.maxHealth || 100)) + '%'; $('#hpText').textContent = Math.ceil(pl.hp) + ' / ' + S.maxHealth;
    $('#inventory').innerHTML = ''; Items.renderHotbar();
  },
  toast(msg){ const d = document.createElement('div'); d.className = 't'; d.textContent = msg; $('#toast').append(d); setTimeout(() => d.remove(), 2200); },

  /* ===== camera ===== */
  updateCamera(dt){
    const pl = this.player, cam = this.camera;
    // base (player) pose
    const eye = new V3(pl.pos.x, pl.pos.y + (+this.S.eyeHeight || 1.6), pl.pos.z);
    const baseQ = new THREE.Quaternion().setFromEuler(new THREE.Euler(pl.pitch, pl.yaw, 0, 'YXZ'));
    let basePos = eye;
    if (this.S.camera === 'third'){
      const back = new V3(0, 0, 1).applyQuaternion(baseQ).multiplyScalar(+this.S.thirdPersonDistance || 4);
      basePos = eye.clone().add(back).add(new V3(0, .4, 0));
      // pull camera in front of walls
      this.ray.set(eye, back.clone().normalize()); this.ray.far = back.length();
      const solids = this.colliders.map(e => e.root);
      const h = this.ray.intersectObjects(solids, true).filter(x => visibleChain(x.object))[0];
      if (h) basePos = eye.clone().add(back.normalize().multiplyScalar(Math.max(.3, h.distance - .25)));
    }
    if (this.playerBody) this.playerBody.visible = this.S.camera === 'third' && !pl.inCar;
    // locked camera pose
    const L = this.camLock; let target = 0;
    if (L){
      target = this.time < L.until ? 1 : 0;
      const lockPos = L.pos.clone(); let look = L.lp.clone();
      if (L.look){ const t = this.find(L.look)[0]; if (t){ const b = boxOf(t.root, true); look = b.isEmpty() ? t.root.getWorldPosition(new V3()) : b.getCenter(new V3()); if (t.enemy) look.y = b.min.y + (b.max.y - b.min.y) * .85; } }
      if (!L.cur || L.follow){ const m = new THREE.Matrix4().lookAt(lockPos, look, new V3(0,1,0)); L.q = new THREE.Quaternion().setFromRotationMatrix(m); L.cur = lockPos; }
      const sp = 1 / Math.max(.001, L.blend);
      this.camBlend += Math.sign(target - this.camBlend) * Math.min(Math.abs(target - this.camBlend), dt * sp);
      if (target === 0 && this.camBlend <= 0) this.camLock = null;
      const s = EASE.smooth(this.camBlend);
      cam.position.copy(basePos).lerp(lockPos, s); cam.quaternion.copy(baseQ).slerp(L.q, s);
    } else { cam.position.copy(basePos); cam.quaternion.copy(baseQ); }
    const aiming = this.keys.has(this.S.keys.aim) && !pl.locked && !pl.dead;
    const fovT = (+this.S.fov || 75) / (aiming ? Math.max(1, +this.S.aimZoom || 2) : 1);
    if (Math.abs(cam.fov - fovT) > .05){ cam.fov += (fovT - cam.fov) * Math.min(1, dt * 14); cam.updateProjectionMatrix(); }
    $('#crosshair').classList.toggle('aiming', aiming);
    if (this.shake && this.time < this.shake.until){ const i = this.shake.i * ((this.shake.until - this.time) / this.shake.d);
      cam.position.add(new V3((Math.random() - .5) * i, (Math.random() - .5) * i, (Math.random() - .5) * i)); }
  },
  doShake(i, d){ this.shake = {i: +i || .2, d: +d || .5, until: this.time + (+d || .5)}; },

  /* ===== fade / text ===== */
  setFade(v, color){ const f = $('#fade'); f.style.opacity = v; if (color) f.style.background = color; this.fadeV = v; },
  fadeTo(to, d, color){ if (color) $('#fade').style.background = color; this.fade = {from: this.fadeV || 0, to, t: 0, d: Math.max(.001, +d || 0)}; },
  updateFade(dt){ const f = this.fade; if (!f) return; f.t += dt; const p = Math.min(1, f.t / f.d); this.setFade(f.from + (f.to - f.from) * p); if (p >= 1) this.fade = null; },
  showTitle(a){
    const st = Object.assign({}, TEXT_PRESETS[a.preset] || TEXT_PRESETS.Cinematic, a.style || {});
    const el = document.createElement('div'); el.className = 'g-title';
    const pos = {center: [50, 50], top: [50, 14], bottom: [50, 86], 'lower-third': [st.align === 'left' ? 8 : 50, 74], custom: [+st.x, +st.y]}[st.position] || [50, 50];
    const tx = st.bg === 'bar' ? '0%' : st.align === 'left' ? '0%' : st.align === 'right' ? '-100%' : '-50%';
    el.style.cssText = `left:${st.bg === 'bar' ? 0 : pos[0]}%;top:${pos[1]}%;--tx:${tx};--ty:-50%;transform:translate(var(--tx),var(--ty));
      font-family:"${st.font}",var(--ui);font-size:${st.size}px;color:${st.color};font-weight:${st.weight};font-style:${st.italic ? 'italic' : 'normal'};
      letter-spacing:${st.letterSpacing}px;text-transform:${st.uppercase ? 'uppercase' : 'none'};text-align:${st.align};line-height:1.15;`;
    if (+st.stroke > 0){ el.style.webkitTextStroke = `${st.stroke}px ${st.strokeColor}`; el.style.paintOrder = 'stroke fill'; }
    el.style.textShadow = {none: 'none', drop: '3px 3px 8px rgba(0,0,0,.85)', glow: `0 0 12px ${st.glowColor}, 0 0 30px ${st.glowColor}`, hard: `4px 4px 0 ${st.glowColor}`}[st.shadow] || 'none';
    if (st.bg === 'box'){ el.style.background = st.bgColor; el.style.padding = '.25em .7em'; el.style.borderRadius = '4px'; }
    if (st.bg === 'bar'){ el.style.background = st.bgColor; el.style.width = '100%'; el.style.maxWidth = 'none'; el.style.padding = '.35em 1em'; }
    const main = document.createElement('div'); const text = String(a.text || '');
    el.append(main);
    if (a.subtitle){ const sub = document.createElement('div'); sub.textContent = a.subtitle;
      sub.style.cssText = `font-size:${st.subSize}px;color:${st.subColor};letter-spacing:1px;text-transform:none;margin-top:.5em;-webkit-text-stroke:0;font-weight:400`; el.append(sub); }
    const ft = +st.fadeTime || .01;
    if (st.animIn === 'typewriter'){ let n = 0; main.textContent = ''; const iv = setInterval(() => { n++; main.textContent = text.slice(0, n); if (n >= text.length) clearInterval(iv); }, 1000 / 28); el._iv = iv; }
    else if (st.animIn === 'wave'){ [...text].forEach((ch, i) => { const s = document.createElement('span'); s.className = 'wv'; s.textContent = ch === ' ' ? ' ' : ch; s.style.animationDelay = (i * .06) + 's'; main.append(s); }); el.style.animation = `tFade ${ft}s ease-out both`; }
    else { main.textContent = text;
      const an = {fade: 'tFade', slideUp: 'tSlideUp', slideDown: 'tSlideDown', zoom: 'tZoom', shake: 'tShake', glitch: 'tGlitch'}[st.animIn];
      if (an === 'tShake') el.style.animation = `tFade ${ft}s ease-out both, tShake .45s ease-in-out 2`;
      else if (an) el.style.animation = `${an} ${ft}s ease-out both`; }
    $('#titles').append(el); this.titleEls.push(el);
    const dur = (+a.duration || 3) * 1000;
    el._t1 = setTimeout(() => { if (st.animOut === 'fade'){ el.style.animation = 'none'; el.style.opacity = 1; void el.offsetWidth; el.style.transition = `opacity ${ft}s ease-in`; el.style.opacity = 0; } }, Math.max(0, dur - (st.animOut === 'fade' ? ft * 1000 : 0)));
    el._t2 = setTimeout(() => this.removeTitle(el), dur + 50);
  },
  removeTitle(el){ clearTimeout(el._t1); clearTimeout(el._t2); clearInterval(el._iv); el.remove(); this.titleEls = this.titleEls.filter(x => x !== el); },
  showDialogue(a){
    const box = $('#dialogue'); box.hidden = false; box.style.transition = 'none'; box.style.opacity = 1; box.querySelector('.speaker').textContent = a.speaker || ''; box.querySelector('.speaker').hidden = !a.speaker;
    const line = box.querySelector('.line'); const text = String(a.text || ''); clearInterval(this._dlg); clearTimeout(this._dlgT);
    const sp = +a.typeSpeed || 0;
    if (sp > 0){ let n = 0; line.textContent = ''; this._dlg = setInterval(() => { n++; line.textContent = text.slice(0, n); if (n >= text.length) clearInterval(this._dlg); }, 1000 / sp); }
    else line.textContent = text;
    this._dlgT = setTimeout(() => { box.style.transition = 'opacity .35s'; box.style.opacity = 0; this._dlgT = setTimeout(() => { box.hidden = true; }, 350); }, Math.max(0, (+a.duration || 4) * 1000 - 350));
  },
  clearText(){ for (const el of [...this.titleEls]) this.removeTitle(el); clearInterval(this._dlg); clearTimeout(this._dlgT); const d = $('#dialogue'); if (d) d.hidden = true; },

  /* ===== audio (real files from the asset folder) ===== */
  playSound(a){
    const url = VFS.url(a.sound) || builtinSfxUrl(a.sound); if (!url){ log('Sound not found: ' + a.sound, 'warn'); return; }
    const au = new Audio(url); au.loop = !!a.loop; const vol = Math.max(0, Math.min(1, a.volume == null ? 1 : +a.volume)); au.volume = vol;
    const s = {a: au, vol, channel: a.channel || '', at: a.at || '', fadeT: 0};
    if (s.channel) this.stopSound(s.channel, 0);
    au.play().catch(() => {}); this.sounds.push(s);
    au.addEventListener('ended', () => { if (!au.loop) this.sounds = this.sounds.filter(x => x !== s); });
    return s;
  },
  stopSound(channel, fade){
    for (const s of this.sounds){ if (channel && s.channel !== channel) continue;
      if (fade > 0){ s.fadeOut = fade; s.fadeT = 0; } else { s.a.pause(); s.dead = true; } }
    this.sounds = this.sounds.filter(s => !s.dead);
  },
  stopAllSounds(){ for (const s of this.sounds) s.a.pause(); this.sounds = []; },
  updateSounds(dt){
    for (const s of this.sounds){
      let v = s.vol;
      if (s.at){ const t = this.find(s.at)[0]; if (t){ const d = t.root.getWorldPosition(new V3()).distanceTo(this.player.pos); v *= Math.max(0, 1 - d / 30); } }
      if (s.fadeOut){ s.fadeT += dt; v *= Math.max(0, 1 - s.fadeT / s.fadeOut); if (s.fadeT >= s.fadeOut){ s.a.pause(); s.dead = true; } }
      s.a.volume = Math.max(0, Math.min(1, v));
    }
    this.sounds = this.sounds.filter(s => !s.dead);
  },

  /* ===== animation clips ===== */
  async playClip(e, key, loop){
    const holder = e.root.userData.body; if (!holder) return;
    if (!holder.userData.model){ e.pendingClip = [key, loop]; return; }
    const clip = await W.findClip(key, holder.userData.clips); if (!clip){ log(`Animation "${key}" not found on ${e.o.name}`, 'warn'); return; }
    if (!e.mixer) e.mixer = new THREE.AnimationMixer(holder.userData.model);
    const act = e.mixer.clipAction(clip);
    if (e.curAction && e.curAction !== act) e.curAction.fadeOut(.25);
    act.reset().setLoop(loop ? THREE.LoopRepeat : THREE.LoopOnce, Infinity); act.clampWhenFinished = !loop; act.fadeIn(.25).play(); e.curAction = act;
  },
  onModelReady(o, holder){
    const e = this.entries.get(o.id); if (!e) return;
    if (e.pendingClip){ const [k, l] = e.pendingClip; e.pendingClip = null; this.playClip(e, k, l); }
    if (e.enemy) this.setupEnemyClips(e.enemy);
    this.collidersDirty = true;
  },

  /* ===== enemies & NPCs ===== */
  makeEnemy(e){
    const E = e.o.enemy;
    const en = e.enemy = {e, hp: +E.health, maxHp: +E.health, speed: +E.speed, hostile: !!E.hostile, state: 'idle', atkT: 0, phase: 0, dead: false, deadT: 0,
      body: {pos: e.root.position.clone(), vel: new V3(), r: .35 * Math.max(e.o.scale[0], e.o.scale[2]), h: 1.8 * e.o.scale[1], onGround: false}, yaw: e.root.rotation.y, flashT: 0, actions: {}};
    this.enemies.push(en);
    if (E.showHealthBar !== false){
      const c = document.createElement('canvas'); c.width = 128; c.height = 16;
      const tex = new THREE.CanvasTexture(c); const sp = new THREE.Sprite(new THREE.SpriteMaterial({map: tex, depthTest: false, transparent: true}));
      sp.scale.set(1, .13, 1); sp.position.y = (E.model && E.normalize ? +E.height : 1.8) + .35; sp.renderOrder = 10; e.root.add(sp);
      en.hpBar = {c, tex, sp}; this.drawHp(en);
    }
    if (e.root.userData.body.userData.model) this.setupEnemyClips(en);
    return en;
  },
  async setupEnemyClips(en){
    const E = en.e.o.enemy, holder = en.e.root.userData.body; if (!holder.userData.model) return;
    en.mixer = en.e.mixer = new THREE.AnimationMixer(holder.userData.model);
    for (const [k, key] of [['idle', E.clipIdle], ['walk', E.clipWalk], ['attack', E.clipAttack], ['death', E.clipDeath]]){
      let clip = await W.findClip(key, holder.userData.clips);
      if (!clip && k === 'idle' && holder.userData.clips && holder.userData.clips[0]) clip = holder.userData.clips[0];
      if (clip){ const a = en.mixer.clipAction(clip); if (k === 'death' || k === 'attack'){ a.setLoop(THREE.LoopOnce, 1); a.clampWhenFinished = true; } en.actions[k] = a; }
    }
    this.setEnemyAnim(en, en.dead ? 'death' : 'idle', true);
  },
  setEnemyAnim(en, name, force){
    if (!en.mixer) { en.anim = name; return; }
    if (en.anim === name && !force) return; const a = en.actions[name]; if (!a){ en.anim = name; return; }
    const prev = en.actions[en.anim]; if (prev && prev !== a) prev.fadeOut(.2);
    a.reset().fadeIn(.2).play(); en.anim = name;
  },
  drawHp(en){ if (!en.hpBar) return; const {c, tex, sp} = en.hpBar, x = c.getContext('2d');
    x.clearRect(0,0,128,16); x.fillStyle = '#000a'; x.fillRect(0,0,128,16); x.fillStyle = en.hostile ? '#e04848' : '#5ccf8a'; x.fillRect(2,2,124 * Math.max(0, en.hp / en.maxHp),12); tex.needsUpdate = true;
    sp.visible = en.hp < en.maxHp || en.hostile; },
  spawnEnemies(a){
    const temps = this.find(a.template).filter(e => e.o.type === 'enemy'); if (!temps.length){ log('Spawn: no enemy template "' + a.template + '"', 'warn'); return; }
    const tpl = temps[0], n = Math.max(1, +a.count || 1);
    for (let i = 0; i < n; i++){
      const o = clone(tpl.o); o.id = uid('sp'); o.visible = true; o.enemy.spawnOnStart = true; o.spawned = true;
      const base = a.atTemplate ? new V3().fromArray(tpl.o.pos) : new V3(+a.x, +a.y, +a.z);
      const sp = +a.spread || 0; const ang = Math.random() * Math.PI * 2, rr = n > 1 ? sp * Math.sqrt(Math.random()) : 0;
      o.pos = [base.x + Math.cos(ang) * rr, base.y, base.z + Math.sin(ang) * rr];
      const root = W.build(o); root.visible = true;
      const e = {o, root, used: false, cool: 0, hidden: false, collide: false}; this.entries.set(o.id, e); this.makeEnemy(e);
      this.spawnFx(root.position);
    }
  },
  spawnFx(p){ const m = new THREE.Mesh(new THREE.TorusGeometry(.6, .06, 6, 32), new THREE.MeshBasicMaterial({color: 0xff6040, transparent: true}));
    m.rotation.x = Math.PI / 2; m.position.copy(p).add(new V3(0,.05,0)); W.scene.add(m);
    const t0 = performance.now(); const tick = () => { const k = (performance.now() - t0) / 500; m.scale.setScalar(1 + k * 1.5); m.material.opacity = 1 - k; if (k < 1 && this.active) requestAnimationFrame(tick); else { W.scene.remove(m); m.geometry.dispose(); } }; tick(); },
  hurtEnemy(en, n){
    if (!en || en.dead) return; en.hp -= n; en.flashT = .15; this.drawHp(en);
    const E = en.e.o.enemy; if (E.hurtSound && en.hp > 0) this.playSound({sound: E.hurtSound, volume: .8});
    if (en.hp <= 0) this.killEnemy(en); else if (!en.hostile && E.hostile !== false) {}
  },
  killEnemy(en){
    if (en.dead) return; en.dead = true; en.hp = 0; en.deadT = 0; this.drawHp(en); if (en.hpBar) en.hpBar.sp.visible = false;
    const E = en.e.o.enemy; if (E.deathSound) this.playSound({sound: E.deathSound, volume: .9});
    this.setEnemyAnim(en, 'death');
    if (E.deathEvent) this.fireEvent(E.deathEvent, en.e);
    for (const t of P.triggers) if (t.type === 'enemyKilled' && (!t.tag || en.e.o.tags.includes(t.tag) || en.e.o.name === t.tag)){
      if (t.once === false || !this.firedTriggers.has(t.id)){ this.firedTriggers.add(t.id); this.fireEvent(t.event, en.e); } }
  },
  updateEnemies(dt){
    const pl = this.player;
    for (const en of this.enemies){
      const e = en.e; if (e.dead && !en.dead) continue;
      if (en.mixer) en.mixer.update(dt);
      if (en.inactive || e.template) continue;
      const man = e.root.userData.body.userData.mannequin, E = e.o.enemy;
      if (en.flashT > 0){ en.flashT -= dt; forMats(e.root, m => { if (m.emissive) m.emissive.setRGB(en.flashT > 0 ? .8 : 0, 0, 0); }); }
      if (en.dead){
        en.deadT += dt;
        if (!en.actions.death){ const k = Math.min(1, en.deadT / .5); e.root.userData.body.rotation.x = -k * Math.PI / 2 * .98; e.root.userData.body.position.y = k * .2; }
        if (en.deadT > 3.5){ const k = Math.min(1, (en.deadT - 3.5) / .8); e.root.position.y = en.body.pos.y - k * 1.2; if (k >= 1 && !e.dead){ this.destroy(e); } }
        continue;
      }
      const b = en.body; b.pos.copy(e.root.position);
      const toP = new V3(pl.pos.x - b.pos.x, 0, pl.pos.z - b.pos.z); const dist = toP.length();
      let want = new V3(), spd = 0, animState = 'idle';
      if (en.moveTo){ const d = new V3(en.moveTo.x - b.pos.x, 0, en.moveTo.z - b.pos.z);
        if (d.length() < .25){ en.moveTo = null; } else { want = d.normalize(); spd = en.moveSpeed || en.speed; animState = 'walk'; } }
      else if (en.hostile && !pl.dead && dist < +E.aggroRange){
        if (dist > +E.attackRange){ want = toP.clone().normalize(); spd = en.speed; animState = 'walk'; }
        else { animState = 'attack'; en.atkT -= dt; want = toP.clone().normalize(); spd = 0;
          if (en.atkT <= 0){ en.atkT = 1 / Math.max(.05, +E.attackRate || 1); en.swingT = .35; this.setEnemyAnim(en, 'attack', true);
            if (E.attackSound) this.playSound({sound: E.attackSound, volume: .8});
            setTimeout(() => { if (!en.dead && this.active){ const d2 = Math.hypot(pl.pos.x - e.root.position.x, pl.pos.z - e.root.position.z); if (d2 <= +E.attackRange + .4) this.damagePlayer(+E.damage); } }, 180); } }
      }
      if (en.facePlayer && !spd){ want = toP.clone().normalize(); en.facePlayer = dist > .1 && animState === 'idle' ? en.facePlayer : false; }
      b.vel.x = want.x * spd; b.vel.z = want.z * spd; b.vel.y -= (+this.S.gravity) * dt;
      // keep apart from other enemies and from the player
      for (const o2 of this.enemies){ if (o2 === en || o2.dead || o2.inactive || o2.e.template || o2.e.dead) continue;
        const dx = b.pos.x - o2.body.pos.x, dz = b.pos.z - o2.body.pos.z, d2 = Math.hypot(dx, dz), min = b.r + o2.body.r;
        if (d2 < min){ const k = (min - d2) / dt * .5; if (d2 < 1e-4){ b.vel.x += (Math.random() - .5) * 4; } else { b.vel.x += dx / d2 * k; b.vel.z += dz / d2 * k; } } }
      if (dist < b.r + pl.r && dist > 1e-4){ const k = (b.r + pl.r - dist) / dt; b.vel.x -= toP.x / dist * k; b.vel.z -= toP.z / dist * k; }
      this.moveBody(b, dt);
      if (b.pos.y < +this.S.killY){ this.killEnemy(en); }
      e.root.position.copy(b.pos);
      if (want.lengthSq() > 0){ const faceModel = !!(E.model); const target = Math.atan2(-want.x, -want.z) + (faceModel ? Math.PI : 0);
        let d = target - e.root.rotation.y; d = Math.atan2(Math.sin(d), Math.cos(d)); e.root.rotation.y += d * Math.min(1, dt * 10); }
      // animation
      if (en.swingT > 0) en.swingT -= dt;
      if (en.mixer){ if (!(en.anim === 'attack' && en.swingT > 0)) this.setEnemyAnim(en, animState === 'attack' ? 'idle' : animState); }
      if (man) animateMannequin(man, en, animState, dt, E.motion);
    }
  },

  /* ===== game saves ===== */
  snapshot(){
    const pl = this.player, objs = {};
    for (const e of this.entries.values()){
      const r = e.root; objs[e.o.id] = {pos: r.position.toArray(), rot: [r.rotation.x, r.rotation.y, r.rotation.z], scale: r.scale.toArray(),
        hidden: e.hidden, collide: e.collide, dead: !!e.dead, used: e.used, enabled: e.o.interact ? e.o.interact.enabled !== false : undefined,
        texture: e.o.texture, text: e.o.text, spawned: e.o.spawned ? e.o : undefined,
        enemy: e.enemy ? {hp: e.enemy.hp, dead: e.enemy.dead, hostile: e.enemy.hostile} : undefined};
    }
    return {format: 'kiln-save-1', savedAt: new Date().toISOString(), time: this.time,
      player: {pos: pl.pos.toArray(), yaw: pl.yaw, pitch: pl.pitch, hp: pl.hp, inv: clone(pl.inv)},
      flags: clone(this.flags), fired: [...this.firedTriggers], gameplay: Gameplay.state(), settings: {walkSpeed: this.S.walkSpeed, runSpeed: this.S.runSpeed, gravity: this.S.gravity, jumpForce: this.S.jumpForce}, objects: objs};
  },
  saveGame(slot, silent){
    slot = String(slot || 'quick').replace(/[^\w-]/g, '') || 'quick';
    const snap = this.snapshot(); P.saves = P.saves || {}; P.saves[slot] = snap;
    if (slot === 'checkpoint') this.checkpoint = {pos: this.player.pos.clone(), yaw: this.player.yaw};
    Editor.persist(true);
    this.toast(silent ? 'Checkpoint saved' : `Game saved (${slot})`); log(`Game saved to saves/${slot}.json`, 'ok');
  },
  loadGame(slot){
    slot = String(slot || 'quick'); const s = P.saves && P.saves[slot]; if (!s){ this.toast(`No save in ${slot}`); return; }
    this.stopAllSounds(); this.clearText(); W.buildAll(); this.reset();
    this.time = s.time; this.flags = clone(s.flags || {}); this.firedTriggers = new Set(s.fired || []); Object.assign(this.S, s.settings || {});
    const pl = this.player; pl.pos.fromArray(s.player.pos); pl.yaw = s.player.yaw; pl.pitch = s.player.pitch; pl.hp = s.player.hp; pl.inv = clone(s.player.inv || {});
    for (const id in s.objects){ const st = s.objects[id]; let e = this.entries.get(id);
      if (!e && st.spawned && !st.dead){ const o = clone(st.spawned); const root = W.build(o); e = {o, root, used: false, cool: 0, hidden: false, collide: false}; this.entries.set(id, e); this.makeEnemy(e); }
      if (!e) continue;
      e.root.position.fromArray(st.pos); e.root.rotation.set(st.rot[0], st.rot[1], st.rot[2]); e.root.scale.fromArray(st.scale);
      this.setHidden(e, !!st.hidden); e.collide = st.collide; e.used = st.used;
      if (e.o.interact && st.enabled !== undefined) e.o.interact.enabled = st.enabled;
      if (st.texture !== e.o.texture){ e.o.texture = st.texture; forMats(e.root, m => { m.map = st.texture ? W.texture(st.texture, e.o.texRepeat) : null; m.needsUpdate = true; }); }
      if (st.dead){ this.destroy(e); continue; }
      if (st.enemy){ if (!e.enemy) this.makeEnemy(e), e.root.visible = !st.hidden, e.template = false; e.enemy.hp = st.enemy.hp; e.enemy.hostile = st.enemy.hostile; e.enemy.body.pos.copy(e.root.position); if (st.enemy.dead) this.destroy(e); else this.drawHp(e.enemy); }
    }
    Gameplay.restore(s.gameplay);
    this.collidersDirty = true; this.updateHud(); this.toast(`Loaded ${slot}`); if (this.paused) this.togglePause(false);
    if (this.S.music) this.playSound({sound: this.S.music, volume: this.S.musicVolume, loop: true, channel: 'music'});
  },
};

/* ---------- helpers ---------- */
function $(s){ return document.querySelector(s); }
function boxOf(root, includeHidden){
  const b = new THREE.Box3(); root.updateMatrixWorld(true);
  root.traverse(m => {
    if (!m.isMesh || m.isSprite) return;
    if (!includeHidden && (m.userData.editorOnly || (m.parent && m.parent.userData.editorOnly))) return;
    if (!m.geometry.boundingBox) m.geometry.computeBoundingBox();
    b.union(m.geometry.boundingBox.clone().applyMatrix4(m.matrixWorld));
  });
  return b;
}
function visibleChain(o){ while (o){ if (!o.visible) return false; o = o.parent; } return true; }
function forMats(root, fn){ root.traverse(m => { if (m.isMesh && m.material && !m.userData.editorOnly && !m.userData.textSign) (Array.isArray(m.material) ? m.material : [m.material]).forEach(fn); }); }
function keyLabel(code){ if (!code) return '—'; return code.replace(/^Key/, '').replace(/^Digit/, '').replace('ShiftLeft', 'L-Shift').replace('ShiftRight', 'R-Shift').replace('ControlLeft', 'L-Ctrl').replace('Space', 'Space').replace(/^Arrow/, '↑').replace('↑Up','↑').replace('↑Down','↓').replace('↑Left','←').replace('↑Right','→'); }
function log(msg, cls){ const el = document.getElementById('log'); if (!el) return; const d = document.createElement('div'); if (cls) d.className = cls;
  d.textContent = new Date().toTimeString().slice(0, 8) + '  ' + msg; el.append(d); while (el.children.length > 400) el.firstChild.remove(); el.scrollTop = el.scrollHeight; }

/* procedural motions for the built-in mannequin rig (offsets on top of your joint pose) */
function animateMannequin(man, en, state, dt, motion){
  const J = man.userData.joints; const spd = Math.hypot(en.body.vel.x, en.body.vel.z);
  en.phase += dt * (state === 'walk' ? 2.2 + spd * 1.6 : 2);
  const s = Math.sin(en.phase), c = Math.cos(en.phase);
  const P0 = n => J[n].userData.pose || new THREE.Euler();
  const set = (n, x, y, z) => { const p = P0(n); J[n].rotation.set(p.x + (x || 0), p.y + (y || 0), p.z + (z || 0)); };
  if (motion === 'none'){ for (const n in J) set(n); return; }
  const zombie = motion === 'zombie';
  if (state === 'walk'){
    const a = zombie ? .35 : .6;
    set('legL', s * a); set('legR', -s * a); set('shinL', Math.max(0, -c) * .7); set('shinR', Math.max(0, c) * .7);
    set('armL', zombie ? -1.4 + s * .1 : -s * a * .8); set('armR', zombie ? -1.4 - s * .1 : s * a * .8); set('foreArmL', zombie ? 0 : -.3); set('foreArmR', zombie ? 0 : -.3);
    set('spine', zombie ? .25 : .05, 0, s * .04); set('head', 0, 0, zombie ? s * .1 : 0); set('hips', 0, s * .08);
  } else if (state === 'attack'){
    const k = en.swingT > 0 ? Math.sin((1 - en.swingT / .35) * Math.PI) : 0;
    set('armR', -1.2 - k * 1.2, 0, 0); set('armL', -1.0 - k * .6); set('foreArmR', -k * .4); set('foreArmL', -.4); set('spine', .2 + k * .2); set('head'); set('legL', .3); set('legR', -.2); set('shinL'); set('shinR', .2); set('hips');
  } else {
    set('spine', Math.sin(en.phase * .7) * .03); set('head', 0, Math.sin(en.phase * .35) * .25); set('armL', zombie ? -1.2 : 0, 0, Math.sin(en.phase * .7) * .04 - .05); set('armR', zombie ? -1.2 : 0, 0, -Math.sin(en.phase * .7) * .04 + .05);
    set('foreArmL'); set('foreArmR'); set('legL'); set('legR'); set('shinL'); set('shinR'); set('hips');
  }
}
function inScene(o){ while (o){ if (o === W.scene) return true; o = o.parent; } return false; }
