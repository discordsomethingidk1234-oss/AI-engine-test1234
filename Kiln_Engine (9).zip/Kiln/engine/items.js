/* ---------- Items: hotbar, held models, pickup animation, swords and guns ----------
   An item (Items tab) can use any group / object in the scene as its model.
   In game: picked-up items go to the hotbar (1-9 or mouse wheel). The selected item is held in front of the camera. */
const SWING_PRESETS = {
  slash:    {label: 'Slash (right → left)', dur: .42, hitAt: .5, keys: [{t: .25, p: [.12, .08, .05], r: [10, -35, -35]}, {t: .55, p: [-.38, -.06, -.25], r: [-60, 65, 45]}]},
  backhand: {label: 'Backhand (left → right)', dur: .42, hitAt: .5, keys: [{t: .25, p: [-.3, .08, .05], r: [10, 40, 35]}, {t: .55, p: [.2, -.06, -.25], r: [-60, -60, -40]}]},
  overhead: {label: 'Overhead chop', dur: .5, hitAt: .55, keys: [{t: .3, p: [0, .25, .12], r: [55, 0, 0]}, {t: .58, p: [0, -.22, -.28], r: [-95, 0, 0]}]},
  stab:     {label: 'Stab / thrust', dur: .38, hitAt: .45, keys: [{t: .22, p: [0, -.05, .14], r: [-85, 0, 0]}, {t: .48, p: [-.05, .02, -.5], r: [-88, 0, 0]}, {t: .7, p: [0, -.04, -.2], r: [-80, 0, 0]}]},
  uppercut: {label: 'Uppercut', dur: .45, hitAt: .5, keys: [{t: .25, p: [.05, -.28, .05], r: [-40, 0, -15]}, {t: .55, p: [-.05, .25, -.25], r: [70, 10, 10]}]},
  spin:     {label: 'Spin', dur: .6, hitAt: .5, keys: [{t: .25, p: [-.1, 0, -.1], r: [0, 120, 0]}, {t: .5, p: [-.2, 0, -.2], r: [0, 240, 0]}, {t: .75, p: [0, 0, -.1], r: [0, 360, 0]}]},
  bash:     {label: 'Bash', dur: .35, hitAt: .45, keys: [{t: .2, p: [.05, .05, .1], r: [20, 0, 0]}, {t: .45, p: [-.05, -.02, -.3], r: [-25, 0, 0]}]},
};
const ITEM_MOTIONS = [['bobsway', 'Bob + sway'], ['bob', 'Bob only'], ['float', 'Float'], ['spin', 'Slow spin'], ['still', 'Still']];

function newItemDef(name){
  return {name: name || 'Item', icon: '', desc: '', model: '', kind: 'none', damage: 20, size: .6,
    hold: {pos: [.32, -.3, -.7], rot: [0, 0, 0], scale: 1}, motion: 'bobsway',
    pickupInWorld: true, pickupMode: 'interact', pickupSound: '', equipSound: '',
    sword: {range: 2.4, arc: 70, cooldown: .1, swingSound: '', hitSound: '', motions: [{preset: 'slash', dur: .42, hitAt: .5, keys: []}, {preset: 'backhand', dur: .42, hitAt: .5, keys: []}]},
    gun: {builtin: 'pistol', magSize: 12, startAmmo: 36, ammoType: '', infinite: false, fireRate: 5, auto: false, reloadTime: 1.4,
      bulletSize: .06, bulletSpeed: 140, bulletColor: '#ffd27a', bulletDrop: 0, spread: .6, range: 150, recoil: 1, shotSound: '', reloadSound: '', emptySound: ''}};
}
/* fill in missing fields on old / partial item definitions */
function normItem(it){
  const d = newItemDef(it.name);
  for (const k in d) if (it[k] === undefined) it[k] = clone(d[k]);
  for (const k of ['hold', 'sword', 'gun']) for (const kk in d[k]) if (it[k][kk] === undefined) it[k][kk] = clone(d[k][kk]);
  return it;
}

function makeSwordMesh(){
  const g = new THREE.Group(), steel = std('#d9dee6', {metalness: .9, roughness: .25}), grip = std('#3a2a1e', {roughness: .9}), gold = std('#c9a23a', {metalness: .8, roughness: .35});
  const blade = bx(.06, .9, .015, steel); blade.position.y = .55; g.add(blade);
  const tip = new THREE.Mesh(new THREE.ConeGeometry(.043, .14, 4), steel); tip.position.y = 1.07; tip.rotation.y = Math.PI / 4; tip.scale.z = .35; g.add(tip);
  const guard = bx(.26, .04, .06, gold); guard.position.y = .09; g.add(guard);
  const handle = bx(.04, .18, .04, grip); g.add(handle);
  const pommel = new THREE.Mesh(new THREE.SphereGeometry(.035, 10, 8), gold); pommel.position.y = -.1; g.add(pommel);
  return g;
}

/* a copy of a scene object / group, without editor helpers */
function cloneVisual(src){
  const c = THREE.SkeletonUtils.clone(src); c.visible = true;
  const rm = [];
  c.traverse(o => {
    if (o.userData.editorOnly || o.isSprite || o.isLight) { rm.push(o); return; }
    const id = o.userData.objId; if (!id) return;
    const ob = P.objects.find(x => x.id === id);
    if (ob && ['interaction', 'spawn', 'light'].includes(ob.type)) { rm.push(o); return; }
    if (o !== c) o.visible = !ob || ob.visible !== false;
  });
  rm.forEach(o => o.parent && o.parent.remove(o));
  return c;
}

const Items = {
  extraDefs: {}, slots: [], sel: -1, ammo: {}, mags: {}, bullets: [], flying: [],
  def(name){ return (P.items || []).find(i => i.name === name) || this.extraDefs[name] || null; },

  /* ---------- the held model is drawn in its own pass, so it never clips into walls ---------- */
  initVM(){
    if (this.vmScene) return;
    const s = this.vmScene = new THREE.Scene();
    s.add(new THREE.HemisphereLight(0xeef3ff, 0x55504a, .9));
    const d = new THREE.DirectionalLight(0xffffff, .9); d.position.set(1, 2, 1.5); s.add(d);
    this.vmCam = new THREE.PerspectiveCamera(62, 1, .01, 50);
    this.holder = new THREE.Group(); this.pivot = new THREE.Group(); this.holder.add(this.pivot); s.add(this.holder);
    this.flash = new THREE.PointLight(0xffc070, 0, 3); s.add(this.flash);
    this.bulletGeo = new THREE.SphereGeometry(.5, 8, 6); this.bulletMats = {};
  },
  renderVM(cam){
    if (!this.vmScene || !this.pivot.children.length || !this.holder.visible) return;
    this.vmCam.aspect = cam.aspect; this.vmCam.updateProjectionMatrix();
    const r = W.renderer; r.autoClear = false; r.clearDepth(); r.render(this.vmScene, this.vmCam); r.autoClear = true;
  },
  /* build a hand-held model for an item, centered and auto-sized */
  buildModel(def){
    let m;
    const src = def.model && W.roots.get(def.model);
    if (src) m = cloneVisual(src);
    else if (def.kind === 'gun') m = makeGunMesh(def.gun.builtin || 'pistol');
    else if (def.kind === 'sword') m = makeSwordMesh();
    else { m = new THREE.Mesh(W.geo.box, std('#c8ccd4')); m.scale.setScalar(.3); }
    if (src){ m.position.set(0, 0, 0); }
    const wrap = new THREE.Group(); wrap.add(m); wrap.updateMatrixWorld(true);
    const b = new THREE.Box3().setFromObject(m);
    if (!b.isEmpty()){
      const c = b.getCenter(new THREE.Vector3()), sz = b.getSize(new THREE.Vector3()); m.position.sub(c);
      const k = (+def.size > 0) ? +def.size / Math.max(sz.x, sz.y, sz.z, 1e-3) : 1; wrap.scale.setScalar(k);
      wrap.userData.front = (b.min.z - c.z) * k; wrap.userData.top = (b.max.y - c.y) * k;
    }
    wrap.traverse(o => { if (o.isMesh){ o.castShadow = false; o.frustumCulled = false; } });
    return wrap;
  },
  setHeld(def){
    this.initVM(); this.pivot.clear(); this.heldDef = def || null; this.swing = null; this.kick = 0; this.reloadT = 0;
    if (!def) return;
    this.pivot.add(this.buildModel(def));
  },

  /* ---------- runtime ---------- */
  reset(){
    this.initVM(); this.extraDefs = {}; this.slots = []; this.sel = -1; this.ammo = {}; this.mags = {}; this.combo = 0; this.useT = 0; this.trigger = false;
    for (const b of this.bullets) W.scene.remove(b.mesh); this.bullets = [];
    for (const f of this.flying) W.scene.remove(f.mesh); this.flying = [];
    this.dipT = 0; this.setHeld(null); this.holder.visible = true;
    const RT = Runtime;
    for (const it of P.items){ normItem(it); if (!it.model) continue;
      const e = RT.entries.get(it.model); if (!e) continue;
      if (it.pickupInWorld) e.itemPickup = it.name;
      else { RT.setHidden(e, true); RT.collidersDirty = true; }
    }
    this.renderHotbar();
  },
  stop(){ this.setHeld(null); for (const b of this.bullets) W.scene.remove(b.mesh); this.bullets = []; for (const f of this.flying) W.scene.remove(f.mesh); this.flying = []; $('#hotbar').innerHTML = ''; },

  /* inventory → hotbar slots (keeps the order you got things in) */
  syncSlots(){
    const inv = Runtime.player ? Runtime.player.inv : {};
    const cur = this.slots[this.sel];
    this.slots = this.slots.filter(n => inv[n] > 0);
    for (const n in inv) if (inv[n] > 0 && !this.slots.includes(n)) this.slots.push(n);
    const i = this.slots.indexOf(cur);
    if (cur && i < 0) this.select(-1, true); else this.sel = i;
  },
  current(){ return this.sel >= 0 ? this.def(this.slots[this.sel]) : null; },
  select(i, silent){
    if (i >= this.slots.length) return;
    if (i === this.sel && !silent) i = -1;     // pressing the same number again puts it away
    this.sel = i; const def = this.current(); this.setHeld(def);
    if (def && !silent) Runtime.playSound({sound: def.equipSound || SFX + 'item_equip.wav', volume: .6});
    this.renderHotbar();
  },
  wheel(dy){ if (!this.slots.length) return; const n = this.slots.length; let i = this.sel < 0 ? (dy > 0 ? 0 : n - 1) : (this.sel + (dy > 0 ? 1 : -1) + n) % n; this.sel = -2; this.select(i); },
  renderHotbar(){
    const hb = $('#hotbar'); if (!hb) return; this.syncSlots();
    hb.innerHTML = ''; hb.hidden = !Runtime.S || !Runtime.S.showHud || !this.slots.length || !!(Runtime.player && Runtime.player.inCar);
    this.slots.forEach((n, i) => {
      const d = this.def(n) || {}, cnt = Runtime.player.inv[n] || 0;
      const slot = h('div', {class: 'hb-slot' + (i === this.sel ? ' on' : '')}, i < 9 ? h('span', {class: 'hb-k'}, i + 1) : null);
      if (d.icon && VFS.url(d.icon)) slot.append(h('img', {src: VFS.url(d.icon)})); else slot.append(h('span', {class: 'hb-n'}, n.slice(0, 7)));
      if (cnt > 1) slot.append(h('span', {class: 'hb-c'}, cnt));
      slot.title = n; hb.append(slot);
    });
    const def = this.current(), a = $('#ammoHud');
    if (def && def.kind === 'gun'){ const g = def.gun, at = g.ammoType || def.name; a.hidden = false;
      a.innerHTML = `<b>${def.name}</b> <span>${this.mag(def)}</span> / ${g.infinite ? '∞' : (this.ammo[at] || 0)}${this.reloadT > 0 ? ' <i>reloading…</i>' : ''}`; }
    else a.hidden = true;
  },

  /* ---------- getting items: the item flies from where it was into your hand ---------- */
  give(name, count, opt){
    opt = opt || {}; const RT = Runtime, def = this.def(name);
    const finish = () => {
      RT.changeItem(name, count || 1, opt.notify !== false);
      if (def && def.kind === 'gun'){ const at = def.gun.ammoType || def.name; if (this.mags[def.name] == null){ this.mags[def.name] = +def.gun.magSize; this.ammo[at] = (this.ammo[at] || 0) + (+def.gun.startAmmo || 0); } }
      this.syncSlots(); const i = this.slots.indexOf(name);
      if (i >= 0 && (this.sel < 0 || opt.equip)) this.select(i, false); else this.renderHotbar();
    };
    if (opt.animate === false || !RT.camera){ finish(); return; }
    // where does it come from?
    let srcRoot = opt.fromEntry ? opt.fromEntry.root : null, at = null;
    if (!srcRoot && opt.from){ const t = RT.find(opt.from)[0]; if (t){ srcRoot = t.root; if (opt.take) opt.fromEntry = t; } }
    if (!srcRoot && opt.src && opt.src.root){ at = boxOf(opt.src.root, true).getCenter(new V3()); }
    let mesh;
    if (srcRoot && srcRoot.visible !== false && !boxOf(srcRoot).isEmpty()){
      mesh = cloneVisual(srcRoot); srcRoot.getWorldPosition(mesh.position); srcRoot.getWorldQuaternion(mesh.quaternion); srcRoot.getWorldScale(mesh.scale);
    } else {
      mesh = def ? this.buildModel(def) : new THREE.Mesh(W.geo.box, std('#c8ccd4'));
      if (!def) mesh.scale.setScalar(.3);
      if (!at && srcRoot) at = boxOf(srcRoot, true).getCenter(new V3());
      if (!at){ const f = RT.camera.getWorldDirection(new V3()).setY(0).normalize(); at = RT.player.pos.clone().addScaledVector(f, .9); at.y += .15; }
      mesh.position.copy(at);
    }
    if (opt.fromEntry && opt.take !== false) RT.destroy(opt.fromEntry);
    W.scene.add(mesh);
    RT.playSound({sound: (def && def.pickupSound) || SFX + 'pickup.wav', volume: .8});
    const b = boxOf(mesh, true), sz = b.isEmpty() ? 1 : Math.max(...b.getSize(new V3()).toArray());
    this.flying.push({mesh, from: mesh.position.clone(), q0: mesh.quaternion.clone(), s0: mesh.scale.clone(), shrink: Math.min(1, .25 / Math.max(sz, .01)), t: 0, d: .55, done: finish});
    this.dipT = .55;    // the player's view dips like they reach down for it
  },
  updateFlying(dt){
    const RT = Runtime, cam = RT.camera;
    for (const f of this.flying){
      f.t += dt; const k = Math.min(1, f.t / f.d), e = k < .5 ? 2 * k * k : 1 - Math.pow(-2 * k + 2, 2) / 2;
      const hand = cam.localToWorld(new V3(.3, -.35, -.6));
      f.mesh.position.copy(f.from).lerp(hand, e); f.mesh.position.y += Math.sin(k * Math.PI) * .5;
      f.mesh.scale.copy(f.s0).multiplyScalar(1 + (f.shrink - 1) * e);
      f.mesh.quaternion.copy(f.q0).slerp(cam.quaternion, e);
      if (k >= 1){ W.scene.remove(f.mesh); f.done(); f.dead = true; }
    }
    this.flying = this.flying.filter(f => !f.dead);
  },

  /* world pickups: a group used as an item's model can be picked up */
  pickupEntry(e){ let x = e; const RT = Runtime; for (let i = 0; x && i < 20; i++){ if (x.itemPickup && !x.dead) return x; x = x.o.parent ? RT.entries.get(x.o.parent) : null; } return null; },
  aimPickup(){
    const r = Runtime.lastPick; if (!r || !r.solid || !r.solid.e || r.solid.d > +Runtime.S.interactRange) return null;
    const p = this.pickupEntry(r.solid.e); return p && this.def(p.itemPickup) && this.def(p.itemPickup).pickupMode !== 'touch' ? p : null;
  },
  tryPickup(){ const p = this.aimPickup(); if (!p) return false; this.give(p.itemPickup, 1, {fromEntry: p, take: true, equip: true}); return true; },

  /* ---------- per frame ---------- */
  update(dt){
    const RT = Runtime, pl = RT.player; if (!pl) return;
    this.updateFlying(dt); this.updateBullets(dt);
    // touch pickups
    const pb = new THREE.Box3(new V3(pl.pos.x - pl.r, pl.pos.y, pl.pos.z - pl.r), new V3(pl.pos.x + pl.r, pl.pos.y + pl.h, pl.pos.z + pl.r));
    for (const e of RT.entries.values()) if (e.itemPickup && !e.dead && !e.hidden){ const d = this.def(e.itemPickup);
      if (d && d.pickupMode === 'touch' && boxOf(e.root, true).expandByScalar(.1).intersectsBox(pb)) this.give(e.itemPickup, 1, {fromEntry: e, take: true, equip: true}); }
    const def = this.heldDef;
    this.holder.visible = !!def && !pl.inCar && RT.S.camera !== 'third';
    this.useT -= dt; this.comboT = (this.comboT || 0) - dt; if (this.comboT <= 0) this.combo = 0;
    if (def && def.kind === 'gun'){
      if (this.reloadT > 0){ this.reloadT -= dt; if (this.reloadT <= 0) this.finishReload(def); }
      if (def.gun.auto && this.trigger && !RT.paused) this.fire(def);
    }
    this.animateHeld(dt);
  },
  /* camera dip while picking something up */
  camera(){ if (this.dipT > 0 && Runtime.camera){ const k = Math.sin((1 - this.dipT / .55) * Math.PI); Runtime.camera.position.y -= .3 * k; Runtime.camera.rotateX(-.35 * k); this.dipT -= 1 / 60; } },

  animateHeld(dt){
    const def = this.heldDef; if (!def) return;
    const RT = Runtime, pl = RT.player, H = def.hold, t = RT.time;
    const spd = Math.min(1, Math.hypot(pl.vel.x, pl.vel.z) / 6) * (pl.onGround ? 1 : .2);
    let ox = 0, oy = 0, rz = 0, ry = 0;
    const m = def.motion || 'bobsway';
    if (m === 'bobsway' || m === 'bob'){ ox = Math.sin(t * 7) * .02 * spd; oy = -Math.abs(Math.cos(t * 7)) * .025 * spd + Math.sin(t * 1.6) * .006; }
    if (m === 'bobsway'){ const dy = (pl.yaw - (this.lastYaw ?? pl.yaw)), dp = (pl.pitch - (this.lastPitch ?? pl.pitch));
      this.sway = this.sway || {x: 0, y: 0}; this.sway.x += (Math.max(-.08, Math.min(.08, dy * 1.5)) - this.sway.x) * Math.min(1, dt * 8); this.sway.y += (Math.max(-.08, Math.min(.08, dp * 1.5)) - this.sway.y) * Math.min(1, dt * 8);
      ox += this.sway.x; oy -= this.sway.y; rz = this.sway.x * 1.5; }
    if (m === 'float') oy = Math.sin(t * 2) * .03;
    if (m === 'spin') ry = t * 1.2;
    this.lastYaw = pl.yaw; this.lastPitch = pl.pitch;
    this.holder.position.set(H.pos[0] + ox, H.pos[1] + oy, H.pos[2]);
    this.holder.rotation.set(H.rot[0] * D2R, H.rot[1] * D2R + ry, H.rot[2] * D2R + rz);
    this.holder.scale.setScalar(+H.scale || 1);
    // swing / recoil / reload offsets on the inner pivot
    const pv = this.pivot; pv.position.set(0, 0, 0); pv.rotation.set(0, 0, 0);
    if (this.swing){ const s = this.swing; s.t += dt; const k = Math.min(1, s.t / s.dur);
      const pose = samplePose(s.keys, k); pv.position.fromArray(pose.p); pv.rotation.set(pose.r[0] * D2R, pose.r[1] * D2R, pose.r[2] * D2R);
      if (!s.hit && k >= s.hitAt){ s.hit = true; if (Runtime.active) this.meleeHit(def); }
      if (k >= 1) this.swing = null; }
    if (this.kick > 0){ this.kick = Math.max(0, this.kick - dt * 7); const r = +def.gun.recoil || 1; pv.position.z += this.kick * .09 * r; pv.rotation.x += this.kick * .3 * r; }
    if (this.reloadT > 0){ const k = Math.sin(Math.min(1, 1 - this.reloadT / (+def.gun.reloadTime || 1)) * Math.PI); pv.position.y -= k * .18; pv.rotation.x -= k * .9; pv.rotation.z += k * .4; }
  },

  /* ---------- using the held item (left click) ---------- */
  use(btn){
    const def = this.heldDef, RT = Runtime, pl = RT.player; if (!def || btn !== 'left' || pl.inCar || pl.locked || pl.dead) return false;
    if (def.kind === 'gun'){ this.trigger = true; this.fire(def); return true; }
    if (def.kind === 'sword' || (+def.damage > 0)){ this.startSwing(def); return true; }
    return false;
  },
  startSwing(def){
    if (this.swing || this.useT > 0) return;
    const list = def.kind === 'sword' && def.sword.motions.length ? def.sword.motions : [{preset: 'bash'}];
    const mo = list[this.combo % list.length]; this.combo++; this.comboT = 1.0;
    const P0 = SWING_PRESETS[mo.preset] || SWING_PRESETS.slash;
    const keys = mo.preset === 'custom' ? (mo.keys || []) : P0.keys;
    this.swing = {t: 0, dur: +mo.dur || P0.dur, hitAt: mo.hitAt != null ? +mo.hitAt : P0.hitAt, keys, hit: false};
    this.useT = this.swing.dur + (def.kind === 'sword' ? +def.sword.cooldown || 0 : .1);
    if (Runtime.active) Runtime.playSound({sound: (def.kind === 'sword' && def.sword.swingSound) || SFX + 'sword_swing.wav', volume: .7});
  },
  meleeHit(def){
    const RT = Runtime, pl = RT.player, cam = RT.camera, range = def.kind === 'sword' ? +def.sword.range || 2.4 : +RT.S.attackRange || 3;
    const arc = Math.cos(((def.kind === 'sword' ? +def.sword.arc : 50) || 70) * D2R);
    const eye = cam.getWorldPosition(new V3()), fwd = cam.getWorldDirection(new V3()); let hit = false;
    for (const en of RT.enemies){ if (en.dead || en.inactive || en.e.template || en.e.dead) continue;
      const c = boxOf(en.e.root, true).getCenter(new V3()), to = c.clone().sub(eye), d = to.length();
      if (d > range + en.body.r) continue; if (to.normalize().dot(fwd) < arc && d > 1) continue;
      RT.hurtEnemy(en, +def.damage || 0); hit = true;
      // knock back a little
      en.body.pos.addScaledVector(fwd.clone().setY(0).normalize(), .35); en.e.root.position.copy(en.body.pos); }
    for (const e of RT.colliders) if (e.dyn && !e.held){ const c = e.box.getCenter(new V3()), to = c.clone().sub(eye);
      if (to.length() < range + .5 && to.normalize().dot(fwd) > arc){ e.dyn.vel.addScaledVector(fwd, 5); e.dyn.vel.y += 2; hit = true; } }
    if (hit) RT.playSound({sound: (def.kind === 'sword' && def.sword.hitSound) || SFX + 'sword_hit.wav', volume: .85});
  },

  /* ---------- guns: real bullets with size, speed and drop ---------- */
  mag(def){ if (this.mags[def.name] == null) this.mags[def.name] = +def.gun.magSize; return this.mags[def.name]; },
  fire(def){
    const RT = Runtime, g = def.gun, pl = RT.player; if (this.useT > 0 || this.reloadT > 0 || pl.dead || pl.locked || pl.inCar) return;
    const at = g.ammoType || def.name;
    if (this.mag(def) <= 0){ this.useT = .3; RT.playSound({sound: g.emptySound || SFX + 'dry_fire.wav', volume: .7}); if (g.infinite || (this.ammo[at] || 0) > 0) this.reload(); return; }
    this.mags[def.name]--; this.useT = 1 / Math.max(.3, +g.fireRate || 5); this.kick = 1;
    pl.pitch = Math.min(1.5, pl.pitch + .012 * (+g.recoil || 1));
    RT.playSound({sound: g.shotSound || SFX + 'gun_shot.wav', volume: .8}); RT.doShake(.03 * (+g.recoil || 1), .08);
    // muzzle flash in the hand pass
    const front = this.pivot.children[0] ? this.pivot.children[0].userData.front || -.3 : -.3;
    this.flash.position.copy(this.holder.localToWorld(new V3(0, 0, front - .05))); this.flash.intensity = 4; setTimeout(() => this.flash.intensity = 0, 45);
    // aim at what's under the crosshair
    const cam = RT.camera, ray = RT.lookRay(); ray.far = 1000;
    const hit = this.castTargets(ray.ray.origin, ray.ray.direction, +g.range || 150);
    const target = hit ? hit.point : ray.ray.origin.clone().addScaledVector(ray.ray.direction, +g.range || 150);
    const muzzle = cam.localToWorld(new V3(def.hold.pos[0] * .6, def.hold.pos[1] * .5, -.6));
    const dir = target.clone().sub(muzzle).normalize();
    const sp = (+g.spread || 0) * D2R; if (sp){ dir.x += (Math.random() - .5) * sp * 2; dir.y += (Math.random() - .5) * sp * 2; dir.z += (Math.random() - .5) * sp * 2; dir.normalize(); }
    this.spawnBullet(muzzle, dir, def);
    this.renderHotbar();
    if (this.mags[def.name] <= 0 && (g.infinite || (this.ammo[at] || 0) > 0)) setTimeout(() => this.reload(), 250);
  },
  spawnBullet(pos, dir, def){
    const g = def.gun, col = g.bulletColor || '#ffd27a';
    const mat = this.bulletMats[col] || (this.bulletMats[col] = new THREE.MeshBasicMaterial({color: col, toneMapped: false}));
    const m = new THREE.Mesh(this.bulletGeo, mat); const sz = Math.max(.01, +g.bulletSize || .06), spd = Math.max(1, +g.bulletSpeed || 140);
    m.scale.set(sz, sz, sz * Math.min(12, Math.max(1, spd / 40))); m.position.copy(pos); W.scene.add(m);
    this.bullets.push({mesh: m, pos: pos.clone(), vel: dir.multiplyScalar(spd), life: (+g.range || 150) / spd, dmg: +def.damage || 0, drop: +g.bulletDrop || 0, size: sz});
  },
  targets(){
    const out = []; for (const e of Runtime.entries.values()) if (!e.dead && !e.held && e.root.visible && !e.itemFly && !['interaction','spawn','light','weapon','ammo','group'].includes(e.o.type) && (!e.enemy || !e.enemy.dead)) out.push(e.root);
    return out;
  },
  castTargets(origin, dir, far){
    const rc = this._rc || (this._rc = new THREE.Raycaster()); rc.set(origin, dir); rc.far = far; rc.camera = Runtime.camera;
    return rc.intersectObjects(this._tg || this.targets(), true).filter(x => visibleChain(x.object) && !x.object.isSprite)[0] || null;
  },
  updateBullets(dt){
    if (!this.bullets.length) return; this._tg = this.targets();
    for (const b of this.bullets){
      b.life -= dt; b.vel.y -= b.drop * 9.8 * dt;
      const step = b.vel.clone().multiplyScalar(dt), len = step.length();
      const hit = this.castTargets(b.pos, step.clone().normalize(), len + b.size);
      if (hit){ const e = Runtime.entryOf(hit.object);
        if (e && e.enemy) Runtime.hurtEnemy(e.enemy, b.dmg);
        if (e && e.dyn && !e.held) e.dyn.vel.addScaledVector(b.vel.clone().normalize(), Math.min(8, 2 + b.size * 30));
        Gameplay.spark(hit.point); b.life = 0; }
      b.pos.add(step); b.mesh.position.copy(b.pos); b.mesh.lookAt(b.pos.clone().add(b.vel));
      if (b.life <= 0){ W.scene.remove(b.mesh); b.dead = true; }
    }
    this._tg = null; this.bullets = this.bullets.filter(b => !b.dead);
  },
  reload(){
    const def = this.heldDef; if (!def || def.kind !== 'gun') return; const g = def.gun, at = g.ammoType || def.name;
    if (this.reloadT > 0 || this.mag(def) >= +g.magSize || !(g.infinite || this.ammo[at] > 0)) return;
    this.reloadT = +g.reloadTime || 1.4; Runtime.playSound({sound: g.reloadSound || SFX + 'reload.wav', volume: .8}); this.renderHotbar();
  },
  finishReload(def){ const g = def.gun, at = g.ammoType || def.name, need = +g.magSize - this.mag(def);
    const take = g.infinite ? need : Math.min(need, this.ammo[at] || 0); this.mags[def.name] += take; if (!g.infinite) this.ammo[at] -= take; this.renderHotbar(); },

  /* old "Gun pickup" objects become hotbar items */
  pickWeaponObject(e){
    const w = e.o.weapon, name = w.name || 'Gun';
    if (!this.def(name)){ const d = newItemDef(name); d.kind = 'gun'; d.size = w.kind === 'rifle' ? .75 : .4; d.damage = +w.damage;
      Object.assign(d.gun, {builtin: w.kind, magSize: +w.magSize, startAmmo: +w.startAmmo, ammoType: w.ammoType, fireRate: +w.fireRate, auto: !!w.auto, reloadTime: +w.reloadTime, range: +w.range, shotSound: w.sound || '', reloadSound: w.reloadSound || ''});
      this.extraDefs[name] = d; }
    const have = (Runtime.player.inv[name] || 0) > 0;
    if (have){ const at = w.ammoType || name; this.ammo[at] = (this.ammo[at] || 0) + (+w.startAmmo || 0); Runtime.toast(`+${w.startAmmo} ${at} ammo`); Runtime.destroy(e); this.renderHotbar(); return; }
    this.give(name, 1, {fromEntry: e, take: true, equip: true});
  },
  addAmmo(type, n){ this.ammo[type] = (this.ammo[type] || 0) + n; this.renderHotbar(); },

  state(){ return {slots: this.slots.slice(), sel: this.sel, ammo: clone(this.ammo), mags: clone(this.mags), extra: clone(this.extraDefs)}; },
  restore(s){ if (!s) return; this.extraDefs = clone(s.extra || {}); this.ammo = clone(s.ammo || {}); this.mags = clone(s.mags || {}); this.slots = (s.slots || []).slice(); this.sel = -1; this.syncSlots(); if (s.sel >= 0) this.select(s.sel, true); this.renderHotbar(); },

  /* ---------- editor preview: the selected item's model held in front of the editor camera ---------- */
  previewDef: null,
  preview(def){
    this.initVM(); this.previewDef = def || null;
    if (!def){ if (!Runtime.active) this.setHeld(null); return; }
    this.setHeld(def); this.holder.visible = true;
  },
  editorUpdate(dt){
    const def = this.previewDef; if (!def || Runtime.active) return;
    const H = def.hold, t = performance.now() / 1000;
    this.holder.position.set(H.pos[0], H.pos[1] + (def.motion === 'float' ? Math.sin(t * 2) * .03 : 0), H.pos[2]);
    this.holder.rotation.set(H.rot[0] * D2R, H.rot[1] * D2R + (def.motion === 'spin' ? t * 1.2 : 0), H.rot[2] * D2R); this.holder.scale.setScalar(+H.scale || 1);
    const pv = this.pivot; pv.position.set(0, 0, 0); pv.rotation.set(0, 0, 0);
    if (this.swing){ const s = this.swing; s.t += dt; const k = Math.min(1, s.t / s.dur); const pose = samplePose(s.keys, k);
      pv.position.fromArray(pose.p); pv.rotation.set(pose.r[0] * D2R, pose.r[1] * D2R, pose.r[2] * D2R); if (k >= 1) this.swing = null; }
    if (this.kick > 0){ this.kick = Math.max(0, this.kick - dt * 7); pv.position.z += this.kick * .09 * (+def.gun.recoil || 1); pv.rotation.x += this.kick * .3 * (+def.gun.recoil || 1); }
  },
  testUse(def){
    if (def.kind === 'gun'){ this.kick = 1; const s = def.gun.shotSound || SFX + 'gun_shot.wav'; previewAudio(VFS.has(s) ? s : ensureAsset(s)); }
    else { this.useT = 0; this.swing = null; this.startSwing(def); const s = def.sword.swingSound || SFX + 'sword_swing.wav'; previewAudio(VFS.has(s) ? s : ensureAsset(s)); }
  },
};

/* keyframe sampling: keys are {t: 0..1, p: [x,y,z] meters, r: [x,y,z] degrees}; rest pose at t=0 and t=1 */
function samplePose(keys, k){
  const ks = [{t: 0, p: [0, 0, 0], r: [0, 0, 0]}, ...(keys || []).filter(x => x.t > 0 && x.t < 1).sort((a, b) => a.t - b.t), {t: 1, p: [0, 0, 0], r: [0, 0, 0]}];
  let i = 0; while (i < ks.length - 2 && k > ks[i + 1].t) i++;
  const a = ks[i], b = ks[i + 1], u = Math.max(0, Math.min(1, (k - a.t) / Math.max(1e-4, b.t - a.t))), s = u * u * (3 - 2 * u);
  const L = (x, y) => x.map((v, j) => +v + ((+y[j]) - (+v)) * s);
  return {p: L(a.p, b.p), r: L(a.r, b.r)};
}
