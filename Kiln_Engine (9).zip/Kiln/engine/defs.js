/* ---------- Definitions: object types, action schema, text styles ---------- */
var P = null;   // the open project (set in main.js)
const uid = (p='o') => p + '_' + Math.random().toString(36).slice(2, 9);
const clone = o => JSON.parse(JSON.stringify(o));

const DEFAULT_SETTINGS = () => ({
  walkSpeed: 4.5, runSpeed: 8, jumpForce: 6, gravity: 18, airControl: 0.6,
  playerHeight: 1.7, playerRadius: 0.35, eyeHeight: 1.6, stepHeight: 0.4,
  maxHealth: 100, playerDamage: 25, attackRange: 3, attackCooldown: 0.45,
  interactRange: 3.5, mouseSensitivity: 1.0, invertY: false, fov: 75,
  camera: 'first', thirdPersonDistance: 4,
  killY: -40, footstepSound: '', hurtSound: '', footstepInterval: 0.42, music: '', musicVolume: 0.5,
  sky: '#8fb6d9', fogColor: '#8fb6d9', fogNear: 30, fogFar: 160, ambient: 0.55, sunIntensity: 1.1,
  shadows: true, pixelRatio: 1, antialias: true, showFps: true, showHud: true,
  keys: { forward:'KeyW', back:'KeyS', left:'KeyA', right:'KeyD', jump:'Space', run:'ShiftLeft', interact:'KeyE',
          lookLeft:'ArrowLeft', lookRight:'ArrowRight', lookUp:'ArrowUp', lookDown:'ArrowDown',
          pause:'KeyP', quickSave:'F5', quickLoad:'F9', aim:'KeyZ', reload:'KeyR' },
  aimZoom: 2.2, throwForce: 12, bhop: true, bhopGain: 1.06, bhopMax: 22, renderHeight: 0, fpsCap: 0, pixelated: false, fullscreen: false,
});
const KEY_LABELS = {forward:'Move forward', back:'Move back', left:'Strafe left', right:'Strafe right', jump:'Jump', run:'Run (hold)',
  interact:'Interact (look + key)', lookLeft:'Look left', lookRight:'Look right', lookUp:'Look up', lookDown:'Look down',
  aim:'Aim / zoom (hold)', reload:'Reload gun', pause:'Pause menu', quickSave:'Quick save', quickLoad:'Quick load'};

const TYPES = {
  box:        {label:'Box / Wall',        color:'#9aa3b3', group:'Shapes'},
  sphere:     {label:'Sphere',            color:'#9aa3b3', group:'Shapes'},
  cylinder:   {label:'Cylinder',          color:'#9aa3b3', group:'Shapes'},
  cone:       {label:'Cone',              color:'#9aa3b3', group:'Shapes'},
  plane:      {label:'Floor plane',       color:'#9aa3b3', group:'Shapes'},
  ramp:       {label:'Ramp',              color:'#9aa3b3', group:'Shapes'},
  decal:      {label:'Image / Decal',     color:'#6fd3f0', group:'Shapes'},
  text3d:     {label:'3D Text sign',      color:'#6fd3f0', group:'Shapes'},
  model:      {label:'3D Model (FBX/GLB)',color:'#a98bff', group:'Gameplay'},
  interaction:{label:'Interaction block', color:'#f2a33a', group:'Gameplay'},
  enemy:      {label:'Enemy / NPC',       color:'#ef5b5b', group:'Gameplay'},
  spawn:      {label:'Player spawn',      color:'#5ccf8a', group:'Gameplay'},
  light:      {label:'Point light',       color:'#ffe08a', group:'Gameplay'},
  weapon:     {label:'Gun pickup',        color:'#e8c33a', group:'Assets'},
  ammo:       {label:'Ammo box',          color:'#e8c33a', group:'Assets'},
  checkpoint: {label:'Checkpoint',        color:'#3fd27a', group:'Assets'},
  vehicle:    {label:'Car',               color:'#4cc3e0', group:'Assets'},
  group:      {label:'Group',             color:'#c9a2ff', group:'Hidden'},
};

function newObject(type, over){
  const o = {id: uid(), name: TYPES[type].label.split(' ')[0] + ' ' + (P ? P.objects.filter(x => x.type === type).length + 1 : 1),
    type, tags: [], pos:[0,0.5,0], rot:[0,0,0], scale:[1,1,1], color:'#c8ccd4', texture:'', texRepeat:[1,1],
    opacity:1, emissive:'#000000', roughness:0.8, metalness:0, visible:true, collide:true, castShadow:true, physics:'static',
    pickable:false, slippery:false, pickItem:'', pickSound:'',
    password:{enabled:false, code:'1234', prompt:'Enter password', event:'', failEvent:'', once:true, showText:false},
    damage:{on:false, amount:10, perSecond:false, kill:false}};
  if (type === 'plane'){ o.scale = [20,1,20]; o.pos = [0,0,0]; o.color = '#7d8a6a'; }
  if (type === 'decal'){ o.collide = false; o.color = '#ffffff'; o.scale = [2,2,1]; o.pos = [0,1.5,0]; o.doubleSided = true; }
  if (type === 'text3d'){ o.collide = false; o.text = 'Hello'; o.font = 'Bebas Neue'; o.fontSize = 96; o.textColor = '#ffffff';
    o.textBg = '#00000088'; o.billboard = false; o.scale = [3,1,1]; o.pos = [0,2,0]; }
  if (type === 'model'){ o.model = ''; o.normalize = true; o.scale = [2,2,2]; o.pos = [0,0,0]; o.color = '#ffffff'; o.anim = ''; o.useModelMaterials = true; }
  if (type === 'interaction'){ o.collide = false; o.color = '#f2a33a'; o.scale = [1.2,2,1.2]; o.pos = [0,1,0];
    o.interact = {mode:'left', event:'', once:false, cooldown:0.5, requireItem:'', consumeItem:false, prompt:'Interact', enabled:true, sound:''}; }
  if (type === 'enemy'){ o.collide = false; o.color = '#c0504d'; o.pos = [0,0,0]; o.scale = [1,1,1];
    o.enemy = {hostile:true, health:100, speed:2.5, damage:10, attackRange:1.4, attackRate:1.0, aggroRange:12, spawnOnStart:true,
      model:'', normalize:true, height:1.8, clipIdle:'', clipWalk:'', clipAttack:'', clipDeath:'', joints:{}, motion:'walk-cycle',
      hurtSound:'', deathSound:'', attackSound:'', deathEvent:'', showHealthBar:true}; }
  if (type === 'weapon'){ o.collide = false; o.pos = [0,.6,0]; o.weapon = {name:'Pistol', kind:'pistol', ammoType:'pistol', damage:25, magSize:12, startAmmo:36, fireRate:5, reloadTime:1.4, auto:false, range:80, sound:'', reloadSound:''}; }
  if (type === 'ammo'){ o.collide = false; o.pos = [0,.3,0]; o.ammo = {ammoType:'pistol', amount:24}; }
  if (type === 'checkpoint'){ o.collide = false; o.pos = [0,0,0]; o.checkpoint = {event:'', sound:''}; }
  if (type === 'vehicle'){ o.pos = [0,0,0]; o.color = '#c0392b'; o.vehicle = {topSpeed:160, power:9, steering:1, engineSound:'', shiftSound:''}; }
  if (type === 'group'){ o.collide = false; o.pos = [0,0,0]; }
  if (type === 'spawn'){ o.collide = false; o.pos = [0,0,0]; o.color = '#5ccf8a'; }
  if (type === 'light'){ o.collide = false; o.pos = [0,3,0]; o.color = '#ffd58a'; o.intensity = 1.5; o.distance = 14; }
  if (['ramp','cone','sphere','cylinder','box'].includes(type) && type !== 'box') o.color = '#b7bcc6';
  return Object.assign(o, over || {});
}

/* Action parameter field types:
   num, int, text, area, bool, color, sel:[...], target (tag or name), asset:image|audio|model, event, font, xyz */
const TARGET_HELP = 'Tag or object name. Every object with this tag is affected.';
const ACTIONS = {
  rotate:      {label:'Rotate object',          k:'obj', p:{target:'target', mode:['by','to'], x:0, y:90, z:0, duration:0.6, ease:['smooth','linear','bounce']}},
  move:        {label:'Move object',            k:'obj', p:{target:'target', mode:['by','to'], x:0, y:2, z:0, duration:1, ease:['smooth','linear','bounce']}},
  scale:       {label:'Scale object',           k:'obj', p:{target:'target', mode:['to','by'], x:1, y:1, z:1, duration:0.5, ease:['smooth','linear','bounce']}},
  setVisible:  {label:'Show / hide object',     k:'obj', p:{target:'target', visible:true, alsoCollision:true}},
  toggleVisible:{label:'Toggle visibility',     k:'obj', p:{target:'target'}},
  setCollision:{label:'Collision on / off',     k:'obj', p:{target:'target', on:false}},
  destroy:     {label:'Destroy object',         k:'obj', p:{target:'target'}},
  setTexture:  {label:'Change texture',         k:'obj', p:{target:'target', texture:'asset:image'}},
  setColor:    {label:'Change color',           k:'obj', p:{target:'target', color:'#ff4444', duration:0.4}},
  setText3D:   {label:'Change 3D sign text',    k:'obj', p:{target:'target', text:'area'}},
  playAnimation:{label:'Play model animation',  k:'obj', p:{target:'target', clip:'clip', loop:true}},
  enableInteraction:{label:'Enable / disable interaction', k:'obj', p:{target:'target', on:false}},

  giveItem:    {label:'Give player item',       k:'player', p:{item:'item', count:1, notify:true, animate:true, from:'target', takeObject:false, equip:false}},
  takeItem:    {label:'Take item from player',  k:'player', p:{item:'item', count:1}},
  teleport:    {label:'Teleport player',        k:'player', p:{x:0, y:1, z:0, setYaw:false, yaw:0, toTarget:'text'}},
  lockPlayer:  {label:'Lock / unlock player',   k:'player', p:{on:true}},
  damagePlayer:{label:'Damage player',          k:'player', p:{amount:10}},
  healPlayer:  {label:'Heal player',            k:'player', p:{amount:25}},
  setSpeed:    {label:'Change move speed',      k:'player', p:{walk:4.5, run:8}},
  setGravity:  {label:'Change gravity / jump',  k:'player', p:{gravity:18, jump:6}},

  cameraLock:  {label:'Lock camera at XYZ',     k:'fx', p:{x:0, y:3, z:6, lookAt:'target', lx:0, ly:1, lz:0, follow:true, blend:0.6, duration:0}},
  cameraRelease:{label:'Release camera',        k:'fx', p:{blend:0.6}},
  cameraShake: {label:'Camera shake',           k:'fx', p:{intensity:0.3, duration:0.6}},
  fadeOut:     {label:'Fade screen out',        k:'fx', p:{duration:0.6, color:'#000000'}},
  fadeIn:      {label:'Fade screen in',         k:'fx', p:{duration:0.8}},
  blackout:    {label:'Complete blackout',      k:'fx', p:{on:true, color:'#000000'}},
  showTitle:   {label:'Show title text',        k:'fx', p:{text:'area', subtitle:'text', duration:3, preset:'preset', style:'style'}},
  showDialogue:{label:'Show dialogue / subtitle',k:'fx', p:{speaker:'text', text:'area', duration:4, typeSpeed:40}},
  hideText:    {label:'Clear all text',         k:'fx', p:{}},

  playSound:   {label:'Play sound file',        k:'sound', p:{sound:'asset:audio', volume:1, loop:false, channel:'text', at:'text'}},
  stopSound:   {label:'Stop sound',             k:'sound', p:{channel:'text', fade:0.3}},

  spawnEnemy:  {label:'Spawn enemy / NPC',      k:'enemy', p:{template:'target', count:1, atTemplate:true, x:0, y:0, z:0, spread:1.5}},
  killEnemy:   {label:'Kill enemy / NPC',       k:'enemy', p:{target:'target'}},
  damageEnemy: {label:'Damage enemy',           k:'enemy', p:{target:'target', amount:25}},
  npcMoveTo:   {label:'Walk NPC to XYZ',        k:'enemy', p:{target:'target', x:0, y:0, z:0, speed:2}},
  npcFacePlayer:{label:'NPC faces player',      k:'enemy', p:{target:'target'}},
  setHostile:  {label:'Enemy hostile on / off', k:'enemy', p:{target:'target', on:true}},

  triggerEvent:{label:'Run another event',      k:'flow', p:{event:'event'}},
  stopEvent:   {label:'Stop an event',          k:'flow', p:{event:'event'}},
  setFlag:     {label:'Set flag',               k:'flow', p:{flag:'text', value:'text'}},
  saveGame:    {label:'Save game (checkpoint)', k:'flow', p:{slot:'text'}},
  log:         {label:'Debug log',              k:'flow', p:{message:'text'}},
};
const ACTION_GROUPS = {obj:'Objects', player:'Player', fx:'Screen, camera & text', sound:'Sound', enemy:'Enemies & NPCs', flow:'Flow'};
const ACTION_DURATION = a => (a.duration != null ? +a.duration : a.type === 'showTitle' ? +(a.duration||3) : 0) || 0;

/* Field defaults: strings that are type hints get blank values */
function actionDefaults(type){
  const p = ACTIONS[type].p, out = {};
  for (const k in p){ const v = p[k];
    if (Array.isArray(v)) out[k] = v[0];
    else if (typeof v === 'number' || typeof v === 'boolean') out[k] = v;
    else if (/^#/.test(v)) out[k] = v;
    else if (v === 'style') out[k] = clone(TEXT_PRESETS.Cinematic);
    else if (v === 'preset') out[k] = 'Cinematic';
    else out[k] = '';
  }
  return out;
}

/* ---------- Triggers (what starts an event) ---------- */
const TRIGGER_TYPES = {
  start:      'When the game starts',
  time:       'At N seconds of game time',
  touch:      'When player touches object (tag)',
  key:        'When a key is pressed',
  enemyKilled:'When enemy (tag) is killed',
  objTouch:   'When object touches another object',
  clickLeft:  'When object is clicked (left)',
  clickRight: 'When object is clicked (right)',
  aim:        'When object is aimed at',
  itemCount:  'When player has N of item',
  flag:       'When flag equals value',
};

/* ---------- Text styling ---------- */
const FONTS = ['Barlow','Bebas Neue','Cinzel','Creepster','Press Start 2P','Orbitron','Special Elite','Noto Sans KR','Black Han Sans','Georgia','Impact','Courier New','Arial','VT323','Share Tech Mono','Silkscreen','Audiowide','Michroma','Righteous','Bungee','Monoton','Shrikhand','Syncopate'];
const TEXT_STYLE_FIELDS = {
  font:['font'], size:['num',8,200], color:['color'], weight:['sel',['400','600','800','900']], italic:['bool'], uppercase:['bool'],
  letterSpacing:['num',-2,30], align:['sel',['center','left','right']],
  position:['sel',['center','top','bottom','lower-third','custom']], x:['num',0,100], y:['num',0,100],
  stroke:['num',0,12], strokeColor:['color'], shadow:['sel',['none','drop','glow','hard']], glowColor:['color'],
  bg:['sel',['none','box','bar']], bgColor:['color'],
  animIn:['sel',['fade','typewriter','slideUp','slideDown','zoom','shake','glitch','wave','none']], animOut:['sel',['fade','none']], fadeTime:['num',0,5],
  subSize:['num',8,120], subColor:['color'],
};
const TEXT_PRESETS = {
  Cinematic:{font:'Cinzel', size:52, color:'#ffffff', weight:'800', italic:false, uppercase:true, letterSpacing:8, align:'center', position:'center', x:50, y:50,
    stroke:0, strokeColor:'#000000', shadow:'glow', glowColor:'#000000', bg:'none', bgColor:'#000000aa', animIn:'fade', animOut:'fade', fadeTime:0.8, subSize:20, subColor:'#d8d8d8'},
  Horror:{font:'Creepster', size:72, color:'#d92b2b', weight:'400', italic:false, uppercase:false, letterSpacing:3, align:'center', position:'center', x:50, y:50,
    stroke:2, strokeColor:'#200000', shadow:'glow', glowColor:'#ff0000', bg:'none', bgColor:'#000000aa', animIn:'shake', animOut:'fade', fadeTime:0.5, subSize:22, subColor:'#ffb0b0'},
  Retro:{font:'Press Start 2P', size:30, color:'#ffe066', weight:'400', italic:false, uppercase:true, letterSpacing:2, align:'center', position:'top', x:50, y:20,
    stroke:0, strokeColor:'#000000', shadow:'hard', glowColor:'#000000', bg:'none', bgColor:'#000000aa', animIn:'typewriter', animOut:'none', fadeTime:0.2, subSize:14, subColor:'#ffffff'},
  SciFi:{font:'Orbitron', size:44, color:'#7ff6ff', weight:'800', italic:false, uppercase:true, letterSpacing:6, align:'center', position:'center', x:50, y:50,
    stroke:0, strokeColor:'#000000', shadow:'glow', glowColor:'#00c8ff', bg:'bar', bgColor:'#001820cc', animIn:'glitch', animOut:'fade', fadeTime:0.5, subSize:18, subColor:'#b9fbff'},
  Typewriter:{font:'Special Elite', size:34, color:'#f2ead8', weight:'400', italic:false, uppercase:false, letterSpacing:1, align:'left', position:'lower-third', x:8, y:75,
    stroke:0, strokeColor:'#000000', shadow:'drop', glowColor:'#000000', bg:'none', bgColor:'#000000aa', animIn:'typewriter', animOut:'fade', fadeTime:0.4, subSize:18, subColor:'#c8c0ae'},
  Impact:{font:'Bebas Neue', size:90, color:'#ffffff', weight:'400', italic:false, uppercase:true, letterSpacing:4, align:'center', position:'center', x:50, y:50,
    stroke:3, strokeColor:'#000000', shadow:'drop', glowColor:'#000000', bg:'none', bgColor:'#000000aa', animIn:'zoom', animOut:'fade', fadeTime:0.3, subSize:24, subColor:'#ffffff'},
  Korean:{font:'Black Han Sans', size:60, color:'#ffffff', weight:'400', italic:false, uppercase:false, letterSpacing:2, align:'center', position:'center', x:50, y:50,
    stroke:0, strokeColor:'#000000', shadow:'glow', glowColor:'#000000', bg:'none', bgColor:'#000000aa', animIn:'slideUp', animOut:'fade', fadeTime:0.6, subSize:22, subColor:'#e6e6e6'},
  GeometryDash:{font:'Geometry Dash', size:52, color:'#ffffff', weight:'400', italic:false, uppercase:false, letterSpacing:2, align:'center', position:'center', x:50, y:50,
    stroke:4, strokeColor:'#000000', shadow:'hard', glowColor:'#000000', bg:'none', bgColor:'#000000aa', animIn:'zoom', animOut:'fade', fadeTime:0.35, subSize:26, subColor:'#ffe066'},
  Boxed:{font:'Barlow', size:28, color:'#ffffff', weight:'600', italic:false, uppercase:false, letterSpacing:0, align:'center', position:'bottom', x:50, y:85,
    stroke:0, strokeColor:'#000000', shadow:'none', glowColor:'#000000', bg:'box', bgColor:'#000000bb', animIn:'fade', animOut:'fade', fadeTime:0.3, subSize:16, subColor:'#cfcfcf'},
};

const EASE = {
  linear: t => t,
  smooth: t => t < .5 ? 2*t*t : 1 - Math.pow(-2*t + 2, 2) / 2,
  bounce: t => { const n = 7.5625, d = 2.75; if (t < 1/d) return n*t*t; if (t < 2/d) return n*(t -= 1.5/d)*t + .75; if (t < 2.5/d) return n*(t -= 2.25/d)*t + .9375; return n*(t -= 2.625/d)*t + .984375; },
};

const RESOLUTIONS = [[0, 'Native (screen)'], [360, '360p (retro)'], [480, '480p'], [720, '720p (HD)'], [900, '900p'], [1080, '1080p (Full HD)'], [1440, '1440p'], [2160, '2160p (4K)']];
const FPS_CAPS = [[0, 'Unlimited (screen refresh)'], [30, '30 FPS'], [60, '60 FPS'], [75, '75 FPS'], [120, '120 FPS'], [144, '144 FPS'], [240, '240 FPS']];
