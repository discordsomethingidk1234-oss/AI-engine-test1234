/* ---------- Editor ---------- */
function h(tag, attrs, ...kids){
  const el = document.createElement(tag);
  if (attrs) for (const k in attrs){ const v = attrs[k]; if (v == null) continue;
    if (k === 'class') el.className = v; else if (k === 'style') el.style.cssText = v;
    else if (k.startsWith('on') && typeof v === 'function') el.addEventListener(k.slice(2), v);
    else if (k in el && !['list','type'].includes(k)) el[k] = v; else el.setAttribute(k, v); }
  for (const c of kids.flat(Infinity)) if (c != null && c !== false) el.append(c.nodeType ? c : document.createTextNode(String(c)));
  return el;
}
const UI = {
  num(v, onIn, onCh, step){ const i = h('input', {type: 'number', value: round(v), step: step || 0.1}); i.addEventListener('input', () => { if (i.value !== '' && onIn) onIn(+i.value); }); i.addEventListener('change', () => onCh && onCh(+i.value || 0)); return i; },
  text(v, onCh, ph, list){ const i = h('input', {type: 'text', value: v == null ? '' : v, placeholder: ph || ''}); if (list) i.setAttribute('list', list); i.addEventListener('change', () => onCh(i.value)); return i; },
  area(v, onCh){ const t = h('textarea', {rows: 3}); t.value = v || ''; t.addEventListener('change', () => onCh(t.value)); return t; },
  chk(v, onCh){ const i = h('input', {type: 'checkbox'}); i.checked = !!v; i.addEventListener('change', () => onCh(i.checked)); return i; },
  color(v, onCh, live){ const i = h('input', {type: 'color', value: /^#[0-9a-f]{6}$/i.test(v) ? v : '#ffffff'}); if (live) i.addEventListener('input', () => live(i.value)); i.addEventListener('change', () => onCh(i.value)); return i; },
  sel(opts, v, onCh){ const s = h('select'); for (const o of opts){ const [val, lab] = Array.isArray(o) ? o : [o, o]; const op = h('option', {value: val}, lab); if (String(val) === String(v)) op.selected = true; s.append(op); }
    s.addEventListener('change', () => onCh(s.value)); return s; },
  row(label, ...c){ return h('div', {class: 'row'}, h('label', {title: label}, label), h('div', null, ...c)); },
  sec(title, ...c){ return h('div', {class: 'sec'}, h('div', {class: 'sec-t'}, title), ...c); },
  xyz(arr, onIn, onCh, step){ const w = h('div', {class: 'xyz'});
    ['X','Y','Z'].forEach((L, i) => { const inp = UI.num(arr[i], v => { arr[i] = v; onIn && onIn(); }, v => { arr[i] = v; onCh && onCh(); }, step); w.append(h('label', null, inp, h('span', null, L))); }); return w; },
  /* asset picker: dropdown + drag target */
  asset(kind, v, onCh){
    const opts = [['', '— none —'], ...VFS.list(kind).map(p => [p, p.replace(/^assets\//, '')])];
    if (v && !VFS.has(v)) opts.push([v, '⚠ missing: ' + v]);
    const s = UI.sel(opts, v, onCh);
    const slot = h('div', {class: 'slot'}); if (kind === 'image' && v && VFS.url(v)) slot.append(h('img', {src: VFS.url(v)}));
    slot.append(s); s.style.border = '0'; s.style.background = 'transparent';
    if (kind === 'audio') slot.append(h('button', {class: 'small', title: 'Preview', onclick: () => previewAudio(s.value)}, '▶'));
    slot.addEventListener('dragover', e => { if (e.dataTransfer.types.includes('text/kiln-asset')){ e.preventDefault(); slot.classList.add('over'); } });
    slot.addEventListener('dragleave', () => slot.classList.remove('over'));
    slot.addEventListener('drop', e => { e.preventDefault(); slot.classList.remove('over'); const p = e.dataTransfer.getData('text/kiln-asset');
      if (p && VFS.kindOf(p) === kind) onCh(p); else if (p) Editor.flash('That slot needs a ' + kind + ' file'); });
    return slot;
  },
};
function round(v){ return typeof v === 'number' ? Math.round(v * 1000) / 1000 : v; }
let _prev = null; function previewAudio(p){ if (_prev){ _prev.pause(); _prev = null; } const u = VFS.url(p); if (u){ _prev = new Audio(u); _prev.play().catch(() => {}); } }

const Editor = {
  sel: null, extra: new Set(), dragSelect: false, selEvent: null, selAction: null, folder: 'assets/textures', pps: 90,
  undoStack: [], redoStack: [], lastState: null, saveTimer: null, unsaved: false,

  init(){
    const c = W.renderer.domElement;
    this.orbit = new THREE.OrbitControls(W.camera, c); this.orbit.target.set(0, 1, 0); this.orbit.enableDamping = true; this.orbit.dampingFactor = .12;
    this.orbit.screenSpacePanning = true; this.orbit.enableZoom = false; this.orbit.enableRotate = false; this.orbit.update();
    // hold left mouse = look around (like a game). WASD then moves where you look. Right-drag pans.
    c.addEventListener('pointerdown', e => { if (Runtime.active || e.button !== 0 || this.dragSelect || this.gizmo.axis) return;
      this.look = {x: e.clientX, y: e.clientY}; }, true);
    window.addEventListener('pointermove', e => { const L = this.look; if (!L || Runtime.active || this.gizmo.dragging) return;
      const dx = e.clientX - L.x, dy = e.clientY - L.y; L.x = e.clientX; L.y = e.clientY;
      const eu = new THREE.Euler().setFromQuaternion(W.camera.quaternion, 'YXZ');
      eu.y -= dx * .0045; eu.x = Math.max(-1.55, Math.min(1.55, eu.x - dy * .0045)); eu.z = 0; W.camera.quaternion.setFromEuler(eu);
      const dist = Math.max(1, W.camera.position.distanceTo(this.orbit.target));
      this.orbit.target.copy(W.camera.position).add(new THREE.Vector3(0, 0, -dist).applyQuaternion(W.camera.quaternion)); });
    window.addEventListener('pointerup', () => { this.look = null; });
    // constant-speed wheel zoom: camera + pivot move together, so it never slows down near the target
    c.addEventListener('wheel', e => { if (Runtime.active) return; e.preventDefault();
      const dir = new THREE.Vector3(); W.camera.getWorldDirection(dir);
      const step = -Math.sign(e.deltaY) * Math.min(Math.abs(e.deltaY), 150) * 0.09 * (e.shiftKey ? 3 : 1);
      W.camera.position.addScaledVector(dir, step); this.orbit.target.addScaledVector(dir, step); }, {passive: false});
    // WASD fly (Q/E down/up, Shift faster) — works with or without a selection
    this.flyKeys = new Set();
    const flyCodes = ['KeyW','KeyA','KeyS','KeyD','KeyQ','KeyE','ShiftLeft','ShiftRight'];
    window.addEventListener('keydown', e => { if (Runtime.active || e.ctrlKey || e.metaKey || /^(INPUT|TEXTAREA|SELECT)$/.test(document.activeElement.tagName)) return;
      if (flyCodes.includes(e.code)) this.flyKeys.add(e.code); });
    window.addEventListener('keyup', e => this.flyKeys.delete(e.code));
    window.addEventListener('blur', () => this.flyKeys.clear());
    this.gizmo = new THREE.TransformControls(W.camera, c); this.gizmo.setSize(.9);
    W.scene.add(this.gizmo);
    this.gizmo.addEventListener('dragging-changed', e => { this.orbit.enabled = !e.value;
      if (e.value){ const r = W.roots.get(this.sel); this.gStart = r ? {p: r.position.clone(), r: r.rotation.clone(), s: r.scale.clone(),
        others: [...(this.extra || [])].map(id => { const x = W.roots.get(id); return x ? {id, p: x.position.clone(), r: x.rotation.clone(), s: x.scale.clone()} : null; }).filter(Boolean)} : null; }
      else this.commit(); });
    this.gizmo.addEventListener('objectChange', () => this.fromGizmo());
    this.helper = new THREE.BoxHelper(new THREE.Object3D(), 0xf2a33a); this.helper.visible = false; W.scene.add(this.helper);
    this.raycaster = new THREE.Raycaster();
    // click to select (ignore drags)
    let down = null;
    c.addEventListener('pointerdown', e => { down = {x: e.clientX, y: e.clientY}; this._skipClick = false; this.beginDrag(e); }, true);
    c.addEventListener('pointermove', e => this.moveDrag(e));
    window.addEventListener('pointerup', () => this.endDrag());
    c.addEventListener('pointerup', e => { if (Runtime.active || !down) return; if (Math.hypot(e.clientX - down.x, e.clientY - down.y) > 4 || this.gizmo.dragging) return;
      if (e.button !== 0) return; if (this._skipClick){ this._skipClick = false; return; }
      const hit = this.pickAt(e.clientX, e.clientY); let id = hit ? hit.id : null;
      if (id && !e.altKey) id = this.topGroup(id);
      this.select(id, (e.shiftKey || e.ctrlKey || e.metaKey) ? 'toggle' : undefined); });
    document.addEventListener('pointerdown', e => { const t = e.target;
      this.area = t.closest && t.closest('#tab-timeline') ? 'timeline' : (t.closest && t.closest('#viewport, #left, #right')) ? 'scene' : this.area; }, true);
    c.addEventListener('dblclick', () => this.focus());
    this.bindDrop(c.parentElement);
    this.bindKeys(); this.bindToolbar(); this.buildAddMenu();
    document.querySelectorAll('.tabs button').forEach(b => b.onclick = () => this.tab(b.dataset.tab));
    $('#hierFilter').oninput = () => this.renderHierarchy();
    $('#projName').onchange = e => { P.name = e.target.value || 'MyGame'; this.commit(); };
    VFS.on(() => { Fonts.sync(); if (!Runtime.active){ this.renderAssets(); } });
    Fonts.init(); setEditorFont(getEditorFont());
  },

  /* ----- project load ----- */
  load(project){
    Runtime.active && Runtime.stop();
    P = project; P.settings = Object.assign(DEFAULT_SETTINGS(), P.settings || {}); P.settings.keys = Object.assign(DEFAULT_SETTINGS().keys, P.settings.keys || {});
    P.objects = P.objects || []; P.events = P.events || []; P.triggers = P.triggers || []; P.items = (P.items || []).map(normItem); P.saves = P.saves || {};
    for (const o of P.objects){ const d = newObject(o.type); for (const k in d) if (o[k] === undefined) o[k] = d[k];
      if (d.interact) o.interact = Object.assign(d.interact, o.interact); if (d.enemy) o.enemy = Object.assign(d.enemy, o.enemy); }
    W.invalidateTextures(); W.modelCache.clear(); W.applyEnvironment(); W.buildAll();
    this.sel = null; this.selEvent = P.events[0] ? P.events[0].id : null; this.selAction = null;
    this.undoStack = []; this.redoStack = []; this.lastState = this.state();
    $('#projName').value = P.name || 'MyGame';
    this.gizmo.detach(); this.helper.visible = false;
    this.refreshAll(); this.setUnsaved(false);
  },
  state(){ return JSON.stringify({objects: P.objects, events: P.events, triggers: P.triggers, items: P.items, settings: P.settings, name: P.name}); },
  commit(){
    const s = this.state(); if (s === this.lastState) return;
    this.undoStack.push(this.lastState); if (this.undoStack.length > 80) this.undoStack.shift(); this.redoStack = []; this.lastState = s;
    this.setUnsaved(true); clearTimeout(this.saveTimer); this.saveTimer = setTimeout(() => this.persist(), 1500);
  },
  restore(s){ const d = JSON.parse(s); Object.assign(P, d); this.lastState = s; W.applyEnvironment(); W.buildAll();
    if (this.sel && !P.objects.find(o => o.id === this.sel)) this.sel = null; this.select(this.sel, true); this.refreshAll(); this.setUnsaved(true);
    clearTimeout(this.saveTimer); this.saveTimer = setTimeout(() => this.persist(), 1500); },
  undo(){ if (!this.undoStack.length) return; this.redoStack.push(this.state()); this.restore(this.undoStack.pop()); },
  redo(){ if (!this.redoStack.length) return; this.undoStack.push(this.state()); this.restore(this.redoStack.pop()); },
  async persist(full){
    try { await Store.saveProject(JSON.parse(JSON.stringify(P)), full === 'full'); this.setUnsaved(false); }
    catch(e){ log('Could not save to browser storage: ' + e.message + ' — use Export .zip', 'err'); }
  },
  setUnsaved(v){ this.unsaved = v; const b = document.querySelector('[data-cmd=save]'); if (b) b.textContent = v ? 'Save •' : 'Saved'; },
  flash(msg){ log(msg, 'warn'); const d = $('#dropHint'); d.textContent = msg; d.style.color = 'var(--ember2)'; clearTimeout(this._ft); this._ft = setTimeout(() => { d.textContent = 'Drop image on an object to texture it · drop FBX/GLB to place it'; d.style.color = ''; }, 2600); },

  refreshAll(){ this.renderHierarchy(); this.renderInspector(); this.renderTimeline(); this.renderTriggers(); this.renderAssets(); this.renderItems(); },
  tab(t){ this.curTab = t; setTimeout(() => this.previewItem(), 0); document.querySelectorAll('.tabs button').forEach(b => b.classList.toggle('on', b.dataset.tab === t)); document.querySelectorAll('.tab').forEach(x => x.classList.toggle('on', x.id === 'tab-' + t)); },

  /* ----- per-frame ----- */
  update(dt){
    const K = this.flyKeys;
    if (K && K.size && !Runtime.active){
      const fwd = new THREE.Vector3(); W.camera.getWorldDirection(fwd);
      const right = new THREE.Vector3().crossVectors(fwd, W.camera.up).normalize();
      const mv = new THREE.Vector3();
      if (K.has('KeyW')) mv.add(fwd); if (K.has('KeyS')) mv.sub(fwd);
      if (K.has('KeyD')) mv.add(right); if (K.has('KeyA')) mv.sub(right);
      if (K.has('KeyE')) mv.y += 1; if (K.has('KeyQ')) mv.y -= 1;
      if (mv.lengthSq()){ mv.normalize().multiplyScalar((K.has('ShiftLeft') || K.has('ShiftRight') ? 45 : 15) * (dt || 0.016));
        W.camera.position.add(mv); this.orbit.target.add(mv); }
    }
    this.orbit.update(); if (this.helper.visible){ const r = W.roots.get(this.sel); if (r) this.helper.setFromObject(r); }
    for (const hh of this.extraHelpers || []){ const r = W.roots.get(hh.userData.id); if (r) hh.setFromObject(r); }
    for (const r of W.roots.values()) r.traverse(m => { if (m.userData.textSign && P.objects.find(o => o.id === r.userData.objId && o.billboard)) m.quaternion.copy(W.camera.quaternion).premultiply(r.quaternion.clone().invert()); }); },

  /* ----- selection & picking ----- */
  obj(id){ return P.objects.find(o => o.id === (id || this.sel)); },
  pickAt(x, y, filter){
    const r = W.renderer.domElement.getBoundingClientRect();
    this.raycaster.setFromCamera({x: ((x - r.left) / r.width) * 2 - 1, y: -((y - r.top) / r.height) * 2 + 1}, W.camera);
    const roots = [...W.roots.values()].filter(x => x.visible);
    const hits = this.raycaster.intersectObjects(roots, true).filter(hh => visibleChain(hh.object) && !hh.object.isLineSegments);
    for (const hh of hits){ let o = hh.object; while (o && !o.userData.objId) o = o.parent; if (!o) continue;
      const ob = this.obj(o.userData.objId); if (ob && (!filter || filter(ob))) return Object.assign(ob ? {id: ob.id, o: ob} : {}, {point: hh.point}); }
    return null;
  },
  groundAt(x, y){
    const r = W.renderer.domElement.getBoundingClientRect();
    this.raycaster.setFromCamera({x: ((x - r.left) / r.width) * 2 - 1, y: -((y - r.top) / r.height) * 2 + 1}, W.camera);
    const hit = this.pickAt(x, y); if (hit) return hit.point;
    const p = new THREE.Vector3(); return this.raycaster.ray.intersectPlane(new THREE.Plane(new THREE.Vector3(0,1,0), 0), p) ? p : this.orbit.target.clone();
  },
  select(id, mode){
    if (!this.extra) this.extra = new Set();
    if (mode === 'toggle' && id){
      if (id === this.sel){ const n = [...this.extra][0] || null; this.extra.delete(n); this.sel = n; }
      else if (this.extra.has(id)) this.extra.delete(id);
      else { if (this.sel) this.extra.add(this.sel); this.sel = id; }
    } else { if (mode !== 'keep' && id !== this.sel) this.extra.clear(); this.sel = id || null; }
    if (!this.sel) this.extra.clear();
    for (const id of [this.sel, ...this.extra]){ let o = id && this.obj(id); while (o && o.parent){ const g = this.obj(o.parent); if (g && g.collapsed) g.collapsed = false; o = g; } }
    this.extra.delete(this.sel); for (const x of [...this.extra]) if (!W.roots.get(x)) this.extra.delete(x);
    const root = this.sel && W.roots.get(this.sel);
    if (root && !Runtime.active){ this.gizmo.attach(root); this.helper.visible = true; this.helper.setFromObject(root); }
    else { this.gizmo.detach(); this.helper.visible = false; }
    (this.extraHelpers || []).forEach(hh => { W.scene.remove(hh); hh.geometry.dispose(); });
    this.extraHelpers = Runtime.active ? [] : [...this.extra].map(x => { const hh = new THREE.BoxHelper(W.roots.get(x), 0x4cc3e0); hh.userData.id = x; W.scene.add(hh); return hh; });
    this.renderHierarchy(); this.renderInspector();
  },
  focus(){ const r = W.roots.get(this.sel); if (!r) return; const b = boxOf(r, true); const c = b.isEmpty() ? r.position.clone() : b.getCenter(new THREE.Vector3());
    const size = b.isEmpty() ? 2 : b.getSize(new THREE.Vector3()).length(); const dir = W.camera.position.clone().sub(this.orbit.target).normalize();
    this.orbit.target.copy(c); W.camera.position.copy(c).add(dir.multiplyScalar(Math.max(3, size * 1.6))); },
  fromGizmo(){
    const o = this.obj(); const r = W.roots.get(this.sel); if (!o || !r) return;
    const write = (ob, rt) => { ob.pos = rt.position.toArray().map(round); ob.rot = [rt.rotation.x, rt.rotation.y, rt.rotation.z].map(v => round(v * R2D)); ob.scale = rt.scale.toArray().map(round); };
    write(o, r);
    const g = this.gStart; if (g) for (const t of g.others){ const x = W.roots.get(t.id), ob = this.obj(t.id); if (!x || !ob) continue;
      x.position.copy(t.p).add(r.position.clone().sub(g.p));
      x.rotation.set(t.r.x + r.rotation.x - g.r.x, t.r.y + r.rotation.y - g.r.y, t.r.z + r.rotation.z - g.r.z);
      x.scale.set(t.s.x * r.scale.x / (g.s.x || 1), t.s.y * r.scale.y / (g.s.y || 1), t.s.z * r.scale.z / (g.s.z || 1)); write(ob, x); }
    clearTimeout(this._gi); this._gi = setTimeout(() => this.renderInspector(), 60);
  },

  /* ----- drag select (toggle with R) ----- */
  toggleDragSelect(){ this.dragSelect = !this.dragSelect; this.edToast(this.dragSelect ? 'Drag select ON' : 'Drag select OFF'); },
  edToast(msg){ let t = $('#edToast'); if (!t){ t = h('div', {id: 'edToast'}); $('#viewport').append(t); }
    t.textContent = msg; t.classList.remove('show'); void t.offsetWidth; t.classList.add('show'); clearTimeout(this._et); this._et = setTimeout(() => t.classList.remove('show'), 1200); },
  beginDrag(e){
    if (Runtime.active || !this.dragSelect || e.button !== 0 || this.gizmo.axis) return;
    this.orbit.enabled = false; e.stopPropagation();
    const rc = $('#viewport').getBoundingClientRect();
    let m = $('#marquee'); if (!m){ m = h('div', {id: 'marquee'}); $('#viewport').append(m); }
    this.drag = {x0: e.clientX, y0: e.clientY, rc, add: e.shiftKey || e.ctrlKey || e.metaKey, started: false}; m.hidden = true;
  },
  moveDrag(e){
    const d = this.drag; if (!d) return;
    if (!d.started && Math.hypot(e.clientX - d.x0, e.clientY - d.y0) < 4) return; d.started = true;
    const m = $('#marquee'), x = Math.min(d.x0, e.clientX), y = Math.min(d.y0, e.clientY);
    m.hidden = false; m.style.cssText = `left:${x - d.rc.left}px;top:${y - d.rc.top}px;width:${Math.abs(e.clientX - d.x0)}px;height:${Math.abs(e.clientY - d.y0)}px`;
    d.x1 = e.clientX; d.y1 = e.clientY;
  },
  endDrag(){
    const d = this.drag; if (!d) return; this.drag = null; this.orbit.enabled = !Runtime.active;
    const m = $('#marquee'); if (m) m.hidden = true;
    if (!d.started) return;
    this._skipClick = true;
    const x0 = Math.min(d.x0, d.x1), x1 = Math.max(d.x0, d.x1), y0 = Math.min(d.y0, d.y1), y1 = Math.max(d.y0, d.y1);
    const rc = W.renderer.domElement.getBoundingClientRect(), ids = [];
    for (const o of P.objects){ const r = W.roots.get(o.id); if (!r || !r.visible || o.type === 'plane') continue;   // floors are skipped (click them instead)
      if (o.type === 'group') continue;
      const b = boxOf(r, true); if (b.isEmpty()) b.setFromCenterAndSize(r.getWorldPosition(new THREE.Vector3()), new THREE.Vector3(.5, .5, .5));
      let ax = Infinity, ay = Infinity, bx2 = -Infinity, by = -Infinity, front = false;
      for (let i = 0; i < 8; i++){ const v = new THREE.Vector3(i & 1 ? b.max.x : b.min.x, i & 2 ? b.max.y : b.min.y, i & 4 ? b.max.z : b.min.z).project(W.camera);
        if (v.z < 1) front = true; const sx = rc.left + (v.x + 1) / 2 * rc.width, sy = rc.top + (1 - v.y) / 2 * rc.height;
        ax = Math.min(ax, sx); bx2 = Math.max(bx2, sx); ay = Math.min(ay, sy); by = Math.max(by, sy); }
      if (front && ax <= x1 && bx2 >= x0 && ay <= y1 && by >= y0) ids.push(this.topGroup(o.id)); }
    ids.splice(0, ids.length, ...new Set(ids));
    this.selectMany(ids, d.add);
    if (ids.length) this.edToast(ids.length + ' selected');
  },
  selIds(){ return this.sel ? [this.sel, ...this.extra] : []; },
  selectMany(ids, add){
    const all = add ? [...new Set([...this.selIds(), ...ids])] : ids;
    this.extra = new Set(all.slice(1)); this.sel = null; this.select(all[0] || null, 'keep');
  },

  /* ----- add / delete / duplicate ----- */
  buildAddMenu(){
    const m = $('#addMenu'); m.innerHTML = ''; let g = null;
    for (const t in TYPES){ if (TYPES[t].group === 'Hidden' || TYPES[t].group === 'Assets') continue; if (g && TYPES[t].group !== g) m.append(h('div', {class: 'dd-sep'})); g = TYPES[t].group;
      m.append(h('button', {onclick: () => { this.add(t); $('#addBtn').parentElement.classList.remove('open'); }}, h('span', {class: 'dot', style: 'background:' + TYPES[t].color}), TYPES[t].label)); }
    m.append(h('div', {class: 'dd-sep'}), h('div', {class: 'hint', style: 'padding:2px 8px'}, 'Basic assets'));
    for (const [k, lab, col] of [['pistol','Pistol (pickup)','#e8c33a'],['rifle','Rifle — automatic (pickup)','#e8c33a'],['ammo','Ammo box','#e8c33a'],['damage','Damage block','#ef5b5b'],
      ['checkpoint','Checkpoint','#3fd27a'],['keypad','Password keypad','#a98bff'],['house','House','#c97a4a'],['car','Car (gears)','#4cc3e0']])
      m.append(h('button', {onclick: () => { this.addPrefab(k); $('#addBtn').parentElement.classList.remove('open'); }}, h('span', {class: 'dot', style: 'background:' + col}), lab));
    $('#addBtn').onclick = e => { e.stopPropagation(); $('#addBtn').parentElement.classList.toggle('open'); };
    document.addEventListener('click', () => $('#addBtn').parentElement.classList.remove('open'));
  },
  add(type, at, over){
    const o = newObject(type, over); const t = at || this.orbit.target;
    o.pos[0] = round(t.x); o.pos[2] = round(t.z);
    if (at){ o.pos[1] = ['spawn','enemy','model','plane','checkpoint','vehicle','group'].includes(type) ? round(at.y) : round(at.y + o.scale[1] / 2); }
    P.objects.push(o); W.build(o); this.commit(); this.select(o.id); log('Added ' + o.name); return o;
  },
  /* descendants of a set of ids (groups include everything inside) */
  withKids(ids){ const out = new Set(ids); let grew = true; while (grew){ grew = false; for (const o of P.objects) if (o.parent && out.has(o.parent) && !out.has(o.id)){ out.add(o.id); grew = true; } } return [...out]; },
  topLevel(ids){ const set = new Set(ids); return ids.filter(id => { let o = this.obj(id); while (o && o.parent){ if (set.has(o.parent)) return false; o = this.obj(o.parent); } return true; }); },
  topGroup(id){ let o = this.obj(id); while (o && o.parent && this.obj(o.parent)) o = this.obj(o.parent); return o ? o.id : id; },
  remove(){ const ids = this.withKids(this.selIds()); if (!ids.length) return;
    for (const id of ids){ const r = W.roots.get(id); if (r){ W.disposeRoot(r); W.roots.delete(id); } }
    const gone = new Set(ids); P.objects = P.objects.filter(x => !gone.has(x.id));
    this.select(null); this.commit(); },
  /* clone a list of objects (with their group children), remapping ids; top-level copies get offset */
  cloneObjects(list, off){
    const map = {}; list.forEach(o => map[o.id] = uid()); const made = [];
    for (const o of list){ const c = clone(o); c.id = map[o.id]; c.name = o.name + ' copy';
      if (c.parent && map[c.parent]) c.parent = map[c.parent];
      else { if (c.parent && !this.obj(c.parent)) delete c.parent; c.pos = c.pos.map((v, i) => round(v + off[i])); }
      P.objects.push(c); made.push(c); }
    W.buildList(made); return made;
  },
  duplicate(){ const top = this.topLevel(this.selIds()); if (!top.length) return;
    // stack the copies on top of the whole selection
    const all = new THREE.Box3(); for (const id of top){ const r = W.roots.get(id); if (r) all.union(boxOf(r, true)); }
    const hgt = all.isEmpty() ? 1 : Math.max(all.max.y - all.min.y, .01);
    const list = this.withKids(top).map(id => this.obj(id)).filter(Boolean);
    const made = this.cloneObjects(list, [0, hgt, 0]);
    this.commit(); this.selectMany(made.filter(c => !c.parent || !made.some(m => m.id === c.parent)).map(c => c.id)); },
  copy(){
    if (this.area === 'timeline'){ const ev = this.ev(), a = ev && ev.actions.find(x => x.id === this.selAction);
      if (a){ this.clip = {kind: 'action', data: clone(a)}; this.edToast('Action copied'); } return; }
    const top = this.topLevel(this.selIds()); if (!top.length) return;
    this.clip = {kind: 'objects', data: clone(this.withKids(top).map(id => this.obj(id)).filter(Boolean))}; this.edToast(top.length + ' copied');
  },
  paste(){
    const c = this.clip; if (!c) return;
    if (c.kind === 'action'){ const ev = this.ev(); if (!ev){ this.edToast('Pick an event first'); return; }
      const a = clone(c.data); a.id = uid('a'); ev.actions.push(a); this.selAction = a.id; this.commit(); this.renderTimeline(); this.tab('timeline'); this.edToast('Action pasted into ' + ev.name); return; }
    const made = this.cloneObjects(clone(c.data), [1, 0, 1]); this.commit();
    this.selectMany(made.filter(x => !x.parent || !made.some(m => m.id === x.parent)).map(x => x.id)); this.edToast(made.length + ' pasted');
  },
  /* G = group the selection (or ungroup a selected group) */
  groupSel(){
    const top = this.topLevel(this.selIds()); if (!top.length) return;
    if (top.length === 1 && this.obj(top[0]).type === 'group') return this.ungroup(top[0]);
    const all = new THREE.Box3(); for (const id of top){ const r = W.roots.get(id); if (r) all.union(boxOf(r, true)); }
    const c = all.isEmpty() ? W.roots.get(top[0]).getWorldPosition(new THREE.Vector3()) : all.getCenter(new THREE.Vector3());
    const parents = new Set(top.map(id => this.obj(id).parent || null)); const par = parents.size === 1 ? [...parents][0] : null;
    const g = newObject('group', {name: 'Group ' + (P.objects.filter(o => o.type === 'group').length + 1)});
    const parRoot = par && W.roots.get(par); const local = parRoot ? parRoot.worldToLocal(new THREE.Vector3(c.x, all.isEmpty() ? c.y : all.min.y, c.z)) : new THREE.Vector3(c.x, all.isEmpty() ? c.y : all.min.y, c.z);
    g.pos = local.toArray().map(round); if (par) g.parent = par;
    P.objects.push(g); const gr = W.build(g);
    for (const id of top){ const o = this.obj(id), r = W.roots.get(id); gr.attach(r); o.parent = g.id; this.writeTf(o, r); }
    this.commit(); this.select(g.id); this.edToast('Grouped ' + top.length);
  },
  ungroup(gid){
    const g = this.obj(gid), gr = W.roots.get(gid); if (!g || !gr) return;
    const dest = (g.parent && W.roots.get(g.parent)) || W.scene; const kids = P.objects.filter(o => o.parent === gid);
    for (const o of kids){ const r = W.roots.get(o.id); if (r){ dest.attach(r); this.writeTf(o, r); } if (g.parent) o.parent = g.parent; else delete o.parent; }
    W.disposeRoot(gr); W.roots.delete(gid); P.objects = P.objects.filter(o => o !== g);
    this.commit(); this.selectMany(kids.map(o => o.id)); this.edToast('Ungrouped');
  },
  writeTf(o, r){ o.pos = r.position.toArray().map(round); o.rot = [r.rotation.x, r.rotation.y, r.rotation.z].map(v => round(v * R2D)); o.scale = r.scale.toArray().map(round); },
  /* camera jumps to the selected object */
  camTo(){ const r = W.roots.get(this.sel); if (!r) return; const b = boxOf(r, true); const c = b.isEmpty() ? r.getWorldPosition(new THREE.Vector3()) : b.getCenter(new THREE.Vector3());
    const size = b.isEmpty() ? 1 : b.getSize(new THREE.Vector3()).length(); const dir = W.camera.getWorldDirection(new THREE.Vector3());
    W.camera.position.copy(c).addScaledVector(dir, -Math.max(2, size * .9)); this.orbit.target.copy(c); this.edToast('Camera → ' + this.obj().name); },
  /* basic assets */
  addPrefab(k){
    const at = this.orbit.target.clone(); at.y = 0; const S = 'assets/sfx/', T = 'assets/textures/';
    if (k === 'pistol' || k === 'rifle'){ const rifle = k === 'rifle';
      ['gun_shot.wav','reload.wav','dry_fire.wav'].forEach(f => ensureAsset(S + f));
      return this.add('weapon', at, {name: rifle ? 'Rifle' : 'Pistol', weapon: rifle ? {name: 'Rifle', kind: 'rifle', ammoType: 'rifle', damage: 18, magSize: 30, startAmmo: 90, fireRate: 10, reloadTime: 2.1, auto: true, range: 120, sound: '', reloadSound: ''}
        : {name: 'Pistol', kind: 'pistol', ammoType: 'pistol', damage: 25, magSize: 12, startAmmo: 36, fireRate: 5, reloadTime: 1.4, auto: false, range: 80, sound: '', reloadSound: ''}}); }
    if (k === 'ammo') return this.add('ammo', at, {name: 'Ammo box'});
    if (k === 'checkpoint'){ ensureAsset(S + 'checkpoint.wav'); return this.add('checkpoint', at, {name: 'Checkpoint'}); }
    if (k === 'damage') return this.add('box', at, {name: 'Damage block', color: '#ff3b1f', emissive: '#8a1500', scale: [2, .25, 2], tags: ['damage'], damage: {on: true, amount: 25, perSecond: true, kill: false}});
    if (k === 'keypad'){ ['keypad_beep.wav','access_granted.wav','access_denied.wav'].forEach(f => ensureAsset(S + f));
      return this.add('box', at, {name: 'Keypad', color: '#2a2f3a', metalness: .6, scale: [.5, .7, .15], tags: ['keypad'], password: {enabled: true, code: '1234', prompt: 'Enter code', event: '', failEvent: '', once: true, showText: false}}); }
    if (k === 'car'){ ['engine_loop.wav','gear_shift.wav'].forEach(f => ensureAsset(S + f)); return this.add('vehicle', at, {name: 'Car'}); }
    if (k === 'house'){
      ensureAsset(T + 'brick.png'); ensureAsset(T + 'wood.jpg'); ensureAsset(S + 'door.wav');
      const g = newObject('group', {name: 'House', pos: [round(at.x), 0, round(at.z)]}); P.objects.push(g);
      const brick = {texture: T + 'brick.png', color: '#ffffff', texRepeat: [3, 1]}, wood = {texture: T + 'wood.jpg', color: '#ffffff'};
      const doorTag = 'house_door_' + g.id.slice(-4);
      const parts = [
        ['box', Object.assign({name: 'Floor', pos: [0, .1, 0], scale: [8, .2, 8], texRepeat: [4, 4]}, wood)],
        ['box', Object.assign({name: 'Back wall', pos: [0, 1.7, -3.85], scale: [8, 3, .3]}, brick)],
        ['box', Object.assign({name: 'Left wall', pos: [-3.85, 1.7, 0], scale: [.3, 3, 8]}, brick)],
        ['box', Object.assign({name: 'Right wall', pos: [3.85, 1.7, 0], scale: [.3, 3, 8]}, brick)],
        ['box', Object.assign({name: 'Front wall L', pos: [-2.5, 1.7, 3.85], scale: [3, 3, .3]}, brick, {texRepeat: [1, 1]})],
        ['box', Object.assign({name: 'Front wall R', pos: [2.5, 1.7, 3.85], scale: [3, 3, .3]}, brick, {texRepeat: [1, 1]})],
        ['box', Object.assign({name: 'Above door', pos: [0, 2.8, 3.85], scale: [2, .8, .3]}, brick, {texRepeat: [1, .3]})],
        ['ramp', {name: 'Roof front', pos: [0, 4.1, 2.15], scale: [8.6, 1.8, 4.3], color: '#7a3b2e', roughness: .9}],
        ['ramp', {name: 'Roof back', pos: [0, 4.1, -2.15], rot: [0, 180, 0], scale: [8.6, 1.8, 4.3], color: '#7a3b2e', roughness: .9}],
        ['box', Object.assign({name: 'Door', tags: [doorTag], pos: [0, 1.2, 3.85], scale: [2, 2.2, .12]}, wood)],
      ];
      const ev = {id: uid('ev'), name: 'Open house door', actions: [
        Object.assign({id: uid('a'), type: 'playSound', t: 0}, actionDefaults('playSound'), {sound: S + 'door.wav'}),
        Object.assign({id: uid('a'), type: 'move', t: 0}, actionDefaults('move'), {target: doorTag, mode: 'by', x: 1.9, y: 0, z: 0, duration: .8})]};
      P.events.push(ev);
      parts.push(['interaction', {name: 'Door handle', pos: [0, 1.2, 4.3], scale: [2.2, 2.4, .9], interact: {mode: 'any', event: ev.id, once: true, cooldown: .5, requireItem: '', consumeItem: false, prompt: 'Open door', enabled: true, sound: ''}}]);
      const made = [g]; for (const [t, over] of parts){ const o = newObject(t, over); o.parent = g.id; P.objects.push(o); made.push(o); }
      W.buildList(made); this.commit(); this.select(g.id); this.renderTimeline(); return g;
    }
  },
  changed(o, rebuild){ if (rebuild !== false) W.rebuild(o); else W.applyTransform(o); if (o.id === this.sel) this.select(o.id); this.commit(); },

  /* ----- toolbar & keys ----- */
  bindToolbar(){
    document.querySelectorAll('[data-cmd]').forEach(b => b.addEventListener('click', () => this.cmd(b.dataset.cmd)));
    document.querySelectorAll('[data-mode]').forEach(b => b.addEventListener('click', () => this.setMode(b.dataset.mode)));
    $('#snapChk').onchange = e => { const on = e.target.checked; this.gizmo.setTranslationSnap(on ? .5 : null); this.gizmo.setRotationSnap(on ? 15 * D2R : null); this.gizmo.setScaleSnap(on ? .25 : null); };
    $('#stopFloat').onclick = () => this.cmd('play');
    $('#zipInput').onchange = async e => { const f = e.target.files[0]; e.target.value = ''; if (f) this.openProject(() => ProjectIO.importZip(f), f.name); };
    $('#folderInput').onchange = async e => { const fl = e.target.files; if (fl.length) this.openProject(() => ProjectIO.importFolder(fl), 'folder'); e.target.value = ''; };
    $('#assetInput').onchange = async e => { await this.importFiles(e.target.files, this.folder.startsWith('assets') ? this.folder : null); e.target.value = ''; };
    $('#modalClose').onclick = () => $('#modal').hidden = true;
    $('#modal').addEventListener('mousedown', e => { if (e.target.id === 'modal') $('#modal').hidden = true; });
    document.querySelectorAll('[data-pm]').forEach(b => b.onclick = () => { const a = b.dataset.pm;
      if (a === 'resume') Runtime.togglePause(false); if (a === 'stop') this.cmd('play');
      if (a === 'save') Runtime.saveGame('slot' + b.dataset.slot); if (a === 'load') Runtime.loadGame('slot' + b.dataset.slot); });
    $('#clickToPlay').onclick = () => Runtime.requestLock();
  },
  setMode(m){ this.gizmo.setMode(m); document.querySelectorAll('[data-mode]').forEach(b => b.classList.toggle('on', b.dataset.mode === m)); },
  async openProject(fn, name){
    try { const p = await fn(); if (!p){ log('No project.json found in ' + name + ' — imported files as assets into a new project', 'warn'); this.load(newProject()); }
      else { this.load(p); log('Opened ' + (p.name || name), 'ok'); }
      await this.persist('full');
    } catch(e){ log('Open failed: ' + e.message, 'err'); console.error(e); }
  },
  cmd(c){
    switch (c){
      case 'new': if (this._newArm){ this._newArm = false; VFS.clear(); this.load(newProject()); this.persist('full'); log('New project', 'ok'); }
        else { this._newArm = true; const b = document.querySelector('[data-cmd=new]'); b.textContent = 'Sure? click again'; setTimeout(() => { this._newArm = false; b.textContent = 'New'; }, 2500); } break;
      case 'openZip': $('#zipInput').click(); break;
      case 'openFolder': $('#folderInput').click(); break;
      case 'save': this.persist('full').then(() => log('Project saved in this browser', 'ok')); break;
      case 'toLauncher': this.commit(); this.edToast('Packing game…');
        this.persist('full').then(() => ProjectIO.buildZip(P)).then(b => addGameToLibrary(b, P.name)).then(() => { location.href = 'launcher.html'; })
          .catch(e => log('Could not send to launcher: ' + e.message + ' — use Export .zip and add it in the launcher', 'err')); break;
      case 'exportZip': ProjectIO.exportZip(P).then(() => log('Exported ' + safeName(P.name) + '.zip', 'ok')).catch(e => log('Export failed: ' + e.message, 'err')); break;
      case 'undo': this.undo(); break; case 'redo': this.redo(); break;
      case 'settings': this.openSettings(); break;
      case 'play':
        if (Runtime.active){ Runtime.stop(); $('#app').classList.remove('playing'); $('#stopFloat').hidden = true; $('#playBtn').classList.remove('stop'); $('#playBtn').textContent = '▶ Play';
          this.orbit.enabled = true; this.gizmo.enabled = true; setTimeout(() => W.resize(), 0); this.select(this.sel); this.previewItem(); }
        else { this.commit(); this.gizmo.detach(); this.helper.visible = false; this.orbit.enabled = false; this.gizmo.enabled = false; $('#app').classList.add('playing'); $('#stopFloat').hidden = false;
          setTimeout(() => W.resize(), 0); Runtime.start(); }
        break;
    }
  },
  bindKeys(){
    window.addEventListener('keydown', e => {
      if (Runtime.active) return;
      const typing = /^(INPUT|TEXTAREA|SELECT)$/.test(document.activeElement.tagName);
      const ctrl = e.ctrlKey || e.metaKey;
      if (ctrl && e.code === 'KeyS'){ e.preventDefault(); this.cmd('save'); return; }
      if (typing) return;
      if (ctrl && e.code === 'KeyZ'){ e.preventDefault(); e.shiftKey ? this.redo() : this.undo(); return; }
      if (ctrl && e.code === 'KeyY'){ e.preventDefault(); this.redo(); return; }
      if (ctrl && e.code === 'KeyD'){ e.preventDefault(); this.duplicate(); return; }
      if (ctrl && e.code === 'KeyC'){ e.preventDefault(); this.copy(); return; }
      if (ctrl && e.code === 'KeyV'){ e.preventDefault(); this.paste(); return; }
      if (e.code === 'KeyT'){ e.preventDefault(); this.camTo(); return; }   // Ctrl+T or T (browsers usually keep Ctrl+T for new tab)
      if (ctrl) return;
      if (e.code === 'KeyG'){ this.groupSel(); return; }
      if (e.code === 'Delete' || e.code === 'Backspace'){ this.remove(); return; }
      if (e.code === 'Digit1') this.setMode('translate'); if (e.code === 'Digit2') this.setMode('rotate'); if (e.code === 'Digit3') this.setMode('scale');
      if (e.code === 'KeyF') this.focus(); if (e.code === 'Escape') this.select(null);
      if (e.code === 'KeyR' && !e.repeat) this.toggleDragSelect();
      if (e.code === 'F5'){ e.preventDefault(); this.cmd('play'); }
    });
  },

  /* ----- drag & drop: assets and OS files onto the viewport ----- */
  bindDrop(vp){
    vp.addEventListener('dragover', e => { e.preventDefault(); vp.classList.add('dragging'); });
    vp.addEventListener('dragleave', e => { if (e.target === vp || !vp.contains(e.relatedTarget)) vp.classList.remove('dragging'); });
    vp.addEventListener('drop', async e => {
      e.preventDefault(); vp.classList.remove('dragging'); if (Runtime.active) return;
      let path = e.dataTransfer.getData('text/kiln-asset');
      if (!path && e.dataTransfer.files.length){ const added = await this.importFiles(e.dataTransfer.files); path = added[0]; }
      if (path) this.dropAsset(path, e.clientX, e.clientY);
    });
  },
  dropAsset(path, x, y){
    const kind = VFS.kindOf(path);
    if (kind === 'image'){
      const hit = this.pickAt(x, y, o => !['interaction','spawn','light'].includes(o.type));
      if (hit){ const o = hit.o; if (o.type === 'text3d'){ this.flash('3D text signs use text, not textures'); return; } o.texture = path; if (o.type === 'model') o.useModelMaterials = false; this.changed(o); log(`Texture ${VFS.base(path)} → ${o.name}`, 'ok'); }
      else { const p = this.groundAt(x, y); const o = this.add('decal', p, {texture: path, name: VFS.base(path).replace(/\.\w+$/, '')}); o.pos[1] = round(p.y + 1); this.changed(o); }
    } else if (kind === 'model'){ const p = this.groundAt(x, y); this.add('model', p, {model: path, name: VFS.base(path).replace(/\.\w+$/, '')}); }
    else if (kind === 'font') this.flash('Font added: pick "' + Fonts.familyOf(path) + '" in any font list (3D text or title text style)');
    else if (kind === 'audio') this.flash('Sounds are played by events: add a "Play sound file" action in Events & Timeline');
  },
  async importFiles(files, folder){
    const out = [];
    const kindDirs = ['assets/textures', 'assets/models', 'assets/sfx', 'assets/music', 'assets/fonts', 'assets/other'];
    for (const f of files){ let dir = folder || VFS.folderFor(f.name);
      // keep files in a folder that matches their type unless the user picked a custom folder
      if (folder && kindDirs.includes(folder) && folder !== VFS.folderFor(f.name) && !(folder === 'assets/music' && VFS.kindOf(f.name) === 'audio')) dir = VFS.folderFor(f.name); const p = VFS.uniquePath(dir + '/' + f.name); VFS.add(p, f, true); out.push(p); }
    VFS.emit(); if (out.length){ log(`Imported ${out.length} file(s): ${out.map(VFS.base).join(', ')}`, 'ok'); this.folder = VFS.dir(out[0]); this.renderAssets(); this.persist(); }
    return out;
  },
  onModelLoaded(o){ if (o.id === this.sel && !Runtime.active){ clearTimeout(this._ml); this._ml = setTimeout(() => this.renderInspector(), 50); } },

  /* ====================== Hierarchy ====================== */
  renderHierarchy(){
    const el = $('#hierarchy'); el.innerHTML = ''; const f = ($('#hierFilter').value || '').toLowerCase();
    let list = P.objects.filter(o => !f || o.name.toLowerCase().includes(f) || o.tags.some(t => t.toLowerCase().includes(f)));
    const depth = o => { let d = 0, x = o; while (x && x.parent && d < 20){ x = this.obj(x.parent); d++; } return d; };
    if (!f){ const ordered = []; const walk = (pid) => { for (const o of P.objects) if ((o.parent || null) === pid || (pid === null && o.parent && !this.obj(o.parent))){ if (ordered.includes(o)) continue; ordered.push(o); if (o.type === 'group' && !o.collapsed) walk(o.id); } }; walk(null); list = ordered; }
    for (const o of list){
      const eye = h('button', {class: 'small', title: 'Show / hide in editor and game', style: 'border:0;background:transparent;opacity:.7', onclick: ev => { ev.stopPropagation(); o.visible = o.visible === false; this.changed(o); this.renderHierarchy(); }}, o.visible === false ? '◌' : '●');
      el.append(h('div', {class: 'h-row' + (o.id === this.sel ? ' sel' : (this.extra && this.extra.has(o.id)) ? ' sel2' : '') + (o.visible === false ? ' hidden-obj' : ''), onclick: ev => this.select(o.id, (ev.shiftKey || ev.ctrlKey || ev.metaKey) ? 'toggle' : undefined), ondblclick: () => this.focus()},
        f ? null : h('span', {style: `width:${depth(o) * 14}px;flex:none`}), h('span', {class: 'dot', style: 'background:' + TYPES[o.type].color + (o.type === 'group' ? ';border-radius:50%' : '')}), o.type === 'group' ? h('button', {class: 'tw', title: o.collapsed ? 'Open group' : 'Close group', onclick: ev => { ev.stopPropagation(); o.collapsed = !o.collapsed; this.commit(); this.renderHierarchy(); }}, o.collapsed ? '▸' : '▾') : null,
        h('span', {class: 'nm'}, o.name), o.type === 'group' ? h('span', {class: 'tg', title: 'objects inside'}, P.objects.filter(x => x.parent === o.id).length) : null,
        o.type === 'group' && P.items.some(it => it.model === o.id) ? h('span', {class: 'tg', title: 'item model'}, '⚔') : null, o.pickable ? h('span', {class: 'tg', title: 'pickable'}, '✋') : null, o.slippery ? h('span', {class: 'tg', title: 'slippery'}, '≈') : null, o.tags.length ? h('span', {class: 'tg'}, '#' + o.tags.join(' #')) : null, eye));
    }
    if (!list.length) el.append(h('div', {class: 'empty-note'}, f ? 'Nothing matches.' : 'Empty scene. Use + Add.'));
    this.updateDatalists();
  },
  updateDatalists(){
    let dl = $('#dl-targets'); if (!dl){ dl = h('datalist', {id: 'dl-targets'}); document.body.append(dl); }
    const names = new Set(); P.objects.forEach(o => { o.tags.forEach(t => names.add(t)); }); const tags = [...names]; P.objects.forEach(o => names.add(o.name));
    dl.innerHTML = ''; tags.forEach(t => dl.append(h('option', {value: t}, 'tag'))); P.objects.forEach(o => dl.append(h('option', {value: o.name}, 'name')));
    let di = $('#dl-items'); if (!di){ di = h('datalist', {id: 'dl-items'}); document.body.append(di); } di.innerHTML = ''; P.items.forEach(i => di.append(h('option', {value: i.name})));
    let dt = $('#dl-tags'); if (!dt){ dt = h('datalist', {id: 'dl-tags'}); document.body.append(dt); } dt.innerHTML = ''; tags.forEach(t => dt.append(h('option', {value: t})));
  },

  /* ====================== Inspector ====================== */
  renderInspector(){
    const el = $('#inspector'); el.innerHTML = ''; const o = this.obj();
    if (!o){ el.append(this.sceneInfo()); return; }
    if (this.extra && this.extra.size) el.append(h('div', {class: 'sec', style: 'background:#1c2a31'}, h('div', {class: 'sec-t'}, (this.extra.size + 1) + ' objects selected'),
      h('div', {class: 'hint'}, 'Gizmo moves / rotates / scales them together. Ctrl+D duplicates all, Del deletes all. Editing below changes only “' + o.name + '”.')));
    const ch = (rb) => () => this.changed(o, rb);
    const live = () => W.applyTransform(o);
    el.append(UI.sec(TYPES[o.type].label,
      UI.row('Name', UI.text(o.name, v => { o.name = v; this.changed(o, false); this.renderHierarchy(); })),
      UI.row('Tags', UI.text(o.tags.join(', '), v => { o.tags = v.split(',').map(s => s.trim()).filter(Boolean); this.changed(o, false); this.renderHierarchy(); }, 'e.g. sigma, door', 'dl-tags')),
      h('div', {class: 'hint'}, 'Events target objects by tag or name.')));
    el.append(UI.sec('Transform',
      UI.row('Position', UI.xyz(o.pos, live, ch(false))),
      UI.row(o.type === 'spawn' ? 'Rotation (Y = facing)' : 'Rotation °', UI.xyz(o.rot, live, ch(false), 5)),
      o.type === 'spawn' ? null : UI.row('Size / scale', UI.xyz(o.scale, live, ch(false))),
      h('div', {style: 'display:flex;gap:4px;flex-wrap:wrap'},
        h('button', {class: 'small', onclick: () => { const r = W.roots.get(o.id); const b = boxOf(r); if (!b.isEmpty()){ o.pos[1] = round(o.pos[1] - b.min.y); this.changed(o, false); } }}, 'Drop to floor'),
        h('button', {class: 'small', onclick: () => { o.rot = [0,0,0]; this.changed(o, false); }}, 'Reset rotation'),
        h('button', {class: 'small', onclick: () => { const p = this.orbit.target; o.pos = [round(p.x), o.pos[1], round(p.z)]; this.changed(o, false); }}, 'Move to view center'))));

    const solid = !['interaction','spawn','light','enemy','text3d','group','weapon','ammo','checkpoint','vehicle'].includes(o.type);
    if (['box','sphere','cylinder','cone','plane','ramp','decal','model','enemy','vehicle'].includes(o.type)){
      const app = UI.sec('Appearance',
        UI.row('Color', UI.color(o.color, v => { o.color = v; ch()(); }, v => { o.color = v; forMats(W.roots.get(o.id), m => m.color && m.color.set(v)); })),
        UI.row('Texture', UI.asset('image', o.texture, v => { o.texture = v; if (o.type === 'model' && v) o.useModelMaterials = false; ch()(); })),
        o.texture ? UI.row('Tiling', h('div', {class: 'xyz', style: 'grid-template-columns:1fr 1fr'},
          UI.num(o.texRepeat[0], null, v => { o.texRepeat[0] = v || 1; ch()(); }), UI.num(o.texRepeat[1], null, v => { o.texRepeat[1] = v || 1; ch()(); }))) : null,
        UI.row('Opacity', UI.num(o.opacity, null, v => { o.opacity = Math.max(0, Math.min(1, v)); ch()(); }, .05)),
        UI.row('Roughness', UI.num(o.roughness, null, v => { o.roughness = v; ch()(); }, .05)),
        UI.row('Metalness', UI.num(o.metalness, null, v => { o.metalness = v; ch()(); }, .05)),
        UI.row('Glow color', UI.color(o.emissive, v => { o.emissive = v; ch()(); })),
        UI.row('Visible', UI.chk(o.visible !== false, v => { o.visible = v; ch()(); this.renderHierarchy(); }), h('span', {class: 'hint'}, 'Cast shadow'), UI.chk(o.castShadow !== false, v => { o.castShadow = v; ch()(); })),
        h('div', {class: 'hint'}, 'Tip: drag an image from Assets onto this object in the viewport.'));
      if (o.type === 'enemy') app.querySelector('.hint:last-child').textContent = 'Texture and color apply to the built-in rig or override the model\'s materials.';
      el.append(app);
    }
    if (solid){ const canMove = !['plane','ramp'].includes(o.type);
      const ps = UI.sec('Physics', UI.row('Solid', UI.chk(o.collide, v => { o.collide = v; ch(false)(); }), h('span', {class: 'hint'}, 'Player and enemies collide with it')));
      if (canMove){
        ps.append(UI.row('Pickable', UI.chk(o.pickable, v => { o.pickable = v; if (v) o.collide = true; this.commit(); this.renderInspector(); this.renderHierarchy(); }), h('span', {class: 'hint'}, 'player can pick up / throw')),
          UI.row('Slippery', UI.chk(o.slippery, v => { o.slippery = v; if (v) o.collide = true; this.commit(); this.renderInspector(); this.renderHierarchy(); }), h('span', {class: 'hint'}, 'slides when touched / pushed')));
        if (o.pickable) ps.append(UI.row('Becomes item', UI.text(o.pickItem, v => { o.pickItem = v; this.commit(); }, 'blank = carry it', 'dl-items')),
          UI.row('Pick-up sound', UI.asset('audio', o.pickSound, v => { o.pickSound = v; this.commit(); this.renderInspector(); })));
        ps.append(h('div', {class: 'hint'}, !o.pickable && !o.slippery ? 'Default: anchored. Nothing moves it.' : 'Falls with gravity in game. Pick up: aim + E or left click. Left click again throws, E drops.'));
      }
      el.append(ps); }
    if (o.type === 'text3d') el.append(UI.sec('3D Text',
      UI.row('Text', UI.area(o.text, v => { o.text = v; ch()(); })),
      UI.row('Font', UI.sel(Fonts.list(), o.font, v => { o.font = v; ch()(); })),
      UI.row('Resolution', UI.num(o.fontSize, null, v => { o.fontSize = v; ch()(); }, 8)),
      UI.row('Text color', UI.color(o.textColor, v => { o.textColor = v; ch()(); })),
      UI.row('Background', UI.text(o.textBg, v => { o.textBg = v; ch()(); }, '#00000088 or #00000000')),
      UI.row('Face camera', UI.chk(o.billboard, v => { o.billboard = v; ch()(); }))));
    if (o.type === 'model') el.append(this.modelSection(o));
    if (o.type === 'interaction') el.append(this.interactionSection(o));
    if (o.type === 'enemy') el.append(...this.enemySections(o));
    if (o.type === 'light') el.append(UI.sec('Light',
      UI.row('Color', UI.color(o.color, v => { o.color = v; ch()(); })),
      UI.row('Intensity', UI.num(o.intensity, null, v => { o.intensity = v; ch()(); })),
      UI.row('Range', UI.num(o.distance, null, v => { o.distance = v; ch()(); }, 1))));
    el.append(...this.extraSections(o));
    if (o.type === 'spawn') el.append(UI.sec('Player spawn', h('div', {class: 'hint'}, 'The player starts here. Rotation Y sets which way they face. Only the first spawn is used.')));
    el.append(h('div', {class: 'sec'}, h('div', {style: 'display:flex;gap:6px'},
      h('button', {onclick: () => this.duplicate()}, 'Duplicate'), h('button', {onclick: () => this.focus()}, 'Focus'), h('div', {style: 'flex:1'}),
      h('button', {class: 'danger', onclick: () => this.remove()}, 'Delete')), h('div', {class: 'hint mono'}, o.id)));
  },
  extraSections(o){
    const out = [], cm = () => this.commit(), rr = () => { this.commit(); this.renderInspector(); };
    const evSel = (v, set) => UI.sel([['', '— none —'], ...P.events.map(e => [e.id, e.name])], v, set);
    if (o.type === 'group'){ const kids = P.objects.filter(x => x.parent === o.id);
      out.push(UI.sec('Group', h('div', {class: 'hint'}, `${kids.length} objects inside. Move / rotate / scale this group and they all follow. Events can target the group's tag.`),
        h('div', {style: 'display:flex;flex-wrap:wrap;gap:4px'}, ...kids.map(k => h('button', {class: 'small', onclick: () => this.select(k.id)}, k.name))),
        h('button', {onclick: () => this.ungroup(o.id)}, 'Ungroup (G)')));
      const uses = P.items.filter(it => it.model === o.id);
      out.push(UI.sec('Item model',
        UI.row('Model of item', UI.sel([['', '— not an item —'], ...P.items.map(it => [it.name, it.name])], uses[0] ? uses[0].name : '', v => {
          P.items.forEach(it => { if (it.model === o.id) it.model = ''; }); const it = P.items.find(x => x.name === v); if (it) it.model = o.id; this.commit(); this.renderInspector(); this.renderHierarchy(); })),
        h('div', {style: 'display:flex;gap:4px;flex-wrap:wrap'},
          h('button', {class: 'small', onclick: () => { let n = o.name.replace(/ *\(item model\)/i, ''), i = 2; const b = n; while (P.items.find(x => x.name === n)) n = b + ' ' + i++;
            const it = newItemDef(n); it.model = o.id; P.items.push(it); this.selItem = it.name; this.commit(); this.tab('items'); this.renderItems(); this.renderInspector(); this.renderHierarchy(); this.updateDatalists(); }}, '+ New item from this group'),
          uses[0] ? h('button', {class: 'small', onclick: () => { this.selItem = uses[0].name; this.tab('items'); this.renderItems(); }}, 'Edit item →') : null),
        h('div', {class: 'hint'}, 'Only groups can be item models. One object? Select it and press G to make it a group.'))); }
    if (o.type === 'weapon'){ const w = o.weapon, set = (k, v) => { w[k] = v; cm(); };
      out.push(UI.sec('Gun',
        UI.row('Name', UI.text(w.name, v => set('name', v))), UI.row('Look', UI.sel([['pistol','Pistol'],['rifle','Rifle']], w.kind, v => { w.kind = v; this.changed(o); })),
        UI.row('Ammo type', UI.text(w.ammoType, v => set('ammoType', v), 'pistol')), UI.row('Damage', UI.num(w.damage, null, v => set('damage', v), 1)),
        UI.row('Magazine', UI.num(w.magSize, null, v => set('magSize', v), 1)), UI.row('Spare ammo', UI.num(w.startAmmo, null, v => set('startAmmo', v), 1)),
        UI.row('Shots / sec', UI.num(w.fireRate, null, v => set('fireRate', v), .5)), UI.row('Reload time', UI.num(w.reloadTime, null, v => set('reloadTime', v), .1)),
        UI.row('Automatic', UI.chk(w.auto, v => set('auto', v)), h('span', {class: 'hint'}, 'hold to fire')), UI.row('Range', UI.num(w.range, null, v => set('range', v), 5)),
        UI.row('Shot sound', UI.asset('audio', w.sound, v => { w.sound = v; rr(); })), UI.row('Reload sound', UI.asset('audio', w.reloadSound, v => { w.reloadSound = v; rr(); })),
        h('div', {class: 'hint'}, 'Walk into it to pick it up. LMB fires, R reloads, 1-9 switch guns. Blank sounds use the built-in ones.'))); }
    if (o.type === 'ammo') out.push(UI.sec('Ammo', UI.row('Ammo type', UI.text(o.ammo.ammoType, v => { o.ammo.ammoType = v; cm(); }, 'pistol')),
      UI.row('Amount', UI.num(o.ammo.amount, null, v => { o.ammo.amount = v; cm(); }, 1)), h('div', {class: 'hint'}, 'Must match the gun\'s ammo type (pistol, rifle…).')));
    if (o.type === 'checkpoint') out.push(UI.sec('Checkpoint', UI.row('On touch run', evSel(o.checkpoint.event, v => { o.checkpoint.event = v; cm(); })),
      UI.row('Sound', UI.asset('audio', o.checkpoint.sound, v => { o.checkpoint.sound = v; rr(); })), h('div', {class: 'hint'}, 'Touch it to set your respawn point. Its flag turns green. When you die you respawn at the last checkpoint.')));
    if (o.type === 'vehicle'){ const V = o.vehicle;
      out.push(UI.sec('Car', UI.row('Top speed km/h', UI.num(V.topSpeed, null, v => { V.topSpeed = v; cm(); }, 5)), UI.row('Engine power', UI.num(V.power, null, v => { V.power = v; cm(); }, .5)),
        UI.row('Steering', UI.num(V.steering, null, v => { V.steering = v; cm(); }, .1)),
        UI.row('Engine sound', UI.asset('audio', V.engineSound, v => { V.engineSound = v; rr(); })), UI.row('Gear shift sound', UI.asset('audio', V.shiftSound, v => { V.shiftSound = v; rr(); })),
        h('div', {class: 'hint'}, 'Play: walk up and press E. W/S throttle / brake, A/D steer, Space gear up, Shift gear down (R N 1-5). Engine pitch follows RPM.'))); }
    if (!['spawn','light','group'].includes(o.type)){
      const pw = o.password = o.password || {enabled: false, code: '1234', prompt: 'Enter password', event: '', failEvent: '', once: true, showText: false};
      const s = UI.sec('Password lock', UI.row('Has password', UI.chk(pw.enabled, v => { pw.enabled = v; if (v){ ['keypad_beep.wav','access_granted.wav','access_denied.wav'].forEach(f => ensureAsset('assets/sfx/' + f)); } rr(); })));
      if (pw.enabled) s.append(UI.row('Password', UI.text(pw.code, v => { pw.code = v; cm(); })), UI.row('Prompt', UI.text(pw.prompt, v => { pw.prompt = v; cm(); })),
        UI.row('Correct → run', evSel(pw.event, v => { pw.event = v; cm(); })), UI.row('Wrong → run', evSel(pw.failEvent, v => { pw.failEvent = v; cm(); })),
        UI.row('Unlock once', UI.chk(pw.once !== false, v => { pw.once = v; cm(); })), UI.row('Show typing', UI.chk(pw.showText, v => { pw.showText = v; cm(); })),
        h('div', {class: 'hint'}, o.type === 'interaction' ? 'The block only activates after the right password.' : 'Left click (or E) on it in game opens a keypad. Keypad buttons beep.'));
      out.push(s); }
    if (this.isSolidish(o)){ const D = o.damage = o.damage || {on: false, amount: 10, perSecond: false, kill: false};
      const s = UI.sec('Damage on touch', UI.row('Hurts player', UI.chk(D.on, v => { D.on = v; rr(); })));
      if (D.on) s.append(UI.row('Damage', UI.num(D.amount, null, v => { D.amount = v; cm(); }, 1)), UI.row('Per second', UI.chk(D.perSecond, v => { D.perSecond = v; cm(); }), h('span', {class: 'hint'}, 'off = once per touch')),
        UI.row('Instant kill', UI.chk(D.kill, v => { D.kill = v; cm(); })));
      out.push(s); }
    return out;
  },
  isSolidish(o){ return !['spawn','light','group','weapon','ammo','checkpoint','text3d','decal','enemy','vehicle'].includes(o.type); },
  sceneInfo(){
    const c = {}; P.objects.forEach(o => c[o.type] = (c[o.type] || 0) + 1);
    return h('div', null, UI.sec('Scene',
      h('div', {class: 'hint'}, `${P.objects.length} objects · ${P.events.length} events · ${P.triggers.length} triggers · ${VFS.files.size} asset files`),
      h('div', {class: 'empty-note', style: 'padding:4px 0'},
        h('div', null, h('b', null, 'Select'), ' an object to edit it. ', h('b', null, '1 / 2 / 3'), ' move · rotate · scale. ', h('b', null, 'F'), ' focus. ', h('b', null, 'Ctrl+D'), ' duplicate. ', h('b', null, 'Del'), ' delete.'),
        h('div', {style: 'margin-top:8px'}, h('b', null, 'Pan'), ' right-drag · ', h('b', null, 'Look'), ' hold left mouse · ', h('b', null, 'R'), ' drag select · ', h('b', null, 'G'), ' group / ungroup · ', h('b', null, 'T'), ' camera to object · ', h('b', null, 'Ctrl+C/V'), ' copy / paste (objects, or actions on the timeline). Shift+click adds to selection, Alt+click picks inside a group. · ',h('b', null, 'Zoom'), ' wheel · ', h('b', null, 'Fly'), ' WASD, Q/E down/up, Shift faster.'),
        h('div', {style: 'margin-top:8px'}, h('b', null, 'Interaction blocks'), ' (orange) are invisible in game. Point them at an event; events run their actions on a timeline.'),
        h('div', {style: 'margin-top:8px'}, h('b', null, 'Play'), ' F5 · Pause ', keyLabel(P.settings.keys.pause), ' · Quick save ', P.settings.keys.quickSave, ' / load ', P.settings.keys.quickLoad))),
      UI.sec('World', UI.row('Sky', UI.color(P.settings.sky, v => { P.settings.sky = P.settings.fogColor = v; W.applyEnvironment(); this.commit(); })),
        UI.row('Light', UI.num(P.settings.sunIntensity, v => { P.settings.sunIntensity = v; W.applyEnvironment(); }, () => this.commit())),
        h('button', {onclick: () => this.openSettings()}, 'All settings…')));
  },
  modelSection(o){
    const s = UI.sec('3D Model',
      UI.row('File', UI.asset('model', o.model, v => { o.model = v; this.changed(o); })),
      UI.row('Auto-size', UI.chk(o.normalize, v => { o.normalize = v; this.changed(o); }), h('span', {class: 'hint'}, 'scale Y = height in meters')),
      UI.row('Own materials', UI.chk(o.useModelMaterials, v => { o.useModelMaterials = v; this.changed(o); }), h('span', {class: 'hint'}, 'off = use color/texture')));
    const holder = W.roots.get(o.id) && W.roots.get(o.id).userData.body; const clips = (holder && holder.userData.clips) || [];
    s.append(UI.row('Auto-play', UI.sel([['', '— none —'], ...clips.map(c => [c.name, c.name])], o.anim, v => { o.anim = v; this.commit(); })));
    if (o.model && !clips.length) s.append(h('div', {class: 'hint'}, holder && holder.userData.model ? 'This file has no animation clips.' : 'Loading model…'));
    s.append(h('div', {class: 'hint'}, 'FBX textures load automatically when the image files are in the project (any folder).'));
    return s;
  },
  interactionSection(o){
    const I = o.interact;
    const evSel = UI.sel([['', '— choose event —'], ...P.events.map(e => [e.id, e.name])], I.event, v => { I.event = v; this.commit(); });
    return UI.sec('Interaction block',
      UI.row('Activated by', UI.sel([['left','Left click'],['right','Right click'],['any','Left or right click'],['key','Interact key (look + press)'],['touch','Player touches / steps in']], I.mode, v => { I.mode = v; this.commit(); })),
      UI.row('Runs event', evSel),
      h('div', {style: 'display:flex;gap:4px'},
        h('button', {class: 'small', onclick: () => { const ev = this.newEvent(o.name + ' event'); I.event = ev.id; this.commit(); this.renderInspector(); this.tab('timeline'); }}, '+ New event for this'),
        I.event ? h('button', {class: 'small', onclick: () => { this.selEvent = I.event; this.selAction = null; this.renderTimeline(); this.tab('timeline'); }}, 'Open event on timeline →') : null),
      UI.row('Prompt text', UI.text(I.prompt, v => { I.prompt = v; this.commit(); }, 'Open door')),
      UI.row('Only once', UI.chk(I.once, v => { I.once = v; this.commit(); }), h('span', {class: 'hint'}, 'Cooldown s'), UI.num(I.cooldown, null, v => { I.cooldown = v; this.commit(); })),
      UI.row('Needs item', UI.text(I.requireItem, v => { I.requireItem = v; this.commit(); }, 'none', 'dl-items')),
      UI.row('Use up item', UI.chk(I.consumeItem, v => { I.consumeItem = v; this.commit(); })),
      UI.row('Click sound', UI.asset('audio', I.sound, v => { I.sound = v; this.commit(); this.renderInspector(); })),
      UI.row('Enabled', UI.chk(I.enabled !== false, v => { I.enabled = v; this.commit(); })),
      h('div', {class: 'hint'}, 'Visible here in the editor, invisible in game. Clicks reach it from up to "Interact range" meters (Settings).'));
  },
  enemySections(o){
    const E = o.enemy, cm = () => this.commit(), rb = () => this.changed(o);
    const st = UI.sec('Enemy / NPC',
      UI.row('Hostile', UI.chk(E.hostile, v => { E.hostile = v; rb(); }), h('span', {class: 'hint'}, 'off = friendly NPC')),
      UI.row('Health', UI.num(E.health, null, v => { E.health = v; cm(); }, 5)),
      UI.row('Move speed', UI.num(E.speed, null, v => { E.speed = v; cm(); })),
      UI.row('Damage', UI.num(E.damage, null, v => { E.damage = v; cm(); }, 1)),
      UI.row('Attack range', UI.num(E.attackRange, null, v => { E.attackRange = v; cm(); })),
      UI.row('Attacks / sec', UI.num(E.attackRate, null, v => { E.attackRate = v; cm(); })),
      UI.row('Notice range', UI.num(E.aggroRange, null, v => { E.aggroRange = v; cm(); }, 1)),
      UI.row('Spawn at start', UI.chk(E.spawnOnStart, v => { E.spawnOnStart = v; cm(); }), h('span', {class: 'hint'}, 'off = template for "Spawn enemy"')),
      UI.row('Health bar', UI.chk(E.showHealthBar !== false, v => { E.showHealthBar = v; cm(); })),
      UI.row('On death run', UI.sel([['', '— none —'], ...P.events.map(e => [e.id, e.name])], E.deathEvent, v => { E.deathEvent = v; cm(); })));
    const holder = W.roots.get(o.id) && W.roots.get(o.id).userData.body;
    const look = UI.sec('Exterior & motion',
      UI.row('Model', UI.asset('model', E.model, v => { E.model = v; E.joints = {}; rb(); })),
      E.model ? UI.row('Auto-size', UI.chk(E.normalize, v => { E.normalize = v; rb(); }), h('span', {class: 'hint'}, 'Height'), UI.num(E.height, null, v => { E.height = v; rb(); })) : null,
      !E.model ? UI.row('Motion style', UI.sel([['walk-cycle','Walk cycle'],['zombie','Zombie shamble'],['none','No procedural motion']], E.motion, v => { E.motion = v; cm(); })) : null,
      !E.model ? h('div', {class: 'hint'}, 'No model: uses the built-in jointed rig. Drop an FBX/GLB here for a custom exterior.') : null);
    if (E.model){
      const clipSel = (label, key) => { const s = UI.sel([['', '— auto —']], E[key], v => { E[key] = v; cm(); }); look.append(UI.row(label, s));
        W.allClips().then(cl => { const own = (holder && holder.userData.clips) || []; s.innerHTML = '';
          [['', '— auto —'], ...own.map(c => [c.name, c.name + ' (this model)']), ...cl.filter(c => c.path !== E.model).map(c => [c.key, VFS.base(c.path) + ' :: ' + c.clip.name])]
            .forEach(([v, l]) => s.append(h('option', {value: v, selected: v === E[key]}, l))); }); };
      clipSel('Idle anim', 'clipIdle'); clipSel('Walk anim', 'clipWalk'); clipSel('Attack anim', 'clipAttack'); clipSel('Death anim', 'clipDeath');
      look.append(h('div', {class: 'hint'}, 'Animations can come from other FBX files with the same skeleton (e.g. Mixamo "without skin" exports).'));
    }
    const snd = UI.sec('Sounds',
      UI.row('Hurt', UI.asset('audio', E.hurtSound, v => { E.hurtSound = v; cm(); this.renderInspector(); })),
      UI.row('Attack', UI.asset('audio', E.attackSound, v => { E.attackSound = v; cm(); this.renderInspector(); })),
      UI.row('Death', UI.asset('audio', E.deathSound, v => { E.deathSound = v; cm(); this.renderInspector(); })));
    // joints
    const jt = UI.sec('Joints (pose offsets °)');
    const setJ = (n, i, v) => { E.joints[n] = E.joints[n] || [0,0,0]; E.joints[n][i] = v; if (!E.joints[n].some(x => x)) delete E.joints[n]; applyJoints(o, holder); };
    const jointRow = n => { const arr = E.joints[n] || [0,0,0]; const w = h('div', {class: 'xyz'});
      [0,1,2].forEach(i => { const inp = UI.num(arr[i], v => setJ(n, i, v), v => { setJ(n, i, v); cm(); }, 5); w.append(h('label', null, inp, h('span', null, 'XYZ'[i]))); });
      return UI.row(n, w); };
    if (!E.model){ MANNEQUIN_JOINTS.forEach(n => jt.append(jointRow(n))); jt.append(h('div', {class: 'hint'}, 'This is the rest pose; walk / attack motions play on top of it.')); }
    else { const bones = listBones(holder);
      if (!bones.length) jt.append(h('div', {class: 'hint'}, holder && holder.userData.model ? 'This model has no skeleton.' : 'Loading model…'));
      else { Object.keys(E.joints).forEach(n => jt.append(jointRow(n)));
        jt.append(UI.row('Add bone', UI.sel([['', `— ${bones.length} bones —`], ...bones.map(b => [b, b])], '', v => { if (v){ E.joints[v] = E.joints[v] || [0,0,0.001]; cm(); this.renderInspector(); } }))); } }
    jt.append(h('button', {class: 'small', onclick: () => { E.joints = {}; applyJoints(o, holder); cm(); this.renderInspector(); }}, 'Reset pose'));
    return [st, look, jt, snd];
  },

  /* ====================== Events & Timeline ====================== */
  newEvent(name){ const ev = {id: uid('ev'), name: name || 'New event', actions: []}; P.events.push(ev); this.selEvent = ev.id; this.selAction = null; this.commit(); this.renderTimeline(); return ev; },
  renderTimeline(){
    const root = $('#tab-timeline'); root.innerHTML = '';
    const list = h('div', {class: 'list scroll'});
    for (const ev of P.events){
      const uses = this.eventUses(ev.id).length;
      list.append(h('div', {class: 'ev-item' + (ev.id === this.selEvent ? ' sel' : ''), onclick: () => { this.selEvent = ev.id; this.selAction = null; this.renderTimeline(); }},
        h('span', {class: 'nm'}, ev.name), h('span', {class: 'badge', title: 'actions'}, ev.actions.length), uses ? null : h('span', {class: 'badge', title: 'Nothing triggers this event yet', style: 'color:var(--ember2)'}, '!')));
    }
    if (!P.events.length) list.append(h('div', {class: 'empty-note'}, 'No events yet. An event is a group of actions on a timeline.'));
    root.append(h('div', {class: 'ev-list'}, list, h('div', {class: 'ev-tools'},
      h('button', {onclick: () => this.newEvent()}, '+ Event'),
      h('button', {onclick: () => { const ev = this.ev(); if (!ev) return; const c = clone(ev); c.id = uid('ev'); c.name += ' copy'; c.actions.forEach(a => a.id = uid('a')); P.events.push(c); this.selEvent = c.id; this.commit(); this.renderTimeline(); }}, 'Copy'),
      h('button', {class: 'danger', onclick: () => { const ev = this.ev(); if (!ev) return; P.events = P.events.filter(x => x !== ev); this.selEvent = P.events[0] && P.events[0].id; this.commit(); this.renderTimeline(); }}, 'Delete'))));
    const ev = this.ev();
    const main = h('div', {class: 'ev-main'}); root.append(main);
    if (!ev){ main.append(h('div', {class: 'empty-note'}, h('b', null, 'Events'), ' are groups of actions that run on a timeline in seconds after the event starts. Events start from interaction blocks, triggers (game time, touching objects, keys…), or other events.')); return; }
    // header
    const addSel = h('select', null, h('option', {value: ''}, '+ Add action…'));
    for (const g in ACTION_GROUPS){ const og = h('optgroup', {label: ACTION_GROUPS[g]}); for (const k in ACTIONS) if (ACTIONS[k].k === g) og.append(h('option', {value: k}, ACTIONS[k].label)); addSel.append(og); }
    addSel.onchange = () => { if (!addSel.value) return; const a = Object.assign({id: uid('a'), type: addSel.value, t: this.nextTime(ev)}, actionDefaults(addSel.value));
      ev.actions.push(a); this.selAction = a.id; this.commit(); this.renderTimeline(); };
    const uses = this.eventUses(ev.id);
    main.append(h('div', {class: 'ev-head'},
      UI.text(ev.name, v => { ev.name = v || 'Event'; this.commit(); this.renderTimeline(); this.renderInspector(); }),
      addSel, h('span', {class: 'hint'}, 'Zoom'),
      (() => { const z = h('input', {type: 'range', min: 30, max: 260, value: this.pps, style: 'width:90px'}); z.oninput = () => { this.pps = +z.value; this.drawTimeline(ev, tl); }; return z; })(),
      h('span', {class: 'hint', style: 'margin-left:auto'}, uses.length ? 'Started by: ' + uses.join(', ') : 'Not started by anything yet — link it from an interaction block, a trigger, or another event.')));
    main.querySelector('.ev-head input').classList.add('evname');
    const tl = h('div', {class: 'tl scroll'}); const form = h('div', {class: 'act-form scroll'});
    main.append(h('div', {class: 'ev-body'}, tl, form));
    this.drawTimeline(ev, tl); this.renderActionForm(ev, form);
  },
  ev(){ return P.events.find(e => e.id === this.selEvent); },
  nextTime(ev){ const sel = ev.actions.find(a => a.id === this.selAction); return sel ? round((+sel.t || 0) + Math.max(.5, ACTION_DURATION(sel))) : ev.actions.length ? round(Math.max(...ev.actions.map(a => (+a.t || 0)))) : 0; },
  eventUses(id){
    const out = []; for (const o of P.objects){ if (o.interact && o.interact.event === id) out.push('“' + o.name + '”'); if (o.enemy && o.enemy.deathEvent === id) out.push(o.name + ' death'); }
    for (const t of P.triggers) if (t.event === id) out.push(TRIGGER_TYPES[t.type].replace(/^When /, '').replace(/^At /, 'at ').split(' (')[0] + (t.type === 'time' ? ` ${t.time}s` : t.tag ? ` #${t.tag}` : ''));
    for (const e of P.events) for (const a of e.actions) if (a.type === 'triggerEvent' && a.event === id) out.push('event ' + e.name);
    return out;
  },
  drawTimeline(ev, tl){
    tl.innerHTML = ''; const pps = this.pps;
    const acts = ev.actions.slice().sort((a, b) => (+a.t || 0) - (+b.t || 0));
    const end = Math.max(10, ...acts.map(a => (+a.t || 0) + ACTION_DURATION(a) + 2));
    const width = end * pps + 40;
    const ruler = h('div', {class: 'tl-ruler', style: `width:${width}px`});
    const stepS = pps < 50 ? 2 : pps < 120 ? 1 : .5;
    for (let s = 0; s <= end; s += stepS) ruler.append(h('div', {class: 'tl-tick', style: `left:${10 + s * pps}px`}, s % 1 ? '' : s + 's'));
    const rows = h('div', {class: 'tl-rows', style: `width:${width}px`});
    if (!acts.length) rows.append(h('div', {class: 'empty-note'}, 'No actions. Use “+ Add action…”. Each action runs at its time (seconds after this event starts).'));
    for (const a of acts){
      const def = ACTIONS[a.type]; const d = ACTION_DURATION(a);
      const label = def.label + (a.target ? ' · ' + a.target : a.sound ? ' · ' + VFS.base(a.sound) : a.text ? ' · ' + String(a.text).slice(0, 24) : a.item ? ' · ' + a.item : '');
      const b = h('div', {class: `tl-block k-${def.k}` + (a.id === this.selAction ? ' sel' : '') + (d ? '' : ' inst'), title: `${(+a.t).toFixed(2)}s — ${label}`,
        style: `left:${10 + (+a.t || 0) * pps}px;` + (d ? `width:${Math.max(18, d * pps)}px` : '')}, `${(+a.t).toFixed(2)}s  ${label}`);
      b.addEventListener('pointerdown', e => {
        e.preventDefault(); try { b.setPointerCapture(e.pointerId); } catch(_){} const x0 = e.clientX, t0 = +a.t || 0; let moved = false;
        b.onpointermove = m => { const dt = (m.clientX - x0) / pps; if (Math.abs(m.clientX - x0) > 2) moved = true;
          let t = Math.max(0, t0 + dt); t = m.shiftKey ? round(t) : Math.round(t / .05) * .05; a.t = round(t); b.style.left = (10 + a.t * pps) + 'px'; b.firstChild.textContent = `${a.t.toFixed(2)}s  ${label}`; };
        b.onpointerup = () => { b.onpointermove = null; b.onpointerup = null; this.selAction = a.id; if (moved) this.commit(); this.renderTimeline(); };
      });
      rows.append(h('div', {class: 'tl-row'}, b));
    }
    tl.append(ruler, rows);
  },
  renderActionForm(ev, form){
    const a = ev.actions.find(x => x.id === this.selAction);
    if (!a){ form.append(h('div', {class: 'empty-note'}, 'Select an action block to edit it. Drag blocks left / right to change when they happen (Shift = no snapping).',
      h('div', {style: 'margin-top:10px'}, h('b', null, 'Colors: '), h('span', {style: 'color:var(--cyan)'}, 'objects '), h('span', {style: 'color:var(--green)'}, 'player '), h('span', {style: 'color:var(--violet)'}, 'screen/camera/text '), h('span', {style: 'color:var(--ember)'}, 'sound '), h('span', {style: 'color:var(--red)'}, 'enemies')))); return; }
    const def = ACTIONS[a.type]; const cm = () => { this.commit(); this.drawTimeline(ev, form.previousSibling); };
    const s = UI.sec(def.label,
      UI.row('Time (s)', UI.num(a.t, null, v => { a.t = Math.max(0, v); cm(); }, .1)),
      h('div', {class: 'hint'}, 'Seconds after this event starts.'));
    for (const k in def.p) s.append(...this.paramField(a, k, def.p[k], cm, form));
    if ('x' in def.p && 'z' in def.p){
      s.append(h('button', {class: 'small', onclick: () => {
        const t = this.orbit.target, c = W.camera.position;
        if (a.type === 'cameraLock'){ Object.assign(a, {x: round(c.x), y: round(c.y), z: round(c.z), lx: round(t.x), ly: round(t.y), lz: round(t.z)}); }
        else { const sel = this.obj(); const p = sel ? new THREE.Vector3().fromArray(sel.pos) : t; Object.assign(a, {x: round(p.x), y: round(p.y + (a.type === 'teleport' ? .1 : 0)), z: round(p.z)}); }
        cm(); this.renderTimeline(); }}, a.type === 'cameraLock' ? 'Use current editor view as camera' : 'Use selected object / view center position'));
    }
    s.append(h('div', {style: 'display:flex;gap:6px;margin-top:6px'},
      h('button', {onclick: () => { const c = clone(a); c.id = uid('a'); c.t = round(+a.t + .5); ev.actions.push(c); this.selAction = c.id; this.commit(); this.renderTimeline(); }}, 'Duplicate'),
      a.type === 'showTitle' ? h('button', {onclick: () => this.previewTitle(a)}, 'Preview text') : null,
      h('div', {style: 'flex:1'}),
      h('button', {class: 'danger', onclick: () => { ev.actions = ev.actions.filter(x => x !== a); this.selAction = null; this.commit(); this.renderTimeline(); }}, 'Delete')));
    form.append(s);
  },
  paramField(a, k, spec, cm, form){
    const lab = {target: 'Target (tag/name)', template: 'Enemy template', toTarget: 'Or to object', lookAt: 'Look at object', at: 'Follow object', lx: 'Look at X', ly: 'Look at Y', lz: 'Look at Z',
      alsoCollision: 'Also collision', from: 'Fly from object', takeObject: 'Remove that object', animate: 'Pickup animation', equip: 'Hold it now', atTemplate: 'At template spot', setYaw: 'Set facing', typeSpeed: 'Letters / sec', blend: 'Blend time (s)', follow: 'Keep tracking'}[k] || k[0].toUpperCase() + k.slice(1);
    const set = v => { a[k] = v; cm(); };
    if (Array.isArray(spec)) return [UI.row(lab, UI.sel(spec, a[k], set))];
    if (typeof spec === 'number') return [UI.row(lab, UI.num(a[k], null, set))];
    if (typeof spec === 'boolean') return [UI.row(lab, UI.chk(a[k], set))];
    if (/^#/.test(spec)) return [UI.row(lab, UI.color(a[k], set))];
    if (spec === 'target') return [UI.row(lab, UI.text(a[k], set, 'tag or name', 'dl-targets'))];
    if (spec === 'item') return [UI.row(lab, UI.text(a[k], set, 'Key', 'dl-items'))];
    if (spec === 'area') return [UI.row(lab, UI.area(a[k], set))];
    if (spec === 'event') return [UI.row(lab, UI.sel([['', '— choose —'], ...P.events.map(e => [e.id, e.name])], a[k], set))];
    if (spec === 'clip') return [UI.row(lab, UI.text(a[k], set, 'clip name or file.fbx::clip'))];
    if (spec.startsWith('asset:')) return [UI.row(lab, UI.asset(spec.slice(6), a[k], v => { a[k] = v; cm(); this.renderTimeline(); }))];
    if (spec === 'preset') return [UI.row('Style preset', UI.sel(Object.keys(TEXT_PRESETS), a[k], v => { a.preset = v; a.style = clone(TEXT_PRESETS[v]); cm(); this.renderTimeline(); }))];
    if (spec === 'style'){
      a.style = Object.assign(clone(TEXT_PRESETS[a.preset] || TEXT_PRESETS.Cinematic), a.style || {});
      const box = h('details', {style: 'border:1px solid var(--line);border-radius:4px;padding:4px 6px'}, h('summary', {style: 'cursor:pointer;color:var(--fg2)'}, 'Text style (font, size, color, outline, glow, position, animation)'));
      const g = h('div', {style: 'display:flex;flex-direction:column;gap:5px;margin-top:6px'}); box.append(g);
      const L = {letterSpacing: 'Letter spacing', animIn: 'Animate in', animOut: 'Animate out', fadeTime: 'Anim time (s)', strokeColor: 'Outline color', stroke: 'Outline px', glowColor: 'Shadow/glow color', bgColor: 'Background color', subSize: 'Subtitle size', subColor: 'Subtitle color', x: 'Custom X %', y: 'Custom Y %', bg: 'Background'};
      for (const f in TEXT_STYLE_FIELDS){ const [t, o] = TEXT_STYLE_FIELDS[f]; const sv = v => { a.style[f] = v; cm(); };
        let c; if (t === 'font') c = UI.sel(Fonts.list(), a.style[f], sv); else if (t === 'num') c = UI.num(a.style[f], null, sv, 1); else if (t === 'bool') c = UI.chk(a.style[f], sv);
        else if (t === 'sel') c = UI.sel(o, a.style[f], sv); else if (t === 'color') c = f === 'bgColor' ? UI.text(a.style[f], sv, '#000000aa') : UI.color(a.style[f], sv);
        g.append(UI.row(L[f] || f[0].toUpperCase() + f.slice(1), c)); }
      box.open = !!this._styleOpen; box.addEventListener('toggle', () => this._styleOpen = box.open);
      return [box];
    }
    return [UI.row(lab, UI.text(a[k], set))];
  },
  previewTitle(a){
    const hud = $('#hud'); hud.hidden = false; hud.classList.add('preview');
    Runtime.showTitle(a); clearTimeout(this._pv);
    this._pv = setTimeout(() => { if (!Runtime.active){ hud.hidden = true; } hud.classList.remove('preview'); }, (+a.duration || 3) * 1000 + 200);
  },

  /* ====================== Triggers ====================== */
  renderTriggers(){
    const root = $('#tab-triggers'); root.innerHTML = '';
    const tbl = h('table', {class: 'tbl'}, h('tr', null, h('th', {style: 'width:240px'}, 'When'), h('th', null, 'Details'), h('th', {style: 'width:220px'}, 'Run event'), h('th', {style: 'width:70px'}, 'Once'), h('th', {style: 'width:40px'})));
    const cm = () => { this.commit(); };
    for (const t of P.triggers){
      const det = h('div', {style: 'display:flex;gap:6px;align-items:center'});
      const d = (lab, el) => det.append(h('span', {class: 'hint'}, lab), el);
      if (t.type === 'time'){ d('at', UI.num(t.time, null, v => { t.time = v; cm(); })); d('s, repeat every', UI.num(t.repeat || 0, null, v => { t.repeat = v; cm(); })); det.append(h('span', {class: 'hint'}, 's (0 = no)')); }
      if (['clickLeft','clickRight','aim'].includes(t.type)){ d('tag / name', UI.text(t.tag, v => { t.tag = v; cm(); }, 'blank = any object', 'dl-targets')); d('max distance', UI.num(t.range || 0, null, v => { t.range = v; cm(); }, 1)); det.append(h('span', {class: 'hint'}, '0 = any')); }
      if (t.type === 'objTouch'){ d('object (tag/name)', UI.text(t.tag, v => { t.tag = v; cm(); }, 'ball', 'dl-targets')); d('touches', UI.text(t.tag2, v => { t.tag2 = v; cm(); }, 'goal', 'dl-targets')); }
      if (t.type === 'touch' || t.type === 'enemyKilled') d('tag / name', UI.text(t.tag, v => { t.tag = v; cm(); }, t.type === 'touch' ? 'hazard' : 'blank = any enemy', 'dl-targets'));
      if (t.type === 'key') det.append(this.keyCapture(t.key, v => { t.key = v; cm(); }));
      if (t.type === 'itemCount'){ d('item', UI.text(t.item, v => { t.item = v; cm(); }, 'Coin', 'dl-items')); d('count ≥', UI.num(t.count || 1, null, v => { t.count = v; cm(); }, 1)); }
      if (t.type === 'flag'){ d('flag', UI.text(t.flag, v => { t.flag = v; cm(); })); d('=', UI.text(t.value, v => { t.value = v; cm(); })); }
      if (t.type === 'start') det.append(h('span', {class: 'hint'}, 'Runs once when Play starts.'));
      tbl.append(h('tr', null,
        h('td', null, UI.sel(Object.entries(TRIGGER_TYPES), t.type, v => { t.type = v; cm(); this.renderTriggers(); })),
        h('td', null, det),
        h('td', null, UI.sel([['', '— choose —'], ...P.events.map(e => [e.id, e.name])], t.event, v => { t.event = v; cm(); this.renderTimeline(); })),
        h('td', null, t.type === 'key' || t.type === 'start' ? '' : UI.chk(t.once !== false, v => { t.once = v; cm(); })),
        h('td', null, h('button', {class: 'small danger', onclick: () => { P.triggers = P.triggers.filter(x => x !== t); cm(); this.renderTriggers(); }}, '✕'))));
    }
    const blocks = P.objects.filter(o => o.type === 'interaction');
    root.append(h('div', {class: 'tbl-wrap scroll'},
      h('div', {style: 'display:flex;gap:8px;align-items:center'}, h('button', {onclick: () => { P.triggers.push({id: uid('tr'), type: 'time', time: 0, event: P.events[0] ? P.events[0].id : '', once: true}); cm(); this.renderTriggers(); }}, '+ Trigger'),
        h('span', {class: 'hint'}, 'Triggers start events from the game clock, touching tagged objects, keys, kills, items or flags. Interaction blocks start events too (set in the Inspector).')),
      tbl,
      blocks.length ? h('div', {class: 'hint'}, 'Interaction blocks: ', ...blocks.map((o, i) => [i ? ', ' : '', h('a', {href: '#', style: 'color:var(--ember2)', onclick: e => { e.preventDefault(); this.select(o.id); this.focus(); }}, o.name),
        ' → ', (P.events.find(e => e.id === o.interact.event) || {name: 'no event'}).name])) : null));
  },
  keyCapture(code, onSet){
    const b = h('button', {class: 'keycap'}, keyLabel(code) || 'press to set');
    b.onclick = () => { b.classList.add('listening'); b.textContent = 'press a key…';
      const fn = e => { e.preventDefault(); e.stopPropagation(); window.removeEventListener('keydown', fn, true); b.classList.remove('listening'); if (e.code !== 'Escape') onSet(e.code); b.textContent = keyLabel(e.code === 'Escape' ? code : e.code); };
      window.addEventListener('keydown', fn, true); };
    return b;
  },

  /* ====================== Assets ====================== */
  renderAssets(){
    const root = $('#tab-assets'); if (!root || !P) return; root.innerHTML = '';
    const folders = new Set(['assets/textures', 'assets/models', 'assets/sfx', 'assets/music', 'assets/fonts', 'assets/other']);
    for (const p of VFS.files.keys()) folders.add(VFS.dir(p) || '(root)');
    const tree = h('div', {class: 'as-tree scroll'});
    for (const f of [...folders].sort()){ const n = [...VFS.files.keys()].filter(p => (VFS.dir(p) || '(root)') === f).length;
      tree.append(h('div', {class: 'as-folder' + (f === this.folder ? ' sel' : ''), onclick: () => { this.folder = f; this.renderAssets(); }}, h('span', null, f.replace(/^assets\//, '') ), h('span', {class: 'hint'}, n))); }
    tree.append(h('div', {class: 'as-folder' + (this.folder === 'saves' ? ' sel' : ''), onclick: () => { this.folder = 'saves'; this.renderAssets(); }}, h('span', null, 'saves'), h('span', {class: 'hint'}, Object.keys(P.saves || {}).length)));
    const nf = h('input', {placeholder: 'new folder name', style: 'margin:8px 10px 0'}); nf.onchange = () => { const n = nf.value.trim().replace(/[^\w\- ]/g, ''); if (n){ this.folder = 'assets/' + n; this._extraFolders = (this._extraFolders || []).concat(this.folder); this.renderAssets(); } };
    (this._extraFolders || []).forEach(f => folders.add(f));
    if (this._extraFolders) for (const f of this._extraFolders) if (![...tree.children].some(c => c.textContent.startsWith(f.replace(/^assets\//, '')))) tree.insertBefore(h('div', {class: 'as-folder' + (f === this.folder ? ' sel' : ''), onclick: () => { this.folder = f; this.renderAssets(); }}, h('span', null, f.replace(/^assets\//, '')), h('span', {class: 'hint'}, 0)), tree.lastChild);
    tree.append(nf);
    const grid = h('div', {class: 'as-grid scroll'});
    const head = h('div', {class: 'ev-head'}, h('b', {class: 'mono'}, this.folder + '/'),
      this.folder !== 'saves' ? h('button', {onclick: () => $('#assetInput').click()}, 'Import files here') : null,
      h('span', {class: 'hint'}, this.folder === 'saves' ? 'In-game saves (F5 / pause menu / "Save game" action). Exported as saves/*.json in the zip.' : 'Drag files from your computer here. Drag a card onto an object, the viewport or an inspector slot.'));
    if (this.folder === 'saves'){
      for (const k in P.saves || {}){ const s = P.saves[k];
        grid.append(h('div', {class: 'as-card'}, h('div', {class: 'th'}, 'SAVE'), h('div', {class: 'nm'}, k + '.json'), h('div', {class: 'nm hint'}, (s.savedAt || '').replace('T', ' ').slice(0, 16)),
          h('div', {class: 'ac'}, this.armedButton('Delete', () => { delete P.saves[k]; this.persist(); this.renderAssets(); })))); }
      if (!Object.keys(P.saves || {}).length) grid.append(h('div', {class: 'empty-note'}, 'No saves yet. Play the game and press ' + P.settings.keys.quickSave + ' or use the pause menu.'));
    } else {
      const files = [...VFS.files.keys()].filter(p => (VFS.dir(p) || '(root)') === this.folder).sort();
      for (const p of files){ const f = VFS.files.get(p);
        const th = h('div', {class: 'th'}); if (f.kind === 'image') th.append(h('img', {src: f.url, loading: 'lazy', draggable: false}));
        else if (f.kind === 'font'){ th.textContent = 'Aa Bb 12'; th.style.cssText = `font-family:"${Fonts.familyOf(p)}";font-size:17px;color:var(--fg)`; }
        else th.textContent = VFS.ext(p).toUpperCase();
        const card = h('div', {class: 'as-card k-' + f.kind, draggable: true, title: p}, th, h('div', {class: 'nm'}, VFS.base(p)),
          h('div', {class: 'ac'},
            f.kind === 'audio' ? h('button', {onclick: () => previewAudio(p), title: 'Play'}, '▶') : null,
            f.kind === 'model' ? h('button', {onclick: () => this.add('model', null, {model: p, name: VFS.base(p).replace(/\.\w+$/, '')}), title: 'Place in scene'}, '+') : null,
            h('button', {title: 'Rename', onclick: () => this.renameAsset(card, p)}, '✎'),
            this.armedButton('✕', () => { VFS.remove(p); this.persist(); })));
        card.addEventListener('dragstart', e => { e.dataTransfer.setData('text/kiln-asset', p); e.dataTransfer.effectAllowed = 'copy'; });
        grid.append(card); }
      if (!files.length) grid.append(h('div', {class: 'empty-note'}, 'Empty folder. Import or drop files here: images (png, jpg, webp…), models (fbx, glb), sounds (wav, mp3, ogg…), fonts (ttf, otf, woff).'));
      grid.addEventListener('dragover', e => { if (e.dataTransfer.types.includes('Files')){ e.preventDefault(); grid.classList.add('over'); } });
      grid.addEventListener('dragleave', () => grid.classList.remove('over'));
      grid.addEventListener('drop', e => { e.preventDefault(); grid.classList.remove('over'); if (e.dataTransfer.files.length) this.importFiles(e.dataTransfer.files, this.folder === '(root)' ? null : this.folder); });
    }
    root.append(tree, h('div', {class: 'as-main'}, head, grid));
  },
  armedButton(label, fn){ const b = h('button', {class: 'danger', title: 'Delete'}, label);
    b.onclick = () => { if (b._armed){ fn(); return; } b._armed = true; b.textContent = 'Sure?'; setTimeout(() => { b._armed = false; b.textContent = label; }, 2200); }; return b; },
  renameAsset(card, p){
    const nm = card.querySelector('.nm'); const i = h('input', {value: VFS.base(p), style: 'width:100%'}); nm.replaceWith(i); i.focus(); i.select();
    const done = () => { const n = i.value.trim(); if (n && n !== VFS.base(p)){ const to = VFS.dir(p) + '/' + n;
      VFS.rename(p, to); const fix = o => { for (const k in o){ if (o[k] === p) o[k] = to; else if (o[k] && typeof o[k] === 'object') fix(o[k]); } }; fix(P.objects); fix(P.events); fix(P.items); fix(P.settings);
      W.invalidateTextures(); W.modelCache.clear(); W.buildAll(); this.commit(); this.persist(); this.renderInspector(); } else this.renderAssets(); };
    i.onkeydown = e => { if (e.key === 'Enter') i.blur(); if (e.key === 'Escape'){ i.value = VFS.base(p); i.blur(); } }; i.onblur = done;
  },

  /* ====================== Items ====================== */
  renderItems(){
    const root = $('#tab-items'); root.innerHTML = ''; P.items.forEach(normItem);
    if (!P.items.find(i => i.name === this.selItem)) this.selItem = P.items[0] ? P.items[0].name : null;
    const list = h('div', {class: 'list scroll'});
    for (const it of P.items){ const k = {gun: 'GUN', sword: 'SWORD', none: ''}[it.kind];
      list.append(h('div', {class: 'ev-item' + (it.name === this.selItem ? ' sel' : ''), onclick: () => { this.selItem = it.name; this.renderItems(); }},
        it.icon && VFS.url(it.icon) ? h('img', {src: VFS.url(it.icon), style: 'width:18px;height:18px;object-fit:contain'}) : null,
        h('span', {class: 'nm'}, it.name), k ? h('span', {class: 'badge'}, k) : null, it.model ? h('span', {class: 'badge', title: 'has a model'}, '3D') : null)); }
    if (!P.items.length) list.append(h('div', {class: 'empty-note'}, 'No items yet.'));
    const uniq = base => { let n = base, i = 2; while (P.items.find(x => x.name === n)) n = base + ' ' + i++; return n; };
    root.append(h('div', {class: 'ev-list'}, list, h('div', {class: 'ev-tools'},
      h('button', {onclick: () => { const it = newItemDef(uniq('Item')); P.items.push(it); this.selItem = it.name; this.commit(); this.renderItems(); this.updateDatalists(); }}, '+ Item'),
      h('button', {onclick: () => { const it = P.items.find(x => x.name === this.selItem); if (!it) return; const c = clone(it); c.name = uniq(it.name); P.items.push(c); this.selItem = c.name; this.commit(); this.renderItems(); }}, 'Copy'),
      this.armedButton('Delete', () => { P.items = P.items.filter(x => x.name !== this.selItem); this.commit(); this.renderItems(); this.updateDatalists(); }))));
    const it = P.items.find(x => x.name === this.selItem);
    const main = h('div', {class: 'it-cols scroll'}); root.append(main);
    if (!it){ main.append(h('div', {class: 'empty-note'}, h('b', null, 'Items'), ' are things the player can hold. Give one a model (any group or object in your scene), choose sword or gun, then give it with the "Give player item" action or place its model in the world as a pickup.')); Items.preview(null); return; }
    const cm = () => this.commit(), rb = () => { this.commit(); this.previewItem(); }, rr = () => { this.commit(); this.renderItems(); };
    // ---- basics
    main.append(UI.sec('Item',
      UI.row('Name', UI.text(it.name, v => { v = v.trim(); if (!v || P.items.some(x => x !== it && x.name === v)) { this.renderItems(); return; } this.renameItem(it.name, v); it.name = v; this.selItem = v; rr(); this.updateDatalists(); })),
      UI.row('Icon', UI.asset('image', it.icon, v => { it.icon = v; rr(); })),
      UI.row('Description', UI.text(it.desc, v => { it.desc = v; cm(); })),
      UI.row('Type', UI.sel([['none', 'Held item (no attack)'], ['sword', 'Sword / melee'], ['gun', 'Gun']], it.kind, v => { it.kind = v; rb(); this.renderItems(); })),
      UI.row('Damage', UI.num(it.damage, null, v => { it.damage = v; cm(); }, 1)),
      h('div', {class: 'hint'}, it.kind === 'none' ? 'Damage above 0 makes left click do a bash with it.' : it.kind === 'sword' ? 'Damage per hit.' : 'Damage per bullet.')));
    // ---- model
    const groups = P.objects.filter(o => o.type === 'group');
    const lab = o => '▾ ' + o.name + ' (' + P.objects.filter(x => x.parent === o.id).length + ')' + (o.parent ? '  in ' + ((this.obj(o.parent) || {}).name || '?') : '');
    const opts = [['', it.kind === 'gun' ? '— built-in gun —' : it.kind === 'sword' ? '— built-in sword —' : '— built-in cube —'], ...groups.map(o => [o.id, lab(o)])];
    const bad = it.model && (!this.obj(it.model) || this.obj(it.model).type !== 'group');
    if (bad) opts.push([it.model, '⚠ not a group — pick a group']);
    const H = it.hold;
    main.append(UI.sec('Model (held in front of the player)',
      UI.row('Model group', UI.sel(opts, it.model, v => { it.model = v; rb(); this.renderItems(); this.renderHierarchy(); })),
      groups.length ? null : h('div', {class: 'hint', style: 'color:var(--ember2)'}, 'No groups yet. Select the objects that make your model and press G.'),
      h('div', {style: 'display:flex;gap:4px;flex-wrap:wrap'},
        h('button', {class: 'small', onclick: () => {
          let o = this.sel && this.obj(this.topGroup(this.sel));
          if (!o || o.type !== 'group'){ this.edToast('Select a group (select objects, press G)'); return; }
          it.model = o.id; rb(); this.renderItems(); this.renderHierarchy(); }}, 'Use selected group'),
        it.model ? h('button', {class: 'small', onclick: () => { this.select(it.model); this.focus(); }}, 'Show in scene') : null),
      it.kind === 'gun' && !it.model ? UI.row('Built-in look', UI.sel([['pistol', 'Pistol'], ['rifle', 'Rifle']], it.gun.builtin, v => { it.gun.builtin = v; rb(); })) : null,
      UI.row('Size in hand', UI.num(it.size, null, v => { it.size = v; rb(); }, .05), h('span', {class: 'hint'}, 'm (0 = real size)')),
      UI.row('Hand position', UI.xyz(H.pos, null, cm, .02)),
      UI.row('Hand rotation °', UI.xyz(H.rot, null, cm, 5)),
      UI.row('Hand scale', UI.num(H.scale, v => { H.scale = v; }, v => { H.scale = v; cm(); }, .05)),
      UI.row('Idle motion', UI.sel(ITEM_MOTIONS, it.motion, v => { it.motion = v; cm(); })),
      h('div', {class: 'hint'}, 'The preview in the viewport shows exactly how it will look in hand. X = right, Y = up, Z = forward is negative.')));
    // ---- pickup
    main.append(UI.sec('Getting it',
      it.model ? UI.row('Model is a pickup', UI.chk(it.pickupInWorld, v => { it.pickupInWorld = v; cm(); }), h('span', {class: 'hint'}, 'off = hidden in game, used only as the look')) : null,
      it.model && it.pickupInWorld ? UI.row('Pick up by', UI.sel([['interact', 'Looking + E / left click'], ['touch', 'Walking into it']], it.pickupMode, v => { it.pickupMode = v; cm(); })) : null,
      UI.row('Pickup sound', UI.asset('audio', it.pickupSound, v => { it.pickupSound = v; rr(); })),
      UI.row('Equip sound', UI.asset('audio', it.equipSound, v => { it.equipSound = v; rr(); })),
      h('div', {class: 'hint'}, 'Blank sounds use the built-in ones. "Give player item" in an event also flies the item into your hand from the object you choose.')));
    // ---- sword
    if (it.kind === 'sword'){ const S = it.sword;
      const sec = UI.sec('Sword',
        UI.row('Reach', UI.num(S.range, null, v => { S.range = v; cm(); }, .1), h('span', {class: 'hint'}, 'm')),
        UI.row('Hit arc', UI.num(S.arc, null, v => { S.arc = v; cm(); }, 5), h('span', {class: 'hint'}, '° left/right')),
        UI.row('Pause after', UI.num(S.cooldown, null, v => { S.cooldown = v; cm(); }, .05), h('span', {class: 'hint'}, 's')),
        UI.row('Swing sound', UI.asset('audio', S.swingSound, v => { S.swingSound = v; rr(); })),
        UI.row('Hit sound', UI.asset('audio', S.hitSound, v => { S.hitSound = v; rr(); })));
      main.append(sec);
      const ms = UI.sec('Swing motions (combo, in order)');
      S.motions.forEach((mo, mi) => {
        const P0 = SWING_PRESETS[mo.preset];
        ms.append(h('div', {class: 'mo-row'}, h('b', {class: 'mono'}, mi + 1),
          UI.sel([...Object.entries(SWING_PRESETS).map(([k, v]) => [k, v.label]), ['custom', 'Custom keyframes…']], mo.preset, v => {
            if (v === 'custom' && !(mo.keys || []).length && P0) mo.keys = clone(P0.keys); mo.preset = v; const np = SWING_PRESETS[v]; if (np){ mo.dur = np.dur; mo.hitAt = np.hitAt; } rr(); }),
          h('button', {class: 'small', title: 'Play this motion in the preview', onclick: () => this.testSwing(it, mi)}, '▶'),
          h('button', {class: 'small danger', onclick: () => { S.motions.splice(mi, 1); rr(); }}, '✕')),
          UI.row('Duration s', UI.num(mo.dur, null, v => { mo.dur = v; cm(); }, .05), h('span', {class: 'hint'}, 'hit at'), UI.num(mo.hitAt, null, v => { mo.hitAt = Math.max(0, Math.min(1, v)); cm(); }, .05)));
        if (mo.preset === 'custom'){
          const tb = h('table', {class: 'tbl kf'}, h('tr', null, h('th', null, 't 0-1'), h('th', null, 'move x y z (m)'), h('th', null, 'turn x y z (°)'), h('th')));
          (mo.keys = mo.keys || []).forEach((k, ki) => tb.append(h('tr', null,
            h('td', null, UI.num(k.t, null, v => { k.t = Math.max(0, Math.min(1, v)); cm(); }, .05)),
            h('td', null, UI.xyz(k.p, null, cm, .02)), h('td', null, UI.xyz(k.r, null, cm, 5)),
            h('td', null, h('button', {class: 'small danger', onclick: () => { mo.keys.splice(ki, 1); rr(); }}, '✕')))));
          ms.append(tb, h('div', {style: 'display:flex;gap:4px;flex-wrap:wrap'},
            h('button', {class: 'small', onclick: () => { const last = mo.keys[mo.keys.length - 1]; mo.keys.push({t: last ? Math.min(.95, +last.t + .2) : .3, p: last ? last.p.slice() : [0, 0, 0], r: last ? last.r.slice() : [0, 0, 0]}); rr(); }}, '+ Keyframe'),
            UI.sel([['', 'Load a preset…'], ...Object.entries(SWING_PRESETS).map(([k, v]) => [k, v.label])], '', v => { if (v){ mo.keys = clone(SWING_PRESETS[v].keys); rr(); } })),
            h('div', {class: 'hint'}, 'Each keyframe is a pose at a moment of the swing (0 = start, 1 = end). It always starts and ends at the rest pose.'));
        }
      });
      ms.append(h('div', {style: 'display:flex;gap:4px'}, h('button', {class: 'small', onclick: () => { S.motions.push({preset: 'overhead', dur: .5, hitAt: .55, keys: []}); rr(); }}, '+ Motion'),
        h('button', {class: 'small', onclick: () => this.testSwing(it)}, '▶ Play combo')),
        h('div', {class: 'hint'}, 'Each left click plays the next motion. Stop clicking for 1 s and the combo restarts.'));
      main.append(ms);
    }
    // ---- gun
    if (it.kind === 'gun'){ const G = it.gun, n = (lab, k, st, hint) => UI.row(lab, UI.num(G[k], null, v => { G[k] = v; cm(); }, st), hint ? h('span', {class: 'hint'}, hint) : null);
      main.append(UI.sec('Gun',
        n('Magazine', 'magSize', 1), n('Spare ammo', 'startAmmo', 1, 'given on first pickup'),
        UI.row('Ammo type', UI.text(G.ammoType, v => { G.ammoType = v; cm(); }, it.name), h('span', {class: 'hint'}, 'ammo boxes')),
        UI.row('Infinite ammo', UI.chk(G.infinite, v => { G.infinite = v; cm(); })),
        n('Shots / sec', 'fireRate', .5), UI.row('Automatic', UI.chk(G.auto, v => { G.auto = v; cm(); }), h('span', {class: 'hint'}, 'hold to fire')),
        n('Reload time', 'reloadTime', .1, 's'), n('Recoil', 'recoil', .1)),
        UI.sec('Bullets',
          n('Bullet size', 'bulletSize', .01, 'm'), n('Bullet speed', 'bulletSpeed', 10, 'm/s'),
          UI.row('Bullet color', UI.color(G.bulletColor, v => { G.bulletColor = v; cm(); })),
          n('Bullet drop', 'bulletDrop', .1, '0 = straight'), n('Spread', 'spread', .1, '°'), n('Range', 'range', 10, 'm')),
        UI.sec('Gun sounds',
          UI.row('Shot', UI.asset('audio', G.shotSound, v => { G.shotSound = v; rr(); })),
          UI.row('Reload', UI.asset('audio', G.reloadSound, v => { G.reloadSound = v; rr(); })),
          UI.row('Empty click', UI.asset('audio', G.emptySound, v => { G.emptySound = v; rr(); })),
          h('button', {class: 'small', onclick: () => Items.testUse(it)}, '▶ Test shot (preview)')));
    }
    this.previewItem();
  },
  previewItem(){ if (this.curTab !== 'items' || Runtime.active){ Items.preview(null); return; } Items.preview(P.items.find(x => x.name === this.selItem) || null); },
  testSwing(it, mi){
    Items.preview(it);
    const list = mi != null ? [it.sword.motions[mi]] : it.sword.motions.slice(); let t = 0;
    for (const mo of list){ setTimeout(() => { if (!Items.previewDef) return; Items.combo = 0; Items.useT = 0; Items.swing = null; Items.startSwing({kind: 'sword', sword: {motions: [mo], cooldown: 0}, damage: 0});
      const snd = it.sword.swingSound || SFX + 'sword_swing.wav'; previewAudio(VFS.has(snd) ? snd : ensureAsset(snd)); }, t * 1000); t += (+mo.dur || .45) + .15; }
  },
  renameItem(from, to){
    const fix = o => { if (!o || typeof o !== 'object') return; for (const k in o){ if (['item', 'requireItem', 'pickItem'].includes(k) && o[k] === from) o[k] = to; else fix(o[k]); } };
    fix(P.events); fix(P.objects); fix(P.triggers);
  },

  /* ====================== Settings modal ====================== */
  openSettings(){
    const S = P.settings; const body = $('#modalBody'); body.innerHTML = ''; $('#modalTitle').textContent = 'Project settings'; $('#modal').hidden = false;
    const cm = () => { W.applyEnvironment(); this.commit(); };
    const n = (lab, k, step, hint) => UI.row(lab, UI.num(S[k], null, v => { S[k] = v; cm(); }, step), hint ? h('span', {class: 'hint'}, hint) : null);
    const c = (lab, k) => UI.row(lab, UI.color(S[k], v => { S[k] = v; cm(); }, v => { S[k] = v; W.applyEnvironment(); }));
    const b = (lab, k) => UI.row(lab, UI.chk(S[k], v => { S[k] = v; cm(); }));
    const a = (lab, k) => UI.row(lab, UI.asset('audio', S[k], v => { S[k] = v; cm(); this.openSettings(); }));
    const keys = UI.sec('Controls (click, then press a key)');
    for (const k in KEY_LABELS) keys.append(UI.row(KEY_LABELS[k], this.keyCapture(S.keys[k], v => { S.keys[k] = v; cm(); })));
    keys.append(h('div', {class: 'hint'}, 'Left / right click on interaction blocks is fixed to the mouse. Left click on an enemy attacks it.'));
    body.append(h('div', {class: 'set-grid'},
      h('div', null,
        UI.sec('Movement & physics', n('Walk speed', 'walkSpeed', .1, 'm/s'), n('Run speed', 'runSpeed', .1, 'm/s'), n('Jump force', 'jumpForce', .1), n('Gravity', 'gravity', .5, 'm/s²'),
          n('Air control', 'airControl', .05, '0–1'), n('Step height', 'stepHeight', .05, 'stairs'), n('Player height', 'playerHeight', .05), n('Player radius', 'playerRadius', .05), n('Eye height', 'eyeHeight', .05), n('Fall reset Y', 'killY', 1)),
        UI.sec('Combat & interaction', n('Max health', 'maxHealth', 5), n('Player damage', 'playerDamage', 1), n('Attack range', 'attackRange', .1), n('Attack cooldown', 'attackCooldown', .05, 's'), n('Interact range', 'interactRange', .1, 'm'), n('Throw force', 'throwForce', .5), b('Bunny hop', 'bhop'), n('Bhop speed gain', 'bhopGain', .01, '× per hop'), n('Bhop max speed', 'bhopMax', 1), n('Aim zoom', 'aimZoom', .1, '× (hold aim key)')),
        UI.sec('Camera', UI.row('View', UI.sel([['first','First person'],['third','Third person']], S.camera, v => { S.camera = v; cm(); })), n('3rd-person distance', 'thirdPersonDistance', .5),
          n('Field of view', 'fov', 1), n('Mouse sensitivity', 'mouseSensitivity', .1), b('Invert Y', 'invertY'))),
      h('div', null, keys,
        UI.sec('Audio', a('Background music', 'music'), n('Music volume', 'musicVolume', .05), a('Footstep sound', 'footstepSound'), n('Step interval', 'footstepInterval', .02, 's'), a('Player hurt sound', 'hurtSound')),
        UI.sec('World', c('Sky color', 'sky'), c('Fog color', 'fogColor'), n('Fog start', 'fogNear', 5), n('Fog end (0 = off)', 'fogFar', 5), n('Ambient light', 'ambient', .05), n('Sun light', 'sunIntensity', .05)),
        UI.sec('Editor', UI.row('Editor font', UI.sel(EDITOR_FONTS, getEditorFont(), v => { setEditorFont(v); }))),
        UI.sec('Game display (saved in the exported zip)',
          UI.row('Resolution', UI.sel(RESOLUTIONS, S.renderHeight || 0, v => { S.renderHeight = +v; cm(); })),
          UI.row('FPS limit', UI.sel(FPS_CAPS, S.fpsCap || 0, v => { S.fpsCap = +v; cm(); })),
          b('Pixelated upscaling', 'pixelated'), b('Start fullscreen (launcher)', 'fullscreen'),
          h('div', {class: 'hint'}, 'Used in Play mode and in the Kiln Launcher. Lower resolution = higher FPS on slow PCs.')),
        UI.sec('Graphics & performance', b('Shadows', 'shadows'), n('Resolution scale', 'pixelRatio', .1, '0.5 = faster'), b('Show FPS in game', 'showFps'), b('Show HUD', 'showHud')))));
  },
};

function newProject(){
  return {format: 'kiln-project-1', name: 'MyGame', settings: DEFAULT_SETTINGS(),
    objects: [newObject('plane', {name: 'Ground', id: uid()}), newObject('spawn', {name: 'Player spawn', pos: [0,0,6], id: uid()})],
    events: [], triggers: [], items: [], saves: {}};
}

const EDITOR_FONTS = [['Geometry Dash','Geometry Dash'],['Barlow','Barlow (clean)'],['VT323','VT323 — 80s terminal'],['Press Start 2P','Press Start 2P — arcade'],
  ['Share Tech Mono','Share Tech Mono — 80s computer'],['Silkscreen','Silkscreen — pixel'],['Orbitron','Orbitron — 80s sci-fi'],['Audiowide','Audiowide — 80s TV logo'],
  ['Michroma','Michroma — 70s space TV'],['Syncopate','Syncopate — 70s wide'],['Righteous','Righteous — 70s'],['Bungee','Bungee — TV sign'],
  ['Bebas Neue','Bebas Neue — titles'],['Shrikhand','Shrikhand — 70s groovy'],['Monoton','Monoton — 80s neon']];
function getEditorFont(){ try { return localStorage.getItem('kiln-editor-font') || 'Geometry Dash'; } catch(e){ return 'Geometry Dash'; } }
function setEditorFont(f){ try { localStorage.setItem('kiln-editor-font', f); } catch(e){}
  const r = document.documentElement.style;
  if (f === 'Barlow'){ r.removeProperty('--ui'); r.removeProperty('--mono'); return; }
  const mono = ['VT323','Share Tech Mono','Press Start 2P','Silkscreen'].includes(f) || f === 'Geometry Dash';
  r.setProperty('--ui', `"${f}","Barlow",system-ui,sans-serif`); r.setProperty('--mono', mono ? `"${f}","JetBrains Mono",monospace` : `"JetBrains Mono",ui-monospace,monospace`);
}
