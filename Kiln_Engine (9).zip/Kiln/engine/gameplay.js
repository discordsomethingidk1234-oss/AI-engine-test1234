/* ---------- Gameplay add-ons: guns, ammo, car with gears, password keypads, damage blocks, checkpoints, bhop ---------- */
const SFX = 'assets/sfx/';
function builtinSfxUrl(path){
  const k = path && (window.BUILTIN_SFX || {})[path.startsWith('assets/') ? path : SFX + VFS.base(path)];
  if (!k) return null; Gameplay._cache = Gameplay._cache || {};
  return Gameplay._cache[path] || (Gameplay._cache[path] = 'data:audio/wav;base64,' + k);
}
/* copy a built-in file into the project if it isn't there yet (so you can see / replace it in Assets) */
function ensureAsset(path){
  if (!path || VFS.has(path)) return path;
  const b64 = (window.BUILTIN_SFX || {})[path] || (window.DEMO_ASSETS || {})[path]; if (!b64) return path;
  const bin = atob(b64), u = new Uint8Array(bin.length); for (let i = 0; i < bin.length; i++) u[i] = bin.charCodeAt(i);
  VFS.add(path, new Blob([u])); return path;
}

/* ----- meshes for the new object types ----- */
function std(c, extra){ return new THREE.MeshStandardMaterial(Object.assign({color: c, roughness: .6, metalness: .2}, extra || {})); }
function bx(w, hh, d, m){ const x = new THREE.Mesh(W.geo.box, m); x.scale.set(w, hh, d); x.castShadow = true; return x; }
function makeGunMesh(kind){
  const g = new THREE.Group(), dark = std('#2a2d33', {metalness: .6, roughness: .4}), grip = std('#4a3a2a', {roughness: .8});
  const rifle = kind === 'rifle';
  const body = bx(.08, .11, rifle ? .55 : .26, dark); body.position.z = rifle ? -.12 : -.05; g.add(body);
  const barrel = new THREE.Mesh(new THREE.CylinderGeometry(.018, .018, rifle ? .4 : .14, 10), dark); barrel.rotation.x = Math.PI / 2; barrel.position.set(0, .02, rifle ? -.58 : -.24); g.add(barrel);
  const hand = bx(.06, .16, .07, grip); hand.position.set(0, -.11, .03); hand.rotation.x = .25; g.add(hand);
  const mag = bx(.05, .12, .06, dark); mag.position.set(0, -.1, rifle ? -.18 : -.02); g.add(mag);
  if (rifle){ const stock = bx(.06, .1, .22, grip); stock.position.set(0, -.02, .25); g.add(stock); }
  const sight = bx(.02, .03, .03, dark); sight.position.set(0, .07, rifle ? -.3 : -.15); g.add(sight);
  return g;
}
function makeCarMesh(o){
  const g = new THREE.Group(), paint = makeMaterial(o); paint.metalness = .5; paint.roughness = .35;
  const glass = std('#1d2a3a', {metalness: .8, roughness: .15}), tire = std('#151515', {roughness: .9}), rim = std('#b8bec8', {metalness: .9, roughness: .3});
  const body = bx(1.9, .55, 4.2, paint); body.position.y = .62; g.add(body);
  const hood = bx(1.85, .15, 1.2, paint); hood.position.set(0, .95, -1.35); g.add(hood);
  const cabin = bx(1.6, .55, 2.0, glass); cabin.position.set(0, 1.15, .25); g.add(cabin);
  const roof = bx(1.62, .06, 1.7, paint); roof.position.set(0, 1.45, .3); g.add(roof);
  const lightM = new THREE.MeshStandardMaterial({color: '#fff6d5', emissive: '#fff2b0', emissiveIntensity: 1.2});
  const tailM = new THREE.MeshStandardMaterial({color: '#ff3030', emissive: '#aa0000'});
  for (const s of [-1, 1]){ const hl = bx(.35, .14, .05, lightM); hl.position.set(s * .65, .72, -2.11); g.add(hl);
    const tl = bx(.35, .12, .05, tailM); tl.position.set(s * .65, .75, 2.11); g.add(tl); }
  const wheels = [];
  for (const [x, z, front] of [[-.95, -1.35, 1], [.95, -1.35, 1], [-.95, 1.35, 0], [.95, 1.35, 0]]){
    const pivot = new THREE.Group(); pivot.position.set(x, .38, z); const spin = new THREE.Group(); pivot.add(spin);
    const t = new THREE.Mesh(new THREE.CylinderGeometry(.38, .38, .3, 20), tire); t.rotation.z = Math.PI / 2; t.castShadow = true; spin.add(t);
    const r = new THREE.Mesh(new THREE.CylinderGeometry(.2, .2, .31, 12), rim); r.rotation.z = Math.PI / 2; spin.add(r);
    g.add(pivot); wheels.push({pivot, spin, front: !!front});
  }
  g.userData.wheels = wheels; g.userData.ownMat = true;
  return g;
}
function makeCheckpointMesh(){
  const g = new THREE.Group(); const pad = new THREE.Mesh(W.geo.cylinder, std('#3b4352')); pad.scale.set(1.6, .08, 1.6); pad.position.y = .04; pad.receiveShadow = true; g.add(pad);
  const pole = new THREE.Mesh(W.geo.cylinder, std('#d0d4dc', {metalness: .7})); pole.scale.set(.06, 2.2, .06); pole.position.y = 1.1; pole.castShadow = true; g.add(pole);
  const flagM = std('#8a8f99', {side: THREE.DoubleSide}); const flag = new THREE.Mesh(W.geo.quad, flagM); flag.scale.set(.8, .5, 1); flag.position.set(.42, 1.9, 0); g.add(flag);
  g.userData.flagMat = flagM; return g;
}
function makeAmmoMesh(){
  const g = new THREE.Group(); const b = bx(.6, .38, .4, std('#4b5a2e', {roughness: .9})); b.position.y = .19; g.add(b);
  const band = bx(.62, .08, .42, std('#e8c33a')); band.position.y = .3; g.add(band); return g;
}
function gameplayMesh(o){
  if (o.type === 'weapon'){ const g = new THREE.Group(); const gun = makeGunMesh(o.weapon.kind); gun.scale.setScalar(2); gun.position.y = .3; g.add(gun); g.userData.spinner = gun; return g; }
  if (o.type === 'ammo') return makeAmmoMesh();
  if (o.type === 'checkpoint') return makeCheckpointMesh();
  if (o.type === 'vehicle') return makeCarMesh(o);
  if (o.type === 'group'){ const g = new THREE.Group(); const ax = new THREE.AxesHelper(.8); ax.userData.editorOnly = true; g.add(ax); return g; }
  return new THREE.Group();
}

/* ----- runtime ----- */
const GEARS = ['R', 'N', '1', '2', '3', '4', '5'];
const GEAR_TOP = [-.18, 0, .2, .38, .58, .78, 1];      // fraction of top speed per gear
const Gameplay = {
  init(){
    const hud = $('#hud');
    hud.append(h('div', {id: 'ammoHud', hidden: true}), h('div', {id: 'carHud', hidden: true}, h('div', {class: 'gear'}), h('div', {class: 'spd'}), h('div', {class: 'rpm'}, h('div')), h('div', {class: 'tip'}, 'W/S drive · A/D steer · Space gear up · Shift gear down · E exit')));
    const keys = ['1','2','3','4','5','6','7','8','9','⌫','0','OK'];
    const pad = h('div', {class: 'pw-keys'}, ...keys.map(k => h('button', {class: k === 'OK' ? 'ok' : '', onclick: () => this.padKey(k)}, k)));
    hud.append(h('div', {id: 'pwPanel', hidden: true}, h('div', {class: 'pw-box'},
      h('div', {class: 'pw-title'}), h('input', {id: 'pwInput', type: 'password', autocomplete: 'off', spellcheck: false}), pad,
      h('button', {class: 'pw-cancel', onclick: () => this.closePw()}, 'Cancel (Esc)'))));
    const inp = $('#pwInput');
    inp.addEventListener('keydown', e => { e.stopPropagation();
      if (e.key === 'Enter'){ e.preventDefault(); this.submitPw(); } else if (e.key === 'Escape'){ e.preventDefault(); this.closePw(); }
      else if (e.key.length === 1 || e.key === 'Backspace') this.beep(); });
    window.addEventListener('mouseup', e => { if (e.button === 0) Items.trigger = false; });
  },
  R(){ return Runtime; },
  reset(){
    const RT = Runtime; this.car = null; this.touchDmg = new Map(); this.objTouch = new Set();
    this.stopEngine(); this.closePw(true); $('#carHud').hidden = true; W.scene.add(RT.camera);
    for (const e of RT.entries.values()){
      if (e.o.type === 'vehicle'){ e.car = {home: e.root.position.clone(), speed: 0, gear: 2, rpm: 900, steer: 0, cut: 0, yaw: e.root.rotation.y, body: {pos: e.root.position.clone(), vel: new V3(), r: 1.1, h: 1.4, onGround: false}}; }
    }
    Items.reset();
  },
  stop(){ Items.stop(); this.stopEngine(); this.closePw(true); if (Runtime.camera) W.scene.remove(Runtime.camera); $('#ammoHud').hidden = true; $('#carHud').hidden = true; },
  beep(){ Runtime.playSound({sound: SFX + 'keypad_beep.wav', volume: .5}); },

  /* --- input hooks --- */
  keyDown(code){
    const RT = Runtime, K = RT.S.keys;
    if (this.car){ if (code === 'Space') this.shift(1); if (code === 'ShiftLeft' || code === 'ShiftRight') this.shift(-1); return; }
    if (code === K.reload) Items.reload();
    const n = /^Digit([1-9])$/.exec(code); if (n) Items.select(+n[1] - 1);
  },
  onInteract(){   // returns true if it handled the interact key
    const RT = Runtime;
    if (this.car){ this.exitCar(); return true; }
    const car = this.nearCar(); if (car){ this.enterCar(car); return true; }
    const t = this.pwTarget(); if (t){ this.openPw(t); return true; }
    return false;
  },
  mouseDown(btn){
    const RT = Runtime; if (this.pwOpen) return true;
    if (this.car) return true;
    if (btn === 'left'){ const t = this.pwTarget(); if (t){ this.openPw(t); return true; } }
    return false;
  },

  /* --- per frame --- */
  update(dt){
    const RT = Runtime, pl = RT.player;
    if (this.car) this.driveCar(dt);
    // spinning pickups
    for (const e of RT.entries.values()){ if (e.dead) continue;
      if (e.o.type === 'weapon' || e.o.type === 'ammo'){ const b = e.root.userData.body; b.rotation.y += dt * 1.5; b.position.y = Math.sin(RT.time * 2.5) * .08 + .1; } }
    // touching: pickups, damage, checkpoints
    const pb = new THREE.Box3(new V3(pl.pos.x - pl.r, pl.pos.y, pl.pos.z - pl.r), new V3(pl.pos.x + pl.r, pl.pos.y + pl.h, pl.pos.z + pl.r));
    for (const e of RT.entries.values()){
      if (e.dead || e.hidden) continue;
      const dmg = e.o.damage && e.o.damage.on, ty = e.o.type;
      if (!dmg && !['weapon','ammo','checkpoint'].includes(ty)) continue;
      const b = boxOf(e.root, true).expandByScalar(.1); const hit = b.intersectsBox(pb) && !this.car;
      if (ty === 'weapon' && hit) Items.pickWeaponObject(e);
      else if (ty === 'ammo' && hit){ Items.addAmmo(e.o.ammo.ammoType, +e.o.ammo.amount || 0); RT.toast(`+${e.o.ammo.amount} ${e.o.ammo.ammoType} ammo`); RT.playSound({sound: SFX + 'dry_fire.wav', volume: .6}); RT.destroy(e); }
      else if (ty === 'checkpoint' && hit) this.touchCheckpoint(e);
      if (dmg){ const D = e.o.damage, st = this.touchDmg.get(e.o.id) || {in: false, acc: 0, cool: 0}; st.cool -= dt;
        if (hit){ if (D.kill) RT.damagePlayer(99999);
          else if (D.perSecond){ st.acc += (+D.amount || 0) * dt; if (st.acc >= 1){ const n = Math.floor(st.acc); st.acc -= n; RT.damagePlayer(n); } }
          else if (!st.in && st.cool <= 0){ RT.damagePlayer(+D.amount || 0); st.cool = .5; } }
        st.in = hit; this.touchDmg.set(e.o.id, st); }
    }
    // object touches object trigger
    for (const t of P.triggers) if (t.type === 'objTouch' && t.tag && t.tag2){
      const A = RT.find(t.tag), B = RT.find(t.tag2);
      for (const a of A){ const ba = boxOf(a.root, true).expandByScalar(.05);
        for (const b of B){ if (a === b) continue; const key = t.id + ':' + a.o.id + ':' + b.o.id;
          if (ba.intersectsBox(boxOf(b.root, true))){ if (!this.objTouch.has(key)){ this.objTouch.add(key); RT.fireTrigger(t, a); } }
          else this.objTouch.delete(key); } } }
  },
  /* camera override while driving (chase camera) */
  camera(dt){
    if (!this.car || Runtime.camLock) return;
    const c = this.car, root = c.e.root, cam = Runtime.camera;
    const back = new V3(Math.sin(c.yaw), 0, Math.cos(c.yaw)).multiplyScalar(7.5);
    const want = root.position.clone().add(back).add(new V3(0, 3, 0));
    if (!this._cc) this._cc = want.clone(); this._cc.lerp(want, Math.min(1, dt * 5));
    cam.position.copy(this._cc); cam.lookAt(root.position.clone().add(new V3(-Math.sin(c.yaw) * 3, 1.2, -Math.cos(c.yaw) * 3)));
    const fovT = (+Runtime.S.fov || 75) + Math.min(18, Math.abs(c.speed) * .35); cam.fov += (fovT - cam.fov) * Math.min(1, dt * 4); cam.updateProjectionMatrix();
  },
  lookPrompt(){
    if (this.car) return;
    const pr = $('#prompt'), K = Runtime.S.keys; const car = this.nearCar();
    if (car && !pr.textContent) pr.textContent = `[${keyLabel(K.interact)}] Drive`;
    const t = this.pwTarget(); if (t && !pr.textContent.startsWith('[')) pr.textContent = `[LMB / ${keyLabel(K.interact)}] ${t.o.password.prompt || 'Enter password'}`;
    else if (t && t.o.type === 'interaction') pr.textContent = `[LMB / ${keyLabel(K.interact)}] 🔒 ${t.o.password.prompt || 'Enter password'}`;
  },

  spark(p){ const m = new THREE.Mesh(new THREE.SphereGeometry(.06, 6, 4), new THREE.MeshBasicMaterial({color: 0xffd080})); m.position.copy(p); W.scene.add(m); setTimeout(() => { W.scene.remove(m); m.geometry.dispose(); }, 120); },

  /* --- checkpoints --- */
  touchCheckpoint(e){
    const RT = Runtime; if (RT.activeCp === e.o.id) return;
    const prev = RT.entries.get(RT.activeCp); if (prev && prev.root.userData.body.userData.flagMat) prev.root.userData.body.userData.flagMat.color.set('#8a8f99');
    RT.activeCp = e.o.id; const p = e.root.getWorldPosition(new V3()); p.y += .1;
    RT.checkpoint = {pos: p, yaw: RT.player.yaw};
    const fm = e.root.userData.body.userData.flagMat; if (fm) fm.color.set('#3fd27a');
    RT.toast('Checkpoint'); RT.playSound({sound: e.o.checkpoint.sound || SFX + 'checkpoint.wav', volume: .7});
    if (e.o.checkpoint.event) RT.fireEvent(e.o.checkpoint.event, e);
  },

  /* --- password keypads --- */
  pwTarget(){
    const RT = Runtime, r = RT.lastPick; if (!r || this.car) return null;
    const range = +RT.S.interactRange;
    const cands = []; if (r.inter && r.inter.e && r.inter.d <= range) cands.push(r.inter.e); if (r.aim && r.aim.e && r.aim.d <= range) cands.push(r.aim.e);
    return cands.find(e => e.o.password && e.o.password.enabled && !e.pwOpen) || null;
  },
  openPw(e){
    const RT = Runtime; this.pwOpen = e; this.pwWasLocked = RT.player.locked; RT.player.locked = true;
    if (document.pointerLockElement) document.exitPointerLock();
    $('#pwPanel').hidden = false; $('#pwPanel .pw-title').textContent = e.o.password.prompt || 'Enter password';
    const i = $('#pwInput'); i.value = ''; i.type = e.o.password.showText ? 'text' : 'password'; setTimeout(() => i.focus(), 30);
    this.beep();
  },
  padKey(k){ const i = $('#pwInput'); this.beep();
    if (k === 'OK') return this.submitPw(); if (k === '⌫') i.value = i.value.slice(0, -1); else i.value += k; i.focus(); },
  closePw(silent){ if (!this.pwOpen) return; const RT = Runtime; this.pwOpen = null; $('#pwPanel').hidden = true; RT.player.locked = !!this.pwWasLocked;
    if (!silent && RT.active) RT.requestLock(); },
  submitPw(){
    const RT = Runtime, e = this.pwOpen; if (!e) return; const pw = e.o.password, val = $('#pwInput').value;
    if (val === String(pw.code)){
      RT.playSound({sound: pw.okSound || SFX + 'access_granted.wav'}); RT.toast(pw.okText || 'Access granted');
      if (pw.once !== false) e.o.password = Object.assign({}, pw, {enabled: false});
      this.closePw();
      if (pw.event) RT.fireEvent(pw.event, e);
      if (e.o.type === 'interaction'){ e._pwOk = true; RT.activate(e); if (pw.once === false) e._pwOk = false; }
    } else {
      RT.playSound({sound: pw.failSound || SFX + 'access_denied.wav'}); $('#pwInput').value = '';
      const b = $('#pwPanel .pw-box'); b.classList.remove('shake'); void b.offsetWidth; b.classList.add('shake');
      if (pw.failEvent) RT.fireEvent(pw.failEvent, e);
    }
  },

  /* --- car --- */
  nearCar(){ const pl = Runtime.player; let best = null, bd = 3.6;
    for (const e of Runtime.entries.values()) if (e.car && !e.dead && !e.hidden){ const d = e.root.position.distanceTo(pl.pos); if (d < bd){ bd = d; best = e; } }
    return best; },
  enterCar(e){
    const RT = Runtime; this.car = e.car; this.car.e = e; e.held = true; RT.player.inCar = true; RT.player.vel.set(0,0,0);
    this._cc = null; if (RT.playerBody) RT.playerBody.visible = false;
    const V = e.o.vehicle; this.engine = RT.playSound({sound: V.engineSound || SFX + 'engine_loop.wav', volume: .45, loop: true, channel: 'engine'});
    if (this.engine) try { this.engine.a.preservesPitch = false; this.engine.a.mozPreservesPitch = false; } catch(_){}
    $('#carHud').hidden = false; Items.renderHotbar(); RT.toast('Space = gear up · Shift = gear down · E = exit');
  },
  exitCar(){
    const RT = Runtime, c = this.car; if (!c) return; const e = c.e;
    this.car = null; e.held = false; RT.player.inCar = false; this.stopEngine();
    const side = new V3(Math.cos(c.yaw), 0, -Math.sin(c.yaw)).multiplyScalar(-2.2);
    RT.player.pos.copy(e.root.position).add(side); RT.player.pos.y += .2; RT.player.yaw = c.yaw; RT.player.pitch = 0;
    e.box = boxOf(e.root); RT.collidersDirty = true; $('#carHud').hidden = true; Items.renderHotbar();
    RT.camera.fov = +RT.S.fov || 75; RT.camera.updateProjectionMatrix();
  },
  stopEngine(){ if (this.engine){ try { this.engine.a.pause(); } catch(_){} this.engine.dead = true; this.engine = null; } },
  shift(dir){ const c = this.car; const g = Math.max(0, Math.min(GEARS.length - 1, c.gear + dir)); if (g === c.gear) return;
    c.gear = g; c.cut = .22; Runtime.playSound({sound: c.e.o.vehicle.shiftSound || SFX + 'gear_shift.wav', volume: .8}); },
  driveCar(dt){
    const RT = Runtime, c = this.car, e = c.e, V = e.o.vehicle, K = RT.S.keys, k = RT.keys;
    const top = (+V.topSpeed || 160) / 3.6, power = +V.power || 9;
    const thr = k.has(K.forward) ? 1 : 0, brk = k.has(K.back) ? 1 : 0;
    const steerIn = (k.has(K.left) ? 1 : 0) - (k.has(K.right) ? 1 : 0);
    c.steer += (steerIn - c.steer) * Math.min(1, dt * 6);
    const g = c.gear, gTop = GEAR_TOP[g] * top, sp = c.speed; let acc = 0; c.cut -= dt;
    const idle = 900, red = 7000;
    if (g >= 2){
      const lower = g === 2 ? 0 : GEAR_TOP[g - 1] * top;
      c.rpm = Math.max(idle, Math.min(red + 200, idle + Math.max(0, sp) / gTop * (red - idle)));
      let torque = c.rpm < 1600 ? .6 : c.rpm < 5600 ? 1 : .8;
      if (sp < lower * .55) torque *= .35;            // lugging in too high a gear
      const ratio = Math.pow(GEAR_TOP[2] / GEAR_TOP[g], .55);
      if (c.cut <= 0 && sp < gTop) acc += thr * power * ratio * torque;
      if (sp >= gTop && thr) c.rpm = red - Math.random() * 400;   // limiter bounce
    } else if (g === 0){
      c.rpm = Math.max(idle, Math.min(red, idle + Math.abs(sp) / Math.abs(gTop) * (red - idle)));
      if (c.cut <= 0 && sp > gTop) acc -= thr * power * .8;
    } else c.rpm += ((thr ? 5500 : idle) - c.rpm) * Math.min(1, dt * 5);   // neutral: free rev
    if (brk) acc -= Math.sign(sp || 1) * 22 * (Math.abs(sp) > .3 ? 1 : 0);
    acc -= sp * .08 + Math.sign(sp) * (thr ? .2 : 1.2);   // drag + rolling / engine braking
    c.speed += acc * dt; if (Math.abs(c.speed) < .05 && !thr) c.speed = 0;
    const turn = c.steer * (+V.steering || 1) * 1.9 * Math.min(1, Math.abs(c.speed) / 6) * Math.sign(c.speed) * (1 - .45 * Math.min(1, Math.abs(c.speed) / top));
    c.yaw += turn * dt;
    const b = c.body; b.pos.copy(e.root.position); b.vel.x = -Math.sin(c.yaw) * c.speed; b.vel.z = -Math.cos(c.yaw) * c.speed; b.vel.y -= (+RT.S.gravity) * dt;
    b.hitWall = false; RT.moveBody(b, dt);
    if (b.hitWall){ c.speed *= -.25; RT.doShake(.2, .2); }
    if (b.pos.y < +RT.S.killY){ b.pos.copy(c.home || e.dyn?.home || new V3(0, 1, 0)); c.speed = 0; }
    e.root.position.copy(b.pos); e.root.rotation.set(0, c.yaw, 0); e.root.updateMatrixWorld(true); e.box = boxOf(e.root);
    RT.player.pos.copy(b.pos); RT.player.vel.set(0,0,0); RT.player.onGround = true;
    const wh = e.root.userData.body.userData.wheels || [];
    for (const w of wh){ w.spin.rotation.x -= c.speed * dt / .38; if (w.front) w.pivot.rotation.y = c.steer * .5; }
    if (this.engine){ this.engine.a.playbackRate = Math.max(.5, Math.min(3.5, .55 + c.rpm / 7000 * 1.6)); this.engine.vol = .3 + .25 * thr; }
    const hud = $('#carHud'); hud.querySelector('.gear').textContent = GEARS[g];
    hud.querySelector('.spd').textContent = Math.round(Math.abs(c.speed) * 3.6) + ' km/h';
    const rb = hud.querySelector('.rpm div'); rb.style.width = Math.min(100, c.rpm / 72) + '%'; rb.classList.toggle('red', c.rpm > 6300);
  },

  /* --- saves --- */
  state(){ return {items: Items.state(), cp: Runtime.checkpoint ? {pos: Runtime.checkpoint.pos.toArray(), yaw: Runtime.checkpoint.yaw, id: Runtime.activeCp} : null}; },
  restore(s){ if (!s) return; Items.restore(s.items);
    if (s.cp){ Runtime.checkpoint = {pos: new V3().fromArray(s.cp.pos), yaw: s.cp.yaw}; Runtime.activeCp = s.cp.id; } },
};
