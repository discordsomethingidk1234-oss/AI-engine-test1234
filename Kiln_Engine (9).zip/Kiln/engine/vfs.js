/* ---------- Virtual file system: the project folder lives here ----------
   Paths look like "assets/textures/brick.png". The project is a folder:
     project.json            (scene, events, triggers, settings)
     assets/textures/*       (png, jpg, webp, gif...)
     assets/models/*         (fbx, glb, gltf)
     assets/sfx/*            (wav, mp3, ogg...)
     assets/music/*
     saves/slotN.json        (in-game save files)
*/
const EXT = {
  image: ['png','jpg','jpeg','gif','webp','bmp','svg','avif'],
  model: ['fbx','glb','gltf'],
  audio: ['wav','mp3','ogg','m4a','aac','flac','webm','opus'],
  font: ['ttf','otf','woff','woff2'],
};
const MIME = {png:'image/png',jpg:'image/jpeg',jpeg:'image/jpeg',gif:'image/gif',webp:'image/webp',bmp:'image/bmp',svg:'image/svg+xml',avif:'image/avif',
  wav:'audio/wav',mp3:'audio/mpeg',ogg:'audio/ogg',m4a:'audio/mp4',aac:'audio/aac',flac:'audio/flac',webm:'audio/webm',opus:'audio/ogg',ttf:'font/ttf',otf:'font/otf',woff:'font/woff',woff2:'font/woff2',json:'application/json'};

const VFS = {
  files: new Map(),          // path -> {blob, url, kind}
  listeners: [],
  dirty: new Set(), removed: new Set(),
  ext(p){ const m = /\.([a-z0-9]+)$/i.exec(p); return m ? m[1].toLowerCase() : ''; },
  kindOf(p){ const e = this.ext(p); for (const k in EXT) if (EXT[k].includes(e)) return k; return e === 'json' ? 'json' : 'other'; },
  folderFor(name){ const k = this.kindOf(name);
    return k === 'image' ? 'assets/textures' : k === 'model' ? 'assets/models' : k === 'audio' ? 'assets/sfx' : k === 'font' ? 'assets/fonts' : 'assets/other'; },
  base(p){ return p.split('/').pop(); },
  dir(p){ return p.split('/').slice(0, -1).join('/'); },
  clean(p){ return p.replace(/\\/g,'/').replace(/^\/+/, '').replace(/\/+/g,'/'); },
  add(path, blob, silent){
    path = this.clean(path);
    const old = this.files.get(path); if (old && old.url) URL.revokeObjectURL(old.url);
    const e = this.ext(path);
    if (MIME[e] && blob.type !== MIME[e]) blob = new Blob([blob], {type: MIME[e]});
    this.files.set(path, {blob, url: URL.createObjectURL(blob), kind: this.kindOf(path)});
    this.dirty.add(path); this.removed.delete(path);
    if (!silent) this.emit();
    return path;
  },
  uniquePath(path){
    if (!this.files.has(path)) return path;
    const d = this.dir(path), b = this.base(path), i = b.lastIndexOf('.');
    const stem = i > 0 ? b.slice(0, i) : b, ex = i > 0 ? b.slice(i) : '';
    for (let n = 2; ; n++){ const p = (d ? d + '/' : '') + stem + '_' + n + ex; if (!this.files.has(p)) return p; }
  },
  remove(path){ const f = this.files.get(path); if (!f) return; URL.revokeObjectURL(f.url); this.files.delete(path); this.dirty.delete(path); this.removed.add(path); this.emit(); },
  rename(from, to){ const f = this.files.get(from); if (!f) return; to = this.clean(to); this.files.delete(from); this.removed.add(from); this.files.set(to, f); f.kind = this.kindOf(to); this.dirty.add(to); this.emit(); },
  url(path){ const f = this.files.get(path); return f ? f.url : null; },
  has(path){ return this.files.has(path); },
  list(kind){ return [...this.files.keys()].filter(p => !kind || this.files.get(p).kind === kind).sort(); },
  findByName(name){ name = this.base(this.clean(name)).toLowerCase(); for (const p of this.files.keys()) if (this.base(p).toLowerCase() === name) return p; return null; },
  clear(){ for (const f of this.files.values()) URL.revokeObjectURL(f.url); this.files.clear(); this.dirty.clear(); this.removed.clear(); this.emit(); },
  on(fn){ this.listeners.push(fn); },
  emit(){ for (const fn of this.listeners) try { fn(); } catch(e){ console.error(e); } },
};

/* ---------- IndexedDB persistence (project survives page reloads) ---------- */
const Store = {
  db: null,
  open(){ if (this.db) return Promise.resolve(this.db);
    return new Promise((res, rej) => { const r = indexedDB.open('kiln-engine', 1);
      r.onupgradeneeded = () => { r.result.createObjectStore('kv'); r.result.createObjectStore('files'); };
      r.onsuccess = () => { this.db = r.result; res(this.db); }; r.onerror = () => rej(r.error); }); },
  async tx(store, mode, fn){ const db = await this.open(); return new Promise((res, rej) => {
      const t = db.transaction(store, mode); const s = t.objectStore(store); const out = fn(s);
      t.oncomplete = () => res(out instanceof IDBRequest ? out.result : out); t.onerror = () => rej(t.error); }); },
  async saveProject(json, full){
    await this.tx('kv', 'readwrite', s => s.put(json, 'project'));
    await this.tx('files', 'readwrite', s => {
      if (full) s.clear();
      const paths = full ? [...VFS.files.keys()] : [...VFS.dirty];
      for (const p of paths){ const f = VFS.files.get(p); if (f) s.put(f.blob, p); }
      if (!full) for (const p of VFS.removed) s.delete(p);
    });
    VFS.dirty.clear(); VFS.removed.clear();
  },
  async loadProject(){
    try {
      const json = await this.tx('kv', 'readonly', s => s.get('project'));
      if (!json) return null;
      const db = await this.open();
      const files = await new Promise((res, rej) => { const out = []; const t = db.transaction('files'); const c = t.objectStore('files').openCursor();
        c.onsuccess = () => { const cur = c.result; if (cur){ out.push([cur.key, cur.value]); cur.continue(); } else res(out); }; c.onerror = () => rej(c.error); });
      return {json, files};
    } catch(e){ console.warn('IndexedDB unavailable', e); return null; }
  },
};

/* ---------- Zip / folder import & export ---------- */
const ProjectIO = {
  async exportZip(project){
    const blob = await this.buildZip(project);
    downloadBlob(blob, safeName(project.name || 'MyGame') + '.zip');
  },
  async buildZip(project){
    const zip = new JSZip(); const root = zip.folder(safeName(project.name || 'MyGame'));
    const p = JSON.parse(JSON.stringify(project)); const saves = p.saves || {}; delete p.saves;
    root.file('project.json', JSON.stringify(p, null, 2));
    root.file('config.json', JSON.stringify(gameConfig(project), null, 2));
    // already-compressed formats are stored as-is (much faster export)
    const packed = /\.(png|jpe?g|webp|gif|avif|mp3|ogg|m4a|aac|opus|webm|glb|fbx)$/i;
    for (const [path, f] of VFS.files) root.file(path, f.blob, packed.test(path) ? {compression: 'STORE'} : undefined);
    for (const slot in saves) root.file('saves/' + slot + '.json', JSON.stringify(saves[slot], null, 2));
    root.folder('assets/textures'); root.folder('assets/models'); root.folder('assets/sfx'); root.folder('assets/music'); root.folder('assets/fonts'); root.folder('saves');
    return zip.generateAsync({type: 'blob', compression: 'DEFLATE', compressionOptions: {level: 6}});
  },
  /* entries: [{path, blob}] with arbitrary leading folder; returns project json + loads VFS */
  async fromEntries(entries){
    const pj = entries.filter(e => /(^|\/)project\.json$/i.test(e.path)).sort((a,b) => a.path.length - b.path.length)[0];
    let prefix = ''; let project = null;
    if (pj){ prefix = pj.path.slice(0, pj.path.length - 'project.json'.length); project = JSON.parse(await pj.blob.text()); }
    VFS.clear(); const saves = {};
    for (const e of entries){
      if (!e.path.startsWith(prefix)) continue;
      const rel = e.path.slice(prefix.length); if (!rel || rel === 'project.json' || rel === 'config.json' || rel.endsWith('/')) continue;
      if (/^saves\/.+\.json$/i.test(rel)){ try { saves[VFS.base(rel).replace(/\.json$/i,'')] = JSON.parse(await e.blob.text()); } catch(_){} continue; }
      VFS.add(rel, e.blob, true);
    }
    VFS.emit();
    if (project) project.saves = Object.assign(project.saves || {}, saves);
    const cf = entries.find(e => e.path === prefix + 'config.json');
    if (project && cf){ try { applyConfig(project, JSON.parse(await cf.blob.text())); } catch(_){} }
    return project;
  },
  async importZip(file){
    const zip = await JSZip.loadAsync(file); const entries = [];
    for (const name in zip.files){ const z = zip.files[name]; if (z.dir || name.startsWith('__MACOSX')) continue; entries.push({path: name, blob: await z.async('blob')}); }
    return this.fromEntries(entries);
  },
  async importFolder(fileList){
    const entries = [...fileList].map(f => ({path: f.webkitRelativePath || f.name, blob: f}));
    return this.fromEntries(entries);
  },
};
function safeName(s){ return String(s).replace(/[^\w\- ]+/g, '').trim().replace(/\s+/g, '_') || 'MyGame'; }
function downloadBlob(blob, name){ const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = name; document.body.appendChild(a); a.click(); setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 2000); }

/* config.json: how the game starts (resolution, FPS, fullscreen) — read by the editor and the Kiln Launcher */
function gameConfig(project){
  const S = project.settings || {};
  return {format: 'kiln-config-1', name: project.name || 'MyGame', resolution: +S.renderHeight || 0, fps: +S.fpsCap || 0,
    pixelated: !!S.pixelated, fullscreen: !!S.fullscreen, camera: S.camera || 'first', fov: +S.fov || 75, mouseSensitivity: +S.mouseSensitivity || 1, exported: new Date().toISOString()};
}
function applyConfig(project, c){
  if (!c) return; const S = project.settings = project.settings || {};
  if (c.resolution != null) S.renderHeight = +c.resolution || 0; if (c.fps != null) S.fpsCap = +c.fps || 0;
  if (c.pixelated != null) S.pixelated = !!c.pixelated; if (c.fullscreen != null) S.fullscreen = !!c.fullscreen;
  if (c.fov) S.fov = +c.fov; if (c.mouseSensitivity) S.mouseSensitivity = +c.mouseSensitivity; if (c.camera) S.camera = c.camera;
}
