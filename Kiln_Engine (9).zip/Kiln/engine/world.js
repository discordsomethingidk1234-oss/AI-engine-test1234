/* ---------- World: Three.js scene, object building, textures, models, mannequins ---------- */
const D2R = Math.PI / 180, R2D = 180 / Math.PI;
const W = {
  renderer:null, scene:null, camera:null, sun:null, hemi:null, grid:null,
  roots: new Map(), texCache: new Map(), modelCache: new Map(), geo:{}, container:null,
  editorMode: true,

  init(container){
    this.container = container;
    const r = this.renderer = new THREE.WebGLRenderer({antialias: true, powerPreference: 'high-performance'});
    r.outputEncoding = THREE.sRGBEncoding; r.shadowMap.enabled = true; r.shadowMap.type = THREE.PCFSoftShadowMap;
    r.toneMapping = THREE.ACESFilmicToneMapping; r.toneMappingExposure = 1.05;
    container.prepend(r.domElement); r.domElement.tabIndex = 0;
    this.scene = new THREE.Scene();
    this.camera = new THREE.PerspectiveCamera(60, 1, 0.05, 2000); this.camera.position.set(12, 10, 14);
    this.hemi = new THREE.HemisphereLight(0xdde8ff, 0x4a4030, 0.6); this.scene.add(this.hemi);
    const s = this.sun = new THREE.DirectionalLight(0xfff2dd, 1.1); s.position.set(30, 50, 20); s.castShadow = true;
    s.shadow.mapSize.set(2048, 2048); Object.assign(s.shadow.camera, {left:-60, right:60, top:60, bottom:-60, near:1, far:200}); s.shadow.bias = -0.0005;
    this.scene.add(s, s.target);
    this.grid = new THREE.GridHelper(200, 200, 0x3a4252, 0x252b36); this.grid.material.transparent = true; this.grid.material.opacity = .6; this.grid.position.y = 0.001;
    this.scene.add(this.grid);
    const g = this.geo;
    g.box = new THREE.BoxGeometry(1,1,1); g.sphere = new THREE.SphereGeometry(.5, 32, 18); g.cylinder = new THREE.CylinderGeometry(.5,.5,1,32);
    g.cone = new THREE.ConeGeometry(.5, 1, 32); g.plane = new THREE.PlaneGeometry(1,1); g.plane.rotateX(-Math.PI/2);
    g.quad = new THREE.PlaneGeometry(1,1); g.ramp = rampGeometry(); g.edges = new THREE.EdgesGeometry(g.box);
    new ResizeObserver(() => this.resize()).observe(container); this.resize();
  },
  renderHeight: 0,
  /* game resolution: the picture is drawn at N pixels tall (width follows the window shape), then stretched to fill */
  setRenderHeight(hgt, pixelated){ this.renderHeight = +hgt || 0; this.renderer.domElement.style.imageRendering = pixelated ? 'pixelated' : ''; this.resize(); },
  basePixelRatio(){ return Math.min(window.devicePixelRatio || 1, 2) * (P && P.settings ? (+P.settings.pixelRatio || 1) : 1); },
  resize(){ const w = this.container.clientWidth || 1, h = this.container.clientHeight || 1;
    this.renderer.setPixelRatio(this.renderHeight > 0 ? this.renderHeight / h : this.basePixelRatio());
    this.renderer.setSize(w, h, false); for (const c of [this.camera, Runtime.camera]) if (c){ c.aspect = w / h; c.updateProjectionMatrix(); } },

  applyEnvironment(){
    const s = P.settings;
    this.scene.background = new THREE.Color(s.sky);
    this.scene.fog = s.fogFar > 0 ? new THREE.Fog(s.fogColor, s.fogNear, s.fogFar) : null;
    this.hemi.intensity = s.ambient; this.sun.intensity = s.sunIntensity;
    this.renderer.shadowMap.enabled = !!s.shadows; this.sun.castShadow = !!s.shadows;
    this.resize();
    this.scene.traverse(m => { if (m.material) m.material.needsUpdate = true; });
  },

  clear(){ for (const r of this.roots.values()) this.disposeRoot(r); this.roots.clear(); },
  disposeRoot(r){ if (r.parent) r.parent.remove(r); r.traverse(m => { if (m.userData.ownMat && m.material){ (Array.isArray(m.material)?m.material:[m.material]).forEach(x => x.dispose()); } }); },
  buildAll(){ this.clear(); this.buildList(P.objects); },
  /* parents (groups) are built before their children */
  buildList(list){ const ids = new Set(list.map(o => o.id)), done = new Set();
    const b = o => { if (done.has(o.id)) return; done.add(o.id); if (o.parent && ids.has(o.parent)){ const par = list.find(x => x.id === o.parent); if (par) b(par); } this.build(o); };
    list.forEach(b); },
  rebuild(o){ const old = this.roots.get(o.id);
    const kids = old ? old.children.filter(c => c.userData.objId) : [];
    kids.forEach(k => old.remove(k));
    if (old){ if (old.parent) old.parent.remove(old); this.disposeRoot(old); }
    const r = this.build(o); kids.forEach(k => r.add(k)); return r; },

  build(o){
    const root = new THREE.Group(); root.userData.objId = o.id; root.name = o.name;
    this.applyTransform(o, root);
    const mat = () => { const m = makeMaterial(o); return m; };
    let mesh;
    switch (o.type){
      case 'box': case 'sphere': case 'cylinder': case 'cone': case 'plane': case 'ramp':
        mesh = new THREE.Mesh(this.geo[o.type], mat()); break;
      case 'decal': mesh = new THREE.Mesh(this.geo.quad, mat()); break;
      case 'text3d': mesh = makeTextSign(o); break;
      case 'interaction': {
        mesh = new THREE.Mesh(this.geo.box, new THREE.MeshBasicMaterial({color: o.color, transparent: true, opacity: .22, depthWrite: false}));
        const e = new THREE.LineSegments(this.geo.edges, new THREE.LineBasicMaterial({color: o.color}));
        mesh.add(e); mesh.userData.editorOnly = true; mesh.userData.ownMat = true; mesh.castShadow = false; mesh.receiveShadow = false;
        mesh.renderOrder = 5; break; }
      case 'spawn': {
        mesh = new THREE.Group(); mesh.userData.editorOnly = true;
        const ring = new THREE.Mesh(new THREE.TorusGeometry(.45, .05, 8, 32), new THREE.MeshBasicMaterial({color: 0x5ccf8a})); ring.rotation.x = Math.PI/2; ring.position.y = .05;
        const arrow = new THREE.Mesh(this.geo.cone, new THREE.MeshBasicMaterial({color: 0x5ccf8a})); arrow.scale.set(.35,.6,.35); arrow.rotation.x = -Math.PI/2; arrow.position.set(0,.9,-.4);
        const body = new THREE.Mesh(this.geo.cylinder, new THREE.MeshBasicMaterial({color: 0x5ccf8a, transparent: true, opacity: .25})); body.scale.set(.7,1.7,.7); body.position.y = .85;
        mesh.add(ring, arrow, body); break; }
      case 'light': {
        mesh = new THREE.Group();
        const L = new THREE.PointLight(o.color, o.intensity, o.distance, 2); L.castShadow = false; mesh.add(L); mesh.userData.light = L;
        const bulb = new THREE.Mesh(this.geo.sphere, new THREE.MeshBasicMaterial({color: o.color})); bulb.scale.setScalar(.3); bulb.userData.editorOnly = true; mesh.add(bulb);
        break; }
      case 'model': {
        mesh = new THREE.Group();
        if (o.model) this.attachModel(o, mesh, o.normalize ? 1 : 0);
        else { const ph = new THREE.Mesh(this.geo.box, new THREE.MeshBasicMaterial({color: 0xa98bff, wireframe: true})); ph.position.y = .5; ph.userData.editorOnly = true; mesh.add(ph); }
        break; }
      case 'weapon': case 'ammo': case 'checkpoint': case 'vehicle': case 'group':
        mesh = gameplayMesh(o); break;
      case 'enemy': {
        mesh = new THREE.Group();
        if (o.enemy.model) this.attachModel(o, mesh, o.enemy.normalize ? o.enemy.height : 0);
        else { const man = makeMannequin(o); mesh.add(man); mesh.userData.mannequin = man; }
        break; }
    }
    mesh.traverse(m => { if (m.isMesh && !m.userData.editorOnly && !(m.parent && m.parent.userData.editorOnly)){ m.castShadow = o.castShadow !== false; m.receiveShadow = true; } });
    root.add(mesh); root.userData.body = mesh;
    root.visible = o.visible !== false;
    const par = o.parent && this.roots.get(o.parent);
    (par || this.scene).add(root); this.roots.set(o.id, root);
    this.setEditorVisibility(root);
    return root;
  },
  applyTransform(o, root){
    root = root || this.roots.get(o.id); if (!root) return;
    root.position.fromArray(o.pos); root.rotation.set(o.rot[0]*D2R, o.rot[1]*D2R, o.rot[2]*D2R); root.scale.fromArray(o.scale);
    if (o.type === 'enemy'){ root.scale.set(o.scale[0], o.scale[1], o.scale[2]); }
  },
  setEditorVisibility(root){
    root.traverse(m => { if (m.userData.editorOnly) m.visible = this.editorMode; });
  },
  setEditorMode(on){ this.editorMode = on; this.grid.visible = on; for (const r of this.roots.values()) this.setEditorVisibility(r); },

  /* ----- textures ----- */
  texture(path, rep){
    const url = VFS.url(path); if (!url) return null;
    const key = path + '|' + (rep ? rep.join('x') : '1x1');
    let t = this.texCache.get(key);
    if (t && t.userData.url === url) return t;
    t = new THREE.TextureLoader().load(url, () => { t.needsUpdate = true; });
    t.userData.url = url; t.encoding = THREE.sRGBEncoding; t.wrapS = t.wrapT = THREE.RepeatWrapping;
    t.anisotropy = this.renderer.capabilities.getMaxAnisotropy();
    if (rep) t.repeat.set(+rep[0] || 1, +rep[1] || 1);
    this.texCache.set(key, t); return t;
  },
  invalidateTextures(){ this.texCache.clear(); },

  /* ----- models ----- */
  loadModel(path){
    const url = VFS.url(path); if (!url) return Promise.reject(new Error('Missing model ' + path));
    const cached = this.modelCache.get(path); if (cached && cached.url === url) return cached.p;
    const manager = new THREE.LoadingManager();
    manager.setURLModifier(u => { if (/^(blob|data):/.test(u)) return u;
      const name = decodeURIComponent(u.split(/[\\/]/).pop().split('?')[0]); const p = VFS.findByName(name); return p ? VFS.url(p) : u; });
    const ext = VFS.ext(path);
    const p = new Promise((res, rej) => {
      if (ext === 'fbx') new THREE.FBXLoader(manager).load(url, obj => res({scene: obj, animations: obj.animations || []}), undefined, rej);
      else new THREE.GLTFLoader(manager).load(url, g => res({scene: g.scene, animations: g.animations || []}), undefined, rej);
    });
    p.catch(e => log('Model failed to load: ' + path + ' — ' + (e && e.message || e), 'err'));
    this.modelCache.set(path, {url, p}); return p;
  },
  attachModel(o, holder, targetHeight){
    const path = o.type === 'enemy' ? o.enemy.model : o.model;
    const ph = new THREE.Mesh(this.geo.box, new THREE.MeshBasicMaterial({color: 0xa98bff, wireframe: true})); ph.position.y = .5; holder.add(ph);
    this.loadModel(path).then(src => {
      holder.remove(ph);
      const inst = THREE.SkeletonUtils.clone(src.scene);
      inst.updateMatrixWorld(true);
      const box = new THREE.Box3().setFromObject(inst), size = box.getSize(new THREE.Vector3());
      const pivot = new THREE.Group(); pivot.add(inst);
      if (targetHeight){
        const k = targetHeight / (size.y > 1e-4 ? size.y : Math.max(size.x, size.z, 1e-3));
        inst.scale.multiplyScalar(k);
        const c = box.getCenter(new THREE.Vector3()); inst.position.set(-c.x * k, -box.min.y * k, -c.z * k);
      }
      inst.traverse(m => {
        if (m.isMesh){ m.castShadow = o.castShadow !== false; m.receiveShadow = true; m.frustumCulled = !m.isSkinnedMesh;
          if ((o.type === 'model' && !o.useModelMaterials) || o.texture){
            const mat = makeMaterial(o); mat.skinning = true; m.material = mat; m.userData.ownMat = true; } }
        if (m.isBone) m.userData.restQ = m.quaternion.clone();
      });
      holder.add(pivot); holder.userData.model = inst; holder.userData.clips = src.animations;
      applyJoints(o, holder);
      if (Runtime.active) Runtime.onModelReady(o, holder);
      if (typeof Editor !== 'undefined') Editor.onModelLoaded(o, src);
    }).catch(() => { ph.material.color.set(0xef5b5b); });
  },
  /* All animation clips from every model asset: "path::clip" */
  async allClips(){
    const out = [];
    for (const p of VFS.list('model')){ try { const m = await this.loadModel(p); for (const c of m.animations) out.push({key: p + '::' + c.name, path: p, clip: c}); } catch(e){} }
    return out;
  },
  async findClip(key, localClips){
    if (!key) return null;
    if (key.includes('::')){ const [p, n] = key.split('::'); try { const m = await this.loadModel(p); return m.animations.find(c => c.name === n) || null; } catch(e){ return null; } }
    return (localClips || []).find(c => c.name === key) || null;
  },
};

function makeMaterial(o){
  const tex = o.texture ? W.texture(o.texture, o.texRepeat) : null;
  const decal = o.type === 'decal';
  const m = new THREE.MeshStandardMaterial({
    color: o.color || '#ffffff', map: tex, roughness: +o.roughness, metalness: +o.metalness,
    emissive: o.emissive || '#000000', transparent: decal || (+o.opacity < 1), opacity: +o.opacity,
    side: (o.doubleSided || decal || o.type === 'plane') ? THREE.DoubleSide : THREE.FrontSide, alphaTest: decal ? 0.05 : 0,
  });
  if (decal){ m.depthWrite = false; m.polygonOffset = true; m.polygonOffsetFactor = -2; }
  return m;
}

function rampGeometry(){
  // wedge 1x1x1, low edge at z=+0.5 (front), high edge at z=-0.5, base on y=-0.5
  const v = [-.5,-.5,.5, .5,-.5,.5, .5,-.5,-.5, -.5,-.5,-.5, -.5,.5,-.5, .5,.5,-.5];
  const idx = [0,2,1, 0,3,2,  0,1,5, 0,5,4,  3,4,5, 3,5,2,  0,4,3,  1,2,5];
  const pos = []; for (const i of idx) pos.push(v[i*3], v[i*3+1], v[i*3+2]);
  const g = new THREE.BufferGeometry(); g.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3)); g.computeVertexNormals();
  const uv = []; for (let i = 0; i < pos.length; i += 3) uv.push(pos[i] + .5, (pos[i+1] + pos[i+2]) * .5 + .5);
  g.setAttribute('uv', new THREE.Float32BufferAttribute(uv, 2)); return g;
}

/* ----- 3D text sign: canvas texture ----- */
function drawTextCanvas(o){
  const c = document.createElement('canvas'); const ctx = c.getContext('2d');
  const fs = +o.fontSize || 96, font = `${fs}px "${o.font || 'Barlow'}", sans-serif`;
  ctx.font = font; const lines = String(o.text || '').split('\n');
  const w = Math.max(64, ...lines.map(l => ctx.measureText(l).width)) + fs * .8, lh = fs * 1.2;
  c.width = Math.min(4096, Math.ceil(w)); c.height = Math.ceil(lh * lines.length + fs * .5);
  ctx.font = font; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
  if (o.textBg && !/00$/.test(o.textBg)){ ctx.fillStyle = o.textBg; ctx.fillRect(0, 0, c.width, c.height); }
  ctx.fillStyle = o.textColor || '#fff';
  lines.forEach((l, i) => ctx.fillText(l, c.width / 2, fs * .25 + lh * (i + .5)));
  return c;
}
function makeTextSign(o){
  const c = drawTextCanvas(o); const t = new THREE.CanvasTexture(c); t.encoding = THREE.sRGBEncoding; t.anisotropy = 8;
  const m = new THREE.MeshBasicMaterial({map: t, transparent: true, side: THREE.DoubleSide, toneMapped: false});
  const mesh = new THREE.Mesh(W.geo.quad, m); mesh.scale.y = c.height / c.width; mesh.userData.ownMat = true; mesh.castShadow = false;
  mesh.userData.textSign = true;
  if (document.fonts && document.fonts.load) document.fonts.load(`${o.fontSize || 96}px "${o.font}"`).then(() => {
    const c2 = drawTextCanvas(o); t.image = c2; t.needsUpdate = true; mesh.scale.y = c2.height / c2.width; }).catch(() => {});
  return mesh;
}

/* ----- Mannequin (built-in rig with joints you can pose) ----- */
const MANNEQUIN_JOINTS = ['hips','spine','head','armL','armR','foreArmL','foreArmR','legL','legR','shinL','shinR'];
function makeMannequin(o){
  const mat = makeMaterial(o); mat.userData = {};
  const dark = new THREE.MeshStandardMaterial({color: new THREE.Color(o.color).multiplyScalar(.55), roughness: .9});
  const part = (w, h, d, m) => { const x = new THREE.Mesh(W.geo.box, m || mat); x.scale.set(w, h, d); x.castShadow = true; return x; };
  const J = {}; const joint = (name, parent, x, y, z) => { const g = new THREE.Group(); g.name = name; g.position.set(x, y, z); parent.add(g); J[name] = g; return g; };
  const root = new THREE.Group();
  const hips = joint('hips', root, 0, .95, 0);
  const pel = part(.42, .2, .24, dark); hips.add(pel);
  const spine = joint('spine', hips, 0, .1, 0);
  const torso = part(.46, .55, .26); torso.position.y = .3; spine.add(torso);
  const head = joint('head', spine, 0, .62, 0);
  const skull = part(.26, .28, .26); skull.position.y = .15; head.add(skull);
  const eyeM = new THREE.MeshBasicMaterial({color: o.enemy && o.enemy.hostile ? 0xffe066 : 0xffffff});
  [-.06, .06].forEach(x => { const e = part(.05, .04, .02, eyeM); e.position.set(x, .18, -.135); head.add(e); });
  for (const s of [-1, 1]){
    const side = s < 0 ? 'L' : 'R';
    const arm = joint('arm' + side, spine, s * .3, .52, 0); const up = part(.13, .34, .13); up.position.y = -.17; arm.add(up);
    const fore = joint('foreArm' + side, arm, 0, -.34, 0); const lo = part(.11, .32, .11, dark); lo.position.y = -.16; fore.add(lo);
    const leg = joint('leg' + side, hips, s * .12, -.08, 0); const th = part(.16, .44, .17); th.position.y = -.22; leg.add(th);
    const shin = joint('shin' + side, leg, 0, -.44, 0); const sh = part(.14, .42, .15, dark); sh.position.y = -.21; shin.add(sh);
  }
  root.userData.joints = J; root.userData.ownMat = true;
  for (const n in J) J[n].userData.rest = J[n].rotation.clone();
  root.rotation.y = Math.PI; // face -Z like the camera forward convention... flip so "front" faces +Z after root rotation
  root.rotation.y = 0;
  return root;
}
/* Apply joint pose offsets (degrees) to mannequin joints or model bones */
function applyJoints(o, holder){
  const joints = (o.enemy && o.enemy.joints) || {};
  const man = holder.userData.mannequin;
  if (man){ const J = man.userData.joints;
    for (const n in J){ const off = joints[n] || [0,0,0]; J[n].rotation.set(off[0]*D2R, off[1]*D2R, off[2]*D2R); J[n].userData.pose = J[n].rotation.clone(); } }
  const model = holder.userData.model;
  if (model) model.traverse(b => { if (b.isBone && b.userData.restQ){ const off = joints[b.name];
    b.quaternion.copy(b.userData.restQ);
    b.userData.offQ = off ? new THREE.Quaternion().setFromEuler(new THREE.Euler(off[0]*D2R, off[1]*D2R, off[2]*D2R)) : null;
    if (b.userData.offQ) b.quaternion.multiply(b.userData.offQ); } });
}
function listBones(holder){ const out = []; const m = holder && holder.userData.model; if (m) m.traverse(b => { if (b.isBone) out.push(b.name); }); return out; }
